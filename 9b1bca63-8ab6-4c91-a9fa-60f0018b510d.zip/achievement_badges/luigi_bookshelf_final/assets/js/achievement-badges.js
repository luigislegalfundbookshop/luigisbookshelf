// Achievement Badges for Luigi's Bookshelf

document.addEventListener('DOMContentLoaded', function() {
    // Constants
    const STORAGE_KEY = "luigis_bookshop_data";
    const ACHIEVEMENTS_KEY = "achievements";
    
    // Achievement definitions
    const achievements = [
        {
            id: "philosophy-pioneer",
            name: "Philosophy Pioneer",
            icon: "🧠",
            description: "Complete all Science & Philosophy books",
            category: "science-philosophy",
            requiredCount: 9, // Number of books in this category
            unlocked: false
        },
        {
            id: "memoir-master",
            name: "Memoir Master",
            icon: "📝",
            description: "Complete all Memoir & Biography books",
            category: "memoir-biography",
            requiredCount: 5, // Number of books in this category
            unlocked: false
        },
        {
            id: "fiction-fanatic",
            name: "Fiction Fanatic",
            icon: "📚",
            description: "Complete all Fiction books",
            category: "fiction",
            requiredCount: 4, // Number of books in this category
            unlocked: false
        },
        {
            id: "bookworm",
            name: "Bookworm",
            icon: "🐛",
            description: "Read 5 books from any category",
            requiredCount: 5,
            unlocked: false
        },
        {
            id: "avid-reader",
            name: "Avid Reader",
            icon: "📖",
            description: "Read 10 books from across all categories",
            requiredCount: 10,
            unlocked: false
        },
        {
            id: "literary-legend",
            name: "Literary Legend",
            icon: "👑",
            description: "Complete all 18 books in Luigi's collection",
            requiredCount: 18,
            unlocked: false
        },
        {
            id: "dystopian-dreamer",
            name: "Dystopian Dreamer",
            icon: "🔮",
            description: "Read both 1984 and Brave New World",
            specialBooks: ["1984", "brave-new-world"],
            unlocked: false
        },
        {
            id: "tech-titan",
            name: "Tech Titan",
            icon: "🚀",
            description: "Read Elon Musk and Shoe Dog biographies",
            specialBooks: ["elon-musk", "shoe-dog"],
            unlocked: false
        }
    ];
    
    // DOM Elements
    const progressSection = document.getElementById('progress-section');
    const bookCheckboxes = document.querySelectorAll('.book-checkbox');
    
    // Initialize
    initializeAchievements();
    
    // Functions
    function initializeAchievements() {
        // Create achievements section if it doesn't exist
        if (!document.getElementById('achievements-section')) {
            createAchievementsSection();
        }
        
        // Add event listeners to book checkboxes for achievement tracking
        bookCheckboxes.forEach(checkbox => {
            checkbox.addEventListener('change', checkAchievements);
        });
        
        // Check for achievements on page load
        checkAchievements();
    }
    
    function createAchievementsSection() {
        // Create achievements section HTML
        const achievementsSection = document.createElement('div');
        achievementsSection.id = 'achievements-section';
        achievementsSection.className = 'achievements-section';
        
        // Create header with toggle button
        const header = document.createElement('div');
        header.className = 'achievements-header';
        
        const title = document.createElement('h2');
        title.className = 'achievements-title';
        title.textContent = 'Achievement Badges';
        
        const toggleButton = document.createElement('button');
        toggleButton.className = 'achievements-toggle';
        toggleButton.textContent = 'Show Badges';
        toggleButton.setAttribute('aria-expanded', 'false');
        toggleButton.setAttribute('aria-controls', 'achievements-content');
        
        header.appendChild(title);
        header.appendChild(toggleButton);
        
        // Create content container
        const content = document.createElement('div');
        content.id = 'achievements-content';
        content.className = 'achievements-content collapsed';
        
        // Create grid for badges
        const grid = document.createElement('div');
        grid.className = 'achievements-grid';
        
        // Add badges to grid
        achievements.forEach(achievement => {
            const badge = createBadgeElement(achievement);
            grid.appendChild(badge);
        });
        
        content.appendChild(grid);
        
        // Add everything to the section
        achievementsSection.appendChild(header);
        achievementsSection.appendChild(content);
        
        // Add toggle functionality
        toggleButton.addEventListener('click', function() {
            const isExpanded = toggleButton.getAttribute('aria-expanded') === 'true';
            
            if (isExpanded) {
                content.className = 'achievements-content collapsed';
                toggleButton.textContent = 'Show Badges';
                toggleButton.setAttribute('aria-expanded', 'false');
            } else {
                content.className = 'achievements-content expanded';
                toggleButton.textContent = 'Hide Badges';
                toggleButton.setAttribute('aria-expanded', 'true');
            }
        });
        
        // Insert after progress section
        if (progressSection && progressSection.parentNode) {
            progressSection.parentNode.insertBefore(achievementsSection, progressSection.nextSibling);
        }
    }
    
    function createBadgeElement(achievement) {
        const badge = document.createElement('div');
        badge.className = 'achievement-badge locked';
        badge.id = `badge-${achievement.id}`;
        
        const icon = document.createElement('div');
        icon.className = 'badge-icon';
        icon.textContent = achievement.icon;
        
        const name = document.createElement('div');
        name.className = 'badge-name';
        name.textContent = achievement.name;
        
        const description = document.createElement('div');
        description.className = 'badge-description';
        description.textContent = achievement.description;
        
        const lock = document.createElement('div');
        lock.className = 'badge-lock';
        lock.textContent = '🔒';
        
        badge.appendChild(icon);
        badge.appendChild(name);
        badge.appendChild(description);
        badge.appendChild(lock);
        
        return badge;
    }
    
    function checkAchievements() {
        const userData = getStoredData();
        if (!userData || !userData.books) return;
        
        // Get previously unlocked achievements
        const previouslyUnlocked = userData.achievements || {};
        
        // Track newly unlocked achievements
        const newlyUnlocked = [];
        
        // Get all read books
        const readBooks = Object.keys(userData.books).filter(bookId => userData.books[bookId]);
        
        // Get books by category
        const booksByCategory = {};
        bookCheckboxes.forEach(checkbox => {
            const bookId = checkbox.getAttribute('data-book');
            const bookEntry = checkbox.closest('.book-entry');
            const categorySection = bookEntry.closest('.book-list').previousElementSibling;
            
            if (categorySection && categorySection.id) {
                const category = categorySection.id;
                if (!booksByCategory[category]) {
                    booksByCategory[category] = [];
                }
                booksByCategory[category].push(bookId);
            }
        });
        
        // Check each achievement
        achievements.forEach(achievement => {
            let unlocked = false;
            
            if (achievement.category) {
                // Category-based achievement
                const categoryBooks = booksByCategory[achievement.category] || [];
                const readCategoryBooks = categoryBooks.filter(bookId => userData.books[bookId]);
                unlocked = readCategoryBooks.length >= achievement.requiredCount;
            } else if (achievement.specialBooks) {
                // Special books achievement
                unlocked = achievement.specialBooks.every(bookId => userData.books[bookId]);
            } else {
                // Count-based achievement
                unlocked = readBooks.length >= achievement.requiredCount;
            }
            
            // Update achievement status
            achievement.unlocked = unlocked;
            
            // Check if this is newly unlocked
            if (unlocked && !previouslyUnlocked[achievement.id]) {
                newlyUnlocked.push(achievement);
                previouslyUnlocked[achievement.id] = {
                    unlockedAt: new Date().toISOString(),
                    name: achievement.name
                };
            }
            
            // Update badge appearance
            updateBadgeAppearance(achievement, unlocked, newlyUnlocked.includes(achievement));
        });
        
        // Save achievements to user data
        userData.achievements = previouslyUnlocked;
        storeData(userData);
        
        // Show notification for newly unlocked achievements
        if (newlyUnlocked.length > 0) {
            showAchievementNotification(newlyUnlocked);
        }
    }
    
    function updateBadgeAppearance(achievement, unlocked, isNew) {
        const badgeElement = document.getElementById(`badge-${achievement.id}`);
        if (!badgeElement) return;
        
        if (unlocked) {
            badgeElement.classList.remove('locked');
            badgeElement.classList.add('achievement-unlocked');
            
            // Remove lock icon
            const lockIcon = badgeElement.querySelector('.badge-lock');
            if (lockIcon) {
                lockIcon.remove();
            }
            
            // Add new badge notification if it's newly unlocked
            if (isNew) {
                const notification = document.createElement('div');
                notification.className = 'new-badge-notification';
                notification.textContent = '!';
                badgeElement.appendChild(notification);
                
                // Auto-expand achievements section when new badge is unlocked
                const achievementsContent = document.getElementById('achievements-content');
                const toggleButton = document.querySelector('.achievements-toggle');
                
                if (achievementsContent && toggleButton) {
                    achievementsContent.className = 'achievements-content expanded';
                    toggleButton.textContent = 'Hide Badges';
                    toggleButton.setAttribute('aria-expanded', 'true');
                }
            }
        } else {
            badgeElement.classList.add('locked');
            badgeElement.classList.remove('achievement-unlocked');
            
            // Make sure lock icon exists
            if (!badgeElement.querySelector('.badge-lock')) {
                const lock = document.createElement('div');
                lock.className = 'badge-lock';
                lock.textContent = '🔒';
                badgeElement.appendChild(lock);
            }
        }
    }
    
    function showAchievementNotification(newAchievements) {
        if (newAchievements.length === 0) return;
        
        const messageBox = document.getElementById('message-box');
        if (!messageBox) return;
        
        let message = '';
        
        if (newAchievements.length === 1) {
            message = `🏆 Achievement Unlocked: "${newAchievements[0].name}"!`;
        } else {
            message = `🏆 ${newAchievements.length} New Achievements Unlocked!`;
        }
        
        messageBox.textContent = message;
        messageBox.className = 'success';
        messageBox.style.display = 'block';
        
        // Hide message after 5 seconds
        setTimeout(() => {
            messageBox.style.display = 'none';
        }, 5000);
    }
    
    function getStoredData() {
        const storedData = localStorage.getItem(STORAGE_KEY);
        return storedData ? JSON.parse(storedData) : null;
    }
    
    function storeData(data) {
        localStorage.setItem(STORAGE_KEY, JSON.stringify(data));
    }
});