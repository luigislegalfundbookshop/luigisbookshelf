// Book Covers API Integration
document.addEventListener('DOMContentLoaded', function() {
    // Specific book cover overrides for problematic titles - using direct Bookshop.org links
    const bookOverrides = {
        "Predictably Irrational": "https://images-us.bookshop.org/ingram/9780061353246.jpg?height=500&v=v2",
        "What's Our Problem?": "https://waitbutwhy.com/wp-content/uploads/2023/02/WOP-3D-Cover-for-Website.png",
        "Shoe Dog": "https://images-us.bookshop.org/ingram/9781501135927.jpg?height=500&v=v2",
        "1984": "https://images-us.bookshop.org/ingram/9780451524935.jpg?height=500&v=v2"
    };
    
    // Get all book entries
    const bookEntries = document.querySelectorAll('.book-entry');
    
    // Process each book entry
    bookEntries.forEach(function(bookEntry) {
        const titleElement = bookEntry.querySelector('.book-title');
        const authorElement = bookEntry.querySelector('.book-author');
        const coverElement = bookEntry.querySelector('.book-cover img');
        const coverContainer = bookEntry.querySelector('.book-cover');
        
        if (titleElement && authorElement && coverElement && coverContainer) {
            const title = titleElement.textContent;
            // Extract author name without "by " prefix
            const author = authorElement.textContent.replace('by ', '').trim();
            
            // Add title as data attribute for fallback
            coverContainer.setAttribute('data-title', title);
            
            // Add loading state
            coverContainer.classList.add('loading');
            
            // Check if this book has an override
            if (bookOverrides[title]) {
                console.log(`Using override for ${title}: ${bookOverrides[title]}`);
                // Use the override image directly
                coverElement.src = bookOverrides[title];
                coverElement.onload = function() {
                    coverContainer.classList.remove('loading');
                };
                coverElement.onerror = function() {
                    coverContainer.classList.add('no-cover');
                    console.error(`Failed to load override image for ${title}`);
                };
            } else {
                // Get book cover from Google Books API
                fetchBookCover(title, author, coverElement, coverContainer);
            }
        }
    });
    
    /**
     * Fetch book cover from Google Books API
     * @param {string} title - Book title
     * @param {string} author - Book author
     * @param {HTMLImageElement} imgElement - Image element to update
     * @param {HTMLElement} containerElement - Container element for the image
     */
    function fetchBookCover(title, author, imgElement, containerElement) {
        // Store original src as fallback
        const originalSrc = imgElement.src;
        
        // Create search query
        const query = encodeURIComponent(`intitle:${title} inauthor:${author}`);
        const apiUrl = `https://www.googleapis.com/books/v1/volumes?q=${query}&maxResults=1`;
        
        fetch(apiUrl)
            .then(response => response.json())
            .then(data => {
                if (data.items && data.items.length > 0 && 
                    data.items[0].volumeInfo && 
                    data.items[0].volumeInfo.imageLinks) {
                    
                    // Get the thumbnail URL and modify for larger size
                    let coverUrl = data.items[0].volumeInfo.imageLinks.thumbnail;
                    
                    // Replace zoom parameter for larger image (if possible)
                    coverUrl = coverUrl.replace('zoom=1', 'zoom=2');
                    
                    // Update image source
                    imgElement.src = coverUrl;
                    imgElement.onload = function() {
                        containerElement.classList.remove('loading');
                    };
                    imgElement.onerror = function() {
                        tryOpenLibrary(title, author, imgElement, containerElement, originalSrc);
                    };
                } else {
                    // If no Google Books result, try Open Library
                    tryOpenLibrary(title, author, imgElement, containerElement, originalSrc);
                }
            })
            .catch(error => {
                console.error('Error fetching book cover:', error);
                // Try Open Library on error
                tryOpenLibrary(title, author, imgElement, containerElement, originalSrc);
            });
    }
    
    /**
     * Try to fetch book cover from Open Library as a backup
     */
    function tryOpenLibrary(title, author, imgElement, containerElement, originalSrc) {
        // Create a clean title for URL (remove special characters, lowercase)
        const cleanTitle = title.toLowerCase().replace(/[^a-z0-9]/g, '+');
        const cleanAuthor = author.toLowerCase().replace(/[^a-z0-9]/g, '+');
        
        // Open Library URL format
        const openLibraryUrl = `https://covers.openlibrary.org/b/title/${cleanTitle}-M.jpg`;
        
        // Update image source
        imgElement.src = openLibraryUrl;
        imgElement.onload = function() {
            // Check if this is a valid image (Open Library returns a 1x1 pixel for missing covers)
            if (imgElement.naturalWidth > 1 && imgElement.naturalHeight > 1) {
                containerElement.classList.remove('loading');
            } else {
                // Fall back to original image or placeholder
                fallbackToOriginal(imgElement, containerElement, originalSrc);
            }
        };
        imgElement.onerror = function() {
            // Fall back to original image or placeholder
            fallbackToOriginal(imgElement, containerElement, originalSrc);
        };
    }
    
    /**
     * Fall back to original image or placeholder
     */
    function fallbackToOriginal(imgElement, containerElement, originalSrc) {
        if (originalSrc && originalSrc !== 'undefined' && !originalSrc.includes('undefined')) {
            imgElement.src = originalSrc;
            imgElement.onload = function() {
                containerElement.classList.remove('loading');
            };
            imgElement.onerror = function() {
                containerElement.classList.add('no-cover');
                imgElement.style.display = 'none';
            };
        } else {
            // If no original source, use a placeholder
            containerElement.classList.remove('loading');
            containerElement.classList.add('no-cover');
        }
    }
});