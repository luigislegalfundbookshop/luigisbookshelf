# Luigi's Legal Fund Bookshop Reading List

## Overview

This package contains all files for the Luigi's Legal Fund Bookshop Reading List website, an exclusive curated reading list with personal book recommendations and reviews.

## Features

- **Exclusive Access System**: 50 unique access codes for personalized user experience
- **Curated Book Collection**: 18 carefully selected books across three categories
- **Personal Reviews**: Luigi's thoughtful reviews for select titles
- **Reading Progress Tracking**: Users can track which books they've read
- **Responsive Design**: Works on mobile, tablet, and desktop devices
- **Barnes & Noble Inspired Design**: Professional, clean aesthetic

## File Structure

```
/
├── index.html                  # Main HTML file
├── assets/
│   ├── css/
│   │   └── styles.css          # Main stylesheet
│   └── js/
│       ├── main.js             # Core functionality and access codes
│       └── book-covers.js      # Book cover image handling
├── docs/
│   ├── user_faq.md             # User FAQ guide
│   └── admin_guide.md          # Admin guide with access code management
└── README.md                   # This file
```

## Implementation Details

- **Access System**: Uses browser localStorage to remember authenticated users
- **Book Covers**: Fetches from Google Books API with Bookshop.org fallbacks
- **Progress Tracking**: Stores reading progress in browser localStorage
- **Responsive Design**: Adapts to all screen sizes with mobile-first approach

## Documentation

Two comprehensive guides are included:

1. **User FAQ** (`docs/user_faq.md`): Explains how to use the reading list, answers common questions, and provides troubleshooting tips for users

2. **Admin Guide** (`docs/admin_guide.md`): Provides detailed instructions for:
   - Managing and distributing access codes
   - Updating book information
   - Adding new books
   - Fixing book cover images
   - Troubleshooting common issues

## Access Information

- **Master Access Code:** luigi
- **Individual Access Codes:** 50 unique codes (see admin_guide.md for the complete list)

## Deployment

The website is designed to be deployed to any standard web hosting service. Simply upload all files maintaining the directory structure.

## Support

For any questions or issues, refer to the admin guide or contact the developer who implemented this solution.

---

*Created for Luigi's Legal Fund Bookshop - August 2025*