// Luigi's Legal Fund Bookshop Reading List - Main JavaScript

document.addEventListener('DOMContentLoaded', function() {
    // Constants
    const PASSWORD = "luigi"; // The password to access the reading list
    const STORAGE_KEY = "luigis_bookshop_data"; // Local storage key
    
    // DOM Elements
    const accessGate = document.getElementById('access-gate');
    const passportContent = document.getElementById('passport-content');
    const passwordInput = document.getElementById('password-input');
    const submitButton = document.getElementById('submit-button');
    const messageBox = document.getElementById('message-box');
    const progressFill = document.getElementById('progress-fill');
    const progressText = document.getElementById('progress-text');
    const userWelcome = document.getElementById('user-welcome');
    const welcomeMessage = document.getElementById('welcome-message');
    const bookCheckboxes = document.querySelectorAll('.book-checkbox');
    
    // Initialize
    initializeApp();
    
    // Event Listeners
    if (submitButton) {
        submitButton.addEventListener('click', validatePassword);
    }
    
    if (passwordInput) {
        passwordInput.addEventListener('keypress', function(e) {
            if (e.key === 'Enter') {
                validatePassword();
            }
        });
    }
    
    // Functions
    function initializeApp() {
        // Check if user has already entered the password
        const userData = getStoredData();
        
        if (userData && userData.authenticated) {
            showContent();
            loadUserProgress();
        }
        
        // Add event listeners to all book checkboxes
        bookCheckboxes.forEach(checkbox => {
            checkbox.addEventListener('change', updateProgress);
        });
    }
    
    function validatePassword() {
        const password = passwordInput.value.trim().toLowerCase();
        
        if (password === PASSWORD) {
            // Store authentication status
            const userData = getStoredData() || {};
            userData.authenticated = true;
            userData.books = userData.books || {};
            storeData(userData);
            
            // Show success message and content
            showMessage('Access granted! Welcome to Luigi\'s reading list.', 'success');
            setTimeout(showContent, 1000);
        } else {
            showMessage('Incorrect password. Please try again.', 'error');
            passwordInput.value = '';
            passwordInput.focus();
        }
    }
    
    function showContent() {
        accessGate.style.display = 'none';
        passportContent.style.display = 'block';
        userWelcome.style.display = 'block';
        
        // Set welcome message
        const userData = getStoredData();
        if (userData && userData.lastVisit) {
            const lastVisit = new Date(userData.lastVisit);
            welcomeMessage.textContent = `Welcome back! Your last visit was on ${lastVisit.toLocaleDateString()}.`;
        } else {
            welcomeMessage.textContent = 'Welcome to Luigi\'s reading list! This is your first visit.';
        }
        
        // Update last visit time
        userData.lastVisit = new Date().toISOString();
        storeData(userData);
    }
    
    function showMessage(message, type) {
        messageBox.textContent = message;
        messageBox.className = type;
        messageBox.style.display = 'block';
    }
    
    function updateProgress() {
        const userData = getStoredData() || { authenticated: true, books: {} };
        
        // Update book status in storage
        bookCheckboxes.forEach(checkbox => {
            const bookId = checkbox.getAttribute('data-book');
            userData.books[bookId] = checkbox.checked;
        });
        
        storeData(userData);
        loadUserProgress();
    }
    
    function loadUserProgress() {
        const userData = getStoredData();
        
        if (userData && userData.books) {
            // Set checkbox states
            bookCheckboxes.forEach(checkbox => {
                const bookId = checkbox.getAttribute('data-book');
                if (userData.books[bookId]) {
                    checkbox.checked = true;
                }
            });
            
            // Calculate and display progress
            const totalBooks = bookCheckboxes.length;
            const readBooks = Object.values(userData.books).filter(Boolean).length;
            const progressPercentage = (readBooks / totalBooks) * 100;
            
            progressFill.style.width = `${progressPercentage}%`;
            progressText.textContent = `Reading Progress: ${readBooks} of ${totalBooks} books (${Math.round(progressPercentage)}%)`;
        }
    }
    
    function getStoredData() {
        const storedData = localStorage.getItem(STORAGE_KEY);
        return storedData ? JSON.parse(storedData) : null;
    }
    
    function storeData(data) {
        localStorage.setItem(STORAGE_KEY, JSON.stringify(data));
    }
});