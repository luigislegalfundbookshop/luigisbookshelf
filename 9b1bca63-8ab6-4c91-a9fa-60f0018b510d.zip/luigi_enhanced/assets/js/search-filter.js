// Luigi's Bookshelf - Search and Filter

document.addEventListener('DOMContentLoaded', function() {
    // Initialize the search and filter functionality
    initSearchFilter();
    
    /**
     * Initialize the search and filter functionality
     */
    function initSearchFilter() {
        // Create search and filter container
        createSearchFilterContainer();
        
        // Set up event listeners
        setupEventListeners();
    }
    
    /**
     * Create the search and filter container
     */
    function createSearchFilterContainer() {
        // Get the passport content div
        const passportContent = document.getElementById('passport-content');
        if (!passportContent) return;
        
        // Create container
        const container = document.createElement('div');
        container.className = 'search-filter-container';
        
        // Create header
        const header = document.createElement('div');
        header.className = 'search-filter-header';
        
        const title = document.createElement('h2');
        title.className = 'search-filter-title';
        title.textContent = 'Search & Filter Books';
        
        const toggle = document.createElement('button');
        toggle.className = 'search-filter-toggle';
        toggle.innerHTML = '<span class="search-filter-toggle-text">Hide</span><span class="search-filter-toggle-icon">▼</span>';
        
        header.appendChild(title);
        header.appendChild(toggle);
        
        // Create content container
        const content = document.createElement('div');
        content.className = 'search-filter-content';
        
        // Create search bar
        const searchBar = document.createElement('div');
        searchBar.className = 'search-bar';
        
        const searchInput = document.createElement('input');
        searchInput.type = 'text';
        searchInput.className = 'search-input';
        searchInput.id = 'search-input';
        searchInput.placeholder = 'Search by title, author, or keyword...';
        
        const searchButton = document.createElement('button');
        searchButton.className = 'search-button';
        searchButton.id = 'search-button';
        searchButton.innerHTML = '<span class="search-button-icon">🔍</span>';
        searchButton.setAttribute('aria-label', 'Search');
        
        searchBar.appendChild(searchInput);
        searchBar.appendChild(searchButton);
        
        // Create filter options
        const filterOptions = document.createElement('div');
        filterOptions.className = 'filter-options';
        
        // Category filter
        const categoryGroup = document.createElement('div');
        categoryGroup.className = 'filter-group';
        
        const categoryLabel = document.createElement('label');
        categoryLabel.className = 'filter-label';
        categoryLabel.textContent = 'Category';
        
        const categorySelect = document.createElement('select');
        categorySelect.className = 'filter-select';
        categorySelect.id = 'category-filter';
        
        const categoryOptions = [
            { value: '', text: 'All Categories' },
            { value: 'science-philosophy', text: 'Science & Philosophy' },
            { value: 'memoir-biography', text: 'Memoir & Biography' },
            { value: 'fiction', text: 'Fiction' }
        ];
        
        categoryOptions.forEach(option => {
            const optionEl = document.createElement('option');
            optionEl.value = option.value;
            optionEl.textContent = option.text;
            categorySelect.appendChild(optionEl);
        });
        
        categoryGroup.appendChild(categoryLabel);
        categoryGroup.appendChild(categorySelect);
        
        // Read status filter
        const readStatusGroup = document.createElement('div');
        readStatusGroup.className = 'filter-group';
        
        const readStatusLabel = document.createElement('label');
        readStatusLabel.className = 'filter-label';
        readStatusLabel.textContent = 'Read Status';
        
        const readStatusSelect = document.createElement('select');
        readStatusSelect.className = 'filter-select';
        readStatusSelect.id = 'read-status-filter';
        
        const readStatusOptions = [
            { value: '', text: 'All Books' },
            { value: 'read', text: 'Read' },
            { value: 'unread', text: 'Unread' }
        ];
        
        readStatusOptions.forEach(option => {
            const optionEl = document.createElement('option');
            optionEl.value = option.value;
            optionEl.textContent = option.text;
            readStatusSelect.appendChild(optionEl);
        });
        
        readStatusGroup.appendChild(readStatusLabel);
        readStatusGroup.appendChild(readStatusSelect);
        
        // Rating filter
        const ratingGroup = document.createElement('div');
        ratingGroup.className = 'filter-group';
        
        const ratingLabel = document.createElement('label');
        ratingLabel.className = 'filter-label';
        ratingLabel.textContent = 'Your Rating';
        
        const ratingSelect = document.createElement('select');
        ratingSelect.className = 'filter-select';
        ratingSelect.id = 'rating-filter';
        
        const ratingOptions = [
            { value: '', text: 'Any Rating' },
            { value: '5', text: '5 Stars' },
            { value: '4', text: '4+ Stars' },
            { value: '3', text: '3+ Stars' },
            { value: '0', text: 'Unrated' }
        ];
        
        ratingOptions.forEach(option => {
            const optionEl = document.createElement('option');
            optionEl.value = option.value;
            optionEl.textContent = option.text;
            ratingSelect.appendChild(optionEl);
        });
        
        ratingGroup.appendChild(ratingLabel);
        ratingGroup.appendChild(ratingSelect);
        
        // Reading time filter
        const timeGroup = document.createElement('div');
        timeGroup.className = 'filter-group';
        
        const timeLabel = document.createElement('label');
        timeLabel.className = 'filter-label';
        timeLabel.textContent = 'Reading Time';
        
        const timeSelect = document.createElement('select');
        timeSelect.className = 'filter-select';
        timeSelect.id = 'time-filter';
        
        const timeOptions = [
            { value: '', text: 'Any Length' },
            { value: 'short', text: 'Short (< 5 hours)' },
            { value: 'medium', text: 'Medium (5-7 hours)' },
            { value: 'long', text: 'Long (> 7 hours)' }
        ];
        
        timeOptions.forEach(option => {
            const optionEl = document.createElement('option');
            optionEl.value = option.value;
            optionEl.textContent = option.text;
            timeSelect.appendChild(optionEl);
        });
        
        timeGroup.appendChild(timeLabel);
        timeGroup.appendChild(timeSelect);
        
        // Add filter groups to options
        filterOptions.appendChild(categoryGroup);
        filterOptions.appendChild(readStatusGroup);
        filterOptions.appendChild(ratingGroup);
        filterOptions.appendChild(timeGroup);
        
        // Filter actions
        const filterActions = document.createElement('div');
        filterActions.className = 'filter-actions';
        
        const resetButton = document.createElement('button');
        resetButton.className = 'filter-button secondary';
        resetButton.id = 'reset-filters';
        resetButton.textContent = 'Reset Filters';
        
        const applyButton = document.createElement('button');
        applyButton.className = 'filter-button';
        applyButton.id = 'apply-filters';
        applyButton.textContent = 'Apply Filters';
        
        filterActions.appendChild(resetButton);
        filterActions.appendChild(applyButton);
        
        // Active filters container
        const activeFilters = document.createElement('div');
        activeFilters.className = 'active-filters';
        activeFilters.id = 'active-filters';
        
        // Search results container
        const searchResults = document.createElement('div');
        searchResults.className = 'search-results';
        searchResults.id = 'search-results';
        searchResults.style.display = 'none';
        
        // Add elements to content
        content.appendChild(searchBar);
        content.appendChild(filterOptions);
        content.appendChild(filterActions);
        content.appendChild(activeFilters);
        content.appendChild(searchResults);
        
        // Add elements to container
        container.appendChild(header);
        container.appendChild(content);
        
        // Insert container at the top of the passport content
        passportContent.insertBefore(container, passportContent.firstChild);
    }
    
    /**
     * Set up event listeners for search and filter
     */
    function setupEventListeners() {
        // Toggle button
        const toggleButton = document.querySelector('.search-filter-toggle');
        const searchFilterContent = document.querySelector('.search-filter-content');
        
        if (toggleButton && searchFilterContent) {
            toggleButton.addEventListener('click', function() {
                const isCollapsed = searchFilterContent.classList.contains('collapsed');
                
                if (isCollapsed) {
                    searchFilterContent.classList.remove('collapsed');
                    toggleButton.classList.remove('collapsed');
                    toggleButton.querySelector('.search-filter-toggle-text').textContent = 'Hide';
                } else {
                    searchFilterContent.classList.add('collapsed');
                    toggleButton.classList.add('collapsed');
                    toggleButton.querySelector('.search-filter-toggle-text').textContent = 'Show';
                }
            });
        }
        
        // Search button
        const searchButton = document.getElementById('search-button');
        if (searchButton) {
            searchButton.addEventListener('click', performSearch);
        }
        
        // Search input (search on Enter key)
        const searchInput = document.getElementById('search-input');
        if (searchInput) {
            searchInput.addEventListener('keypress', function(e) {
                if (e.key === 'Enter') {
                    performSearch();
                }
            });
        }
        
        // Apply filters button
        const applyButton = document.getElementById('apply-filters');
        if (applyButton) {
            applyButton.addEventListener('click', performSearch);
        }
        
        // Reset filters button
        const resetButton = document.getElementById('reset-filters');
        if (resetButton) {
            resetButton.addEventListener('click', resetFilters);
        }
    }
    
    /**
     * Perform search based on input and filters
     */
    function performSearch() {
        // Get search query
        const searchQuery = document.getElementById('search-input').value.trim().toLowerCase();
        
        // Get filter values
        const categoryFilter = document.getElementById('category-filter').value;
        const readStatusFilter = document.getElementById('read-status-filter').value;
        const ratingFilter = document.getElementById('rating-filter').value;
        const timeFilter = document.getElementById('time-filter').value;
        
        // Get all books
        const books = getAllBooks();
        
        // Filter books
        const filteredBooks = books.filter(book => {
            // Search query filter
            if (searchQuery && !matchesSearchQuery(book, searchQuery)) {
                return false;
            }
            
            // Category filter
            if (categoryFilter && book.category !== categoryFilter) {
                return false;
            }
            
            // Read status filter
            if (readStatusFilter) {
                const userData = getStoredData() || { books: {} };
                const isRead = userData.books && userData.books[book.id];
                
                if (readStatusFilter === 'read' && !isRead) {
                    return false;
                }
                
                if (readStatusFilter === 'unread' && isRead) {
                    return false;
                }
            }
            
            // Rating filter
            if (ratingFilter) {
                const userData = getStoredData() || { ratings: {} };
                const rating = userData.ratings && userData.ratings[book.id];
                
                if (ratingFilter === '0' && rating) {
                    return false;
                }
                
                if (ratingFilter !== '0' && (!rating || rating < parseInt(ratingFilter))) {
                    return false;
                }
            }
            
            // Reading time filter
            if (timeFilter) {
                const readingTime = getBookReadingTime(book.id);
                
                if (timeFilter === 'short' && readingTime >= 300) { // 5 hours
                    return false;
                }
                
                if (timeFilter === 'medium' && (readingTime < 300 || readingTime > 420)) { // 5-7 hours
                    return false;
                }
                
                if (timeFilter === 'long' && readingTime <= 420) { // 7 hours
                    return false;
                }
            }
            
            return true;
        });
        
        // Display results
        displaySearchResults(filteredBooks, searchQuery);
        
        // Update active filters
        updateActiveFilters(searchQuery, categoryFilter, readStatusFilter, ratingFilter, timeFilter);
    }
    
    /**
     * Check if a book matches the search query
     */
    function matchesSearchQuery(book, query) {
        // Check title
        if (book.title.toLowerCase().includes(query)) {
            return true;
        }
        
        // Check author
        if (book.author.toLowerCase().includes(query)) {
            return true;
        }
        
        // Check summary
        if (book.summary && book.summary.toLowerCase().includes(query)) {
            return true;
        }
        
        // Check tags
        if (book.tags && book.tags.some(tag => tag.toLowerCase().includes(query))) {
            return true;
        }
        
        return false;
    }
    
    /**
     * Display search results
     */
    function displaySearchResults(books, searchQuery) {
        const resultsContainer = document.getElementById('search-results');
        if (!resultsContainer) return;
        
        // Clear previous results
        resultsContainer.innerHTML = '';
        
        // Create results header
        const header = document.createElement('div');
        header.className = 'search-results-header';
        
        const title = document.createElement('div');
        title.className = 'search-results-title';
        
        const count = document.createElement('span');
        count.className = 'search-results-count';
        count.textContent = `${books.length} book${books.length !== 1 ? 's' : ''} found`;
        
        title.textContent = searchQuery ? `Results for "${searchQuery}" ` : 'All Books ';
        title.appendChild(count);
        
        const sort = document.createElement('div');
        sort.className = 'search-results-sort';
        
        const sortLabel = document.createElement('span');
        sortLabel.className = 'sort-label';
        sortLabel.textContent = 'Sort by:';
        
        const sortSelect = document.createElement('select');
        sortSelect.className = 'sort-select';
        sortSelect.id = 'sort-select';
        
        const sortOptions = [
            { value: 'title-asc', text: 'Title (A-Z)' },
            { value: 'title-desc', text: 'Title (Z-A)' },
            { value: 'author-asc', text: 'Author (A-Z)' },
            { value: 'author-desc', text: 'Author (Z-A)' },
            { value: 'category', text: 'Category' }
        ];
        
        sortOptions.forEach(option => {
            const optionEl = document.createElement('option');
            optionEl.value = option.value;
            optionEl.textContent = option.text;
            sortSelect.appendChild(optionEl);
        });
        
        sortSelect.addEventListener('change', function() {
            sortSearchResults(books, this.value, searchQuery);
        });
        
        sort.appendChild(sortLabel);
        sort.appendChild(sortSelect);
        
        header.appendChild(title);
        header.appendChild(sort);
        
        // Create results list
        const resultsList = document.createElement('div');
        resultsList.className = 'search-results-list';
        
        if (books.length === 0) {
            // No results
            const noResults = document.createElement('div');
            noResults.className = 'search-no-results';
            noResults.textContent = 'No books found matching your search criteria.';
            resultsList.appendChild(noResults);
        } else {
            // Sort books by title (default)
            books.sort((a, b) => a.title.localeCompare(b.title));
            
            // Add each book
            books.forEach(book => {
                const resultItem = createSearchResultItem(book, searchQuery);
                resultsList.appendChild(resultItem);
            });
        }
        
        // Add elements to results container
        resultsContainer.appendChild(header);
        resultsContainer.appendChild(resultsList);
        
        // Show results container
        resultsContainer.style.display = 'block';
        
        // Hide book categories if we're showing search results
        const bookCategories = document.querySelector('.book-categories');
        if (bookCategories) {
            bookCategories.style.display = 'none';
        }
    }
    
    /**
     * Create a search result item
     */
    function createSearchResultItem(book, searchQuery) {
        const item = document.createElement('div');
        item.className = 'search-result-item';
        item.dataset.id = book.id;
        
        // Book cover
        const cover = document.createElement('div');
        cover.className = 'search-result-cover';
        
        // Find the book cover image from the existing book entries
        const bookEntry = document.querySelector(`.book-checkbox[data-book="${book.id}"]`);
        let coverUrl = '';
        
        if (bookEntry) {
            const bookCoverImg = bookEntry.closest('.book-entry').querySelector('.book-cover img');
            if (bookCoverImg) {
                coverUrl = bookCoverImg.src;
            }
        }
        
        const coverImg = document.createElement('img');
        coverImg.src = coverUrl || 'https://via.placeholder.com/150x200?text=No+Cover';
        coverImg.alt = `${book.title} cover`;
        cover.appendChild(coverImg);
        
        // Book details
        const details = document.createElement('div');
        details.className = 'search-result-details';
        
        const title = document.createElement('h3');
        title.className = 'search-result-title';
        title.innerHTML = highlightText(book.title, searchQuery);
        
        const author = document.createElement('p');
        author.className = 'search-result-author';
        author.innerHTML = `by ${highlightText(book.author, searchQuery)}`;
        
        const category = document.createElement('p');
        category.className = 'search-result-category';
        category.textContent = formatCategoryName(book.category);
        
        const summary = document.createElement('p');
        summary.className = 'search-result-summary';
        summary.innerHTML = highlightText(book.summary || 'No summary available.', searchQuery);
        
        const actions = document.createElement('div');
        actions.className = 'search-result-actions';
        
        const viewButton = document.createElement('a');
        viewButton.className = 'search-result-button';
        viewButton.textContent = 'View Book';
        viewButton.href = '#';
        viewButton.addEventListener('click', function(e) {
            e.preventDefault();
            viewBook(book.id);
        });
        
        actions.appendChild(viewButton);
        
        details.appendChild(title);
        details.appendChild(author);
        details.appendChild(category);
        details.appendChild(summary);
        details.appendChild(actions);
        
        // Add elements to the item
        item.appendChild(cover);
        item.appendChild(details);
        
        return item;
    }
    
    /**
     * Sort search results
     */
    function sortSearchResults(books, sortBy, searchQuery) {
        // Sort books
        switch (sortBy) {
            case 'title-asc':
                books.sort((a, b) => a.title.localeCompare(b.title));
                break;
            case 'title-desc':
                books.sort((a, b) => b.title.localeCompare(a.title));
                break;
            case 'author-asc':
                books.sort((a, b) => a.author.localeCompare(b.author));
                break;
            case 'author-desc':
                books.sort((a, b) => b.author.localeCompare(a.author));
                break;
            case 'category':
                books.sort((a, b) => a.category.localeCompare(b.category) || a.title.localeCompare(b.title));
                break;
            default:
                books.sort((a, b) => a.title.localeCompare(b.title));
        }
        
        // Redisplay results
        displaySearchResults(books, searchQuery);
    }
    
    /**
     * Update active filters display
     */
    function updateActiveFilters(searchQuery, category, readStatus, rating, time) {
        const activeFiltersContainer = document.getElementById('active-filters');
        if (!activeFiltersContainer) return;
        
        // Clear previous filters
        activeFiltersContainer.innerHTML = '';
        
        // Check if any filters are active
        const hasActiveFilters = searchQuery || category || readStatus || rating || time;
        
        if (!hasActiveFilters) {
            return;
        }
        
        // Add search query filter
        if (searchQuery) {
            addActiveFilter(activeFiltersContainer, `Search: "${searchQuery}"`, () => {
                document.getElementById('search-input').value = '';
                performSearch();
            });
        }
        
        // Add category filter
        if (category) {
            const categoryText = document.querySelector(`#category-filter option[value="${category}"]`).textContent;
            addActiveFilter(activeFiltersContainer, `Category: ${categoryText}`, () => {
                document.getElementById('category-filter').value = '';
                performSearch();
            });
        }
        
        // Add read status filter
        if (readStatus) {
            const readStatusText = document.querySelector(`#read-status-filter option[value="${readStatus}"]`).textContent;
            addActiveFilter(activeFiltersContainer, `Status: ${readStatusText}`, () => {
                document.getElementById('read-status-filter').value = '';
                performSearch();
            });
        }
        
        // Add rating filter
        if (rating) {
            const ratingText = document.querySelector(`#rating-filter option[value="${rating}"]`).textContent;
            addActiveFilter(activeFiltersContainer, `Rating: ${ratingText}`, () => {
                document.getElementById('rating-filter').value = '';
                performSearch();
            });
        }
        
        // Add time filter
        if (time) {
            const timeText = document.querySelector(`#time-filter option[value="${time}"]`).textContent;
            addActiveFilter(activeFiltersContainer, `Time: ${timeText}`, () => {
                document.getElementById('time-filter').value = '';
                performSearch();
            });
        }
    }
    
    /**
     * Add an active filter tag
     */
    function addActiveFilter(container, text, removeCallback) {
        const filter = document.createElement('div');
        filter.className = 'active-filter';
        
        const filterText = document.createElement('span');
        filterText.textContent = text;
        
        const removeButton = document.createElement('button');
        removeButton.className = 'active-filter-remove';
        removeButton.innerHTML = '×';
        removeButton.setAttribute('aria-label', `Remove ${text} filter`);
        removeButton.addEventListener('click', removeCallback);
        
        filter.appendChild(filterText);
        filter.appendChild(removeButton);
        container.appendChild(filter);
    }
    
    /**
     * Reset all filters
     */
    function resetFilters() {
        // Clear search input
        document.getElementById('search-input').value = '';
        
        // Reset filter selects
        document.getElementById('category-filter').value = '';
        document.getElementById('read-status-filter').value = '';
        document.getElementById('rating-filter').value = '';
        document.getElementById('time-filter').value = '';
        
        // Clear active filters
        const activeFiltersContainer = document.getElementById('active-filters');
        if (activeFiltersContainer) {
            activeFiltersContainer.innerHTML = '';
        }
        
        // Hide search results
        const resultsContainer = document.getElementById('search-results');
        if (resultsContainer) {
            resultsContainer.style.display = 'none';
        }
        
        // Show book categories
        const bookCategories = document.querySelector('.book-categories');
        if (bookCategories) {
            bookCategories.style.display = 'block';
        }
    }
    
    /**
     * View a book by scrolling to it and highlighting it
     */
    function viewBook(bookId) {
        // Hide search results
        const resultsContainer = document.getElementById('search-results');
        if (resultsContainer) {
            resultsContainer.style.display = 'none';
        }
        
        // Show book categories
        const bookCategories = document.querySelector('.book-categories');
        if (bookCategories) {
            bookCategories.style.display = 'block';
        }
        
        // Find the book element
        const bookEntry = document.querySelector(`.book-checkbox[data-book="${bookId}"]`);
        
        if (bookEntry) {
            const bookElement = bookEntry.closest('.book-entry');
            
            if (bookElement) {
                // Scroll to the book
                bookElement.scrollIntoView({ behavior: 'smooth', block: 'center' });
                
                // Highlight the book temporarily
                bookElement.style.transition = 'background-color 0.5s ease';
                bookElement.style.backgroundColor = '#fffde7';
                
                setTimeout(() => {
                    bookElement.style.backgroundColor = '';
                    setTimeout(() => {
                        bookElement.style.transition = '';
                    }, 500);
                }, 1500);
            }
        }
    }
    
    /**
     * Highlight search terms in text
     */
    function highlightText(text, searchQuery) {
        if (!searchQuery || !text) return text;
        
        const regex = new RegExp(`(${escapeRegExp(searchQuery)})`, 'gi');
        return text.replace(regex, '<span class="search-highlight">$1</span>');
    }
    
    /**
     * Escape special characters in a string for use in a regular expression
     */
    function escapeRegExp(string) {
        return string.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
    }
    
    /**
     * Format a category name for display
     */
    function formatCategoryName(category) {
        return category
            .split('-')
            .map(word => word.charAt(0).toUpperCase() + word.slice(1))
            .join(' & ');
    }
    
    /**
     * Get all books data
     */
    function getAllBooks() {
        // This would normally come from a database
        // For this implementation, we're hardcoding the book data
        return [
            // Science & Philosophy
            {
                id: 'ape-universe',
                title: 'The Ape that Understood the Universe',
                author: 'Steve Stewart-Williams',
                category: 'science-philosophy',
                summary: 'A compelling look at human behavior through evolutionary psychology and culture.',
                tags: ['psychology', 'evolution', 'human-behavior']
            },
            {
                id: 'code-book',
                title: 'The Code Book',
                author: 'Simon Singh',
                category: 'science-philosophy',
                summary: 'An engaging history of cryptography from ancient ciphers to quantum encryption.',
                tags: ['cryptography', 'mathematics', 'history']
            },
            {
                id: 'brief-answers',
                title: 'Brief Answers to the Big Questions',
                author: 'Stephen Hawking',
                category: 'science-philosophy',
                summary: 'Hawking\'s final book tackles some of the universe\'s biggest questions.',
                tags: ['physics', 'cosmology', 'philosophy']
            },
            {
                id: 'sapiens',
                title: 'Sapiens',
                author: 'Yuval Noah Harari',
                category: 'science-philosophy',
                summary: 'A brief history of humankind, exploring the ways in which biology and history have defined us.',
                tags: ['history', 'anthropology', 'evolution']
            },
            {
                id: 'thinking-fast-slow',
                title: 'Thinking, Fast and Slow',
                author: 'Daniel Kahneman',
                category: 'science-philosophy',
                summary: 'An exploration of the two systems that drive the way we think and make choices.',
                tags: ['psychology', 'decision-making', 'behavioral-economics']
            },
            {
                id: 'why-we-sleep',
                title: 'Why We Sleep',
                author: 'Matthew Walker',
                category: 'science-philosophy',
                summary: 'A fascinating dive into the science of sleep and dreams.',
                tags: ['neuroscience', 'health', 'psychology']
            },
            
            // Memoir & Biography
            {
                id: 'educated',
                title: 'Educated',
                author: 'Tara Westover',
                category: 'memoir-biography',
                summary: 'A memoir about a woman who leaves her survivalist family and goes on to earn a PhD.',
                tags: ['memoir', 'education', 'family']
            },
            {
                id: 'becoming',
                title: 'Becoming',
                author: 'Michelle Obama',
                category: 'memoir-biography',
                summary: 'The former First Lady\'s memoir about her life journey from Chicago to the White House.',
                tags: ['memoir', 'politics', 'leadership']
            },
            {
                id: 'born-crime',
                title: 'Born a Crime',
                author: 'Trevor Noah',
                category: 'memoir-biography',
                summary: 'Stories from Trevor Noah\'s South African childhood during the twilight of apartheid.',
                tags: ['memoir', 'comedy', 'south-africa']
            },
            {
                id: 'shoe-dog',
                title: 'Shoe Dog',
                author: 'Phil Knight',
                category: 'memoir-biography',
                summary: 'A memoir by the creator of Nike about building the world\'s most innovative brand.',
                tags: ['business', 'entrepreneurship', 'sports']
            },
            {
                id: 'elon-musk',
                title: 'Elon Musk',
                author: 'Walter Isaacson',
                category: 'memoir-biography',
                summary: 'A biography of the entrepreneur behind Tesla, SpaceX, and more.',
                tags: ['business', 'technology', 'entrepreneurship']
            },
            {
                id: 'greenlights',
                title: 'Greenlights',
                author: 'Matthew McConaughey',
                category: 'memoir-biography',
                summary: 'The actor shares his unconventional wisdom and lessons learned the hard way.',
                tags: ['memoir', 'entertainment', 'philosophy']
            },
            
            // Fiction
            {
                id: 'project-hail-mary',
                title: 'Project Hail Mary',
                author: 'Andy Weir',
                category: 'fiction',
                summary: 'A lone astronaut must save humanity from an extinction-level threat.',
                tags: ['science-fiction', 'space', 'adventure']
            },
            {
                id: 'midnight-library',
                title: 'The Midnight Library',
                author: 'Matt Haig',
                category: 'fiction',
                summary: 'A library beyond the edge of the universe contains books with all the different lives you could have lived.',
                tags: ['fantasy', 'philosophy', 'life-choices']
            },
            {
                id: 'invisible-life',
                title: 'The Invisible Life of Addie LaRue',
                author: 'V.E. Schwab',
                category: 'fiction',
                summary: 'A young woman makes a Faustian bargain to live forever but is cursed to be forgotten by everyone she meets.',
                tags: ['fantasy', 'historical-fiction', 'romance']
            },
            {
                id: 'circe',
                title: 'Circe',
                author: 'Madeline Miller',
                category: 'fiction',
                summary: 'A bold and subversive retelling of the goddess\'s story from Homer\'s Odyssey.',
                tags: ['mythology', 'fantasy', 'historical-fiction']
            },
            {
                id: 'brave-new-world',
                title: 'Brave New World',
                author: 'Aldous Huxley',
                category: 'fiction',
                summary: 'A dystopian novel set in a futuristic World State of genetically modified citizens.',
                tags: ['dystopian', 'classic', 'science-fiction']
            },
            {
                id: '1984',
                title: '1984',
                author: 'George Orwell',
                category: 'fiction',
                summary: 'A dystopian social science fiction novel and cautionary tale about totalitarianism.',
                tags: ['dystopian', 'classic', 'political-fiction']
            }
        ];
    }
    
    /**
     * Get reading time for a book
     */
    function getBookReadingTime(bookId) {
        // Book reading time data (in minutes)
        const bookReadingTimes = {
            // Science & Philosophy
            'ape-universe': 240, // 4 hours
            'code-book': 360, // 6 hours
            'brief-answers': 180, // 3 hours
            'sapiens': 480, // 8 hours
            'thinking-fast-slow': 540, // 9 hours
            'why-we-sleep': 300, // 5 hours
            
            // Memoir & Biography
            'educated': 330, // 5.5 hours
            'becoming': 420, // 7 hours
            'born-crime': 270, // 4.5 hours
            'shoe-dog': 300, // 5 hours
            'elon-musk': 480, // 8 hours
            'greenlights': 270, // 4.5 hours
            
            // Fiction
            'project-hail-mary': 390, // 6.5 hours
            'midnight-library': 270, // 4.5 hours
            'invisible-life': 330, // 5.5 hours
            'circe': 360, // 6 hours
            'brave-new-world': 240, // 4 hours
            '1984': 270 // 4.5 hours
        };
        
        return bookReadingTimes[bookId] || 300; // Default to 5 hours if not found
    }
    
    /**
     * Get stored user data from localStorage
     */
    function getStoredData() {
        const STORAGE_KEY = "luigis_bookshop_data";
        const storedData = localStorage.getItem(STORAGE_KEY);
        return storedData ? JSON.parse(storedData) : null;
    }
});