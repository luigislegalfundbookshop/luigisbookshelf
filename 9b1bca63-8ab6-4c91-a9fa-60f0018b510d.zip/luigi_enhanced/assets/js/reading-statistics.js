// Luigi's Bookshelf - Reading Statistics

document.addEventListener('DOMContentLoaded', function() {
    // Constants
    const STORAGE_KEY = "luigis_bookshop_data";
    const STATS_KEY = "reading_stats";
    const MS_PER_DAY = 86400000; // Milliseconds in a day
    
    // Initialize the reading statistics
    initReadingStatistics();
    
    /**
     * Initialize the reading statistics functionality
     */
    function initReadingStatistics() {
        // Create statistics section
        createStatisticsSection();
        
        // Set up event listeners
        setupEventListeners();
        
        // Track reading activity for today
        trackReadingActivity();
    }
    
    /**
     * Create the statistics section
     */
    function createStatisticsSection() {
        // Get the passport content div
        const passportContent = document.getElementById('passport-content');
        if (!passportContent) return;
        
        // Find where to insert the statistics section
        // We'll put it after the search filter or reading progress
        let insertAfter = document.querySelector('.search-filter-container');
        if (!insertAfter) {
            insertAfter = document.querySelector('.reading-progress');
        }
        if (!insertAfter) return;
        
        // Create container
        const container = document.createElement('div');
        container.className = 'statistics-section';
        
        // Create header
        const header = document.createElement('div');
        header.className = 'statistics-header';
        
        const title = document.createElement('h2');
        title.className = 'statistics-title';
        title.textContent = 'Reading Statistics';
        
        const toggle = document.createElement('button');
        toggle.className = 'statistics-toggle';
        toggle.innerHTML = '<span class="statistics-toggle-text">Hide</span><span class="statistics-toggle-icon">▼</span>';
        
        header.appendChild(title);
        header.appendChild(toggle);
        
        // Create content container
        const content = document.createElement('div');
        content.className = 'statistics-content';
        
        // Create time period selector
        const timePeriod = document.createElement('div');
        timePeriod.className = 'statistics-time-period';
        
        const weekButton = document.createElement('button');
        weekButton.className = 'statistics-time-button active';
        weekButton.dataset.period = 'week';
        weekButton.textContent = 'Week';
        
        const monthButton = document.createElement('button');
        monthButton.className = 'statistics-time-button';
        monthButton.dataset.period = 'month';
        monthButton.textContent = 'Month';
        
        const yearButton = document.createElement('button');
        yearButton.className = 'statistics-time-button';
        yearButton.dataset.period = 'year';
        yearButton.textContent = 'Year';
        
        const allTimeButton = document.createElement('button');
        allTimeButton.className = 'statistics-time-button';
        allTimeButton.dataset.period = 'all';
        allTimeButton.textContent = 'All Time';
        
        timePeriod.appendChild(weekButton);
        timePeriod.appendChild(monthButton);
        timePeriod.appendChild(yearButton);
        timePeriod.appendChild(allTimeButton);
        
        // Create dashboard
        const dashboard = document.createElement('div');
        dashboard.className = 'statistics-dashboard';
        dashboard.id = 'statistics-dashboard';
        
        // Create charts container
        const chartsContainer = document.createElement('div');
        chartsContainer.id = 'statistics-charts';
        
        // Add elements to content
        content.appendChild(timePeriod);
        content.appendChild(dashboard);
        content.appendChild(chartsContainer);
        
        // Add elements to container
        container.appendChild(header);
        container.appendChild(content);
        
        // Insert after the target element
        insertAfter.parentNode.insertBefore(container, insertAfter.nextSibling);
        
        // Generate initial statistics
        generateStatistics('week');
    }
    
    /**
     * Set up event listeners
     */
    function setupEventListeners() {
        // Toggle button
        const toggleButton = document.querySelector('.statistics-toggle');
        const statisticsContent = document.querySelector('.statistics-content');
        
        if (toggleButton && statisticsContent) {
            toggleButton.addEventListener('click', function() {
                const isCollapsed = statisticsContent.classList.contains('collapsed');
                
                if (isCollapsed) {
                    statisticsContent.classList.remove('collapsed');
                    toggleButton.classList.remove('collapsed');
                    toggleButton.querySelector('.statistics-toggle-text').textContent = 'Hide';
                } else {
                    statisticsContent.classList.add('collapsed');
                    toggleButton.classList.add('collapsed');
                    toggleButton.querySelector('.statistics-toggle-text').textContent = 'Show';
                }
            });
        }
        
        // Time period buttons
        const timeButtons = document.querySelectorAll('.statistics-time-button');
        
        timeButtons.forEach(button => {
            button.addEventListener('click', function() {
                // Remove active class from all buttons
                timeButtons.forEach(btn => btn.classList.remove('active'));
                
                // Add active class to clicked button
                this.classList.add('active');
                
                // Generate statistics for selected period
                generateStatistics(this.dataset.period);
            });
        });
    }
    
    /**
     * Track reading activity for today
     */
    function trackReadingActivity() {
        // Get stored data
        const userData = getStoredData() || {};
        
        // Initialize reading stats if needed
        if (!userData[STATS_KEY]) {
            userData[STATS_KEY] = {
                activityDates: [],
                booksCompletedDates: {},
                lastVisit: null
            };
        }
        
        // Get today's date (YYYY-MM-DD format)
        const today = new Date().toISOString().split('T')[0];
        
        // Record today's visit
        if (!userData[STATS_KEY].activityDates.includes(today)) {
            userData[STATS_KEY].activityDates.push(today);
        }
        
        // Record last visit
        userData[STATS_KEY].lastVisit = new Date().toISOString();
        
        // Save data
        storeData(userData);
        
        // Set up event listener for book checkboxes to track completions
        const bookCheckboxes = document.querySelectorAll('.book-checkbox');
        
        bookCheckboxes.forEach(checkbox => {
            checkbox.addEventListener('change', function() {
                if (this.checked) {
                    // Book was marked as read
                    recordBookCompletion(this.getAttribute('data-book'));
                }
            });
        });
    }
    
    /**
     * Record when a book is completed
     */
    function recordBookCompletion(bookId) {
        // Get stored data
        const userData = getStoredData() || {};
        
        // Initialize reading stats if needed
        if (!userData[STATS_KEY]) {
            userData[STATS_KEY] = {
                activityDates: [],
                booksCompletedDates: {},
                lastVisit: null
            };
        }
        
        // Check if this book was already recorded
        if (!userData[STATS_KEY].booksCompletedDates[bookId]) {
            // Get today's date (YYYY-MM-DD format)
            const today = new Date().toISOString().split('T')[0];
            
            // Record completion date
            userData[STATS_KEY].booksCompletedDates[bookId] = today;
            
            // Save data
            storeData(userData);
            
            // Update statistics
            const activePeriod = document.querySelector('.statistics-time-button.active').dataset.period;
            generateStatistics(activePeriod);
        }
    }
    
    /**
     * Generate statistics for the selected time period
     */
    function generateStatistics(period) {
        // Get stored data
        const userData = getStoredData() || {};
        
        // Get reading stats
        const readingStats = userData[STATS_KEY] || {
            activityDates: [],
            booksCompletedDates: {},
            lastVisit: null
        };
        
        // Calculate date range for the selected period
        const dateRange = getDateRange(period);
        
        // Generate dashboard statistics
        generateDashboardStats(readingStats, dateRange);
        
        // Generate charts
        generateCharts(readingStats, dateRange, period);
    }
    
    /**
     * Generate dashboard statistics
     */
    function generateDashboardStats(readingStats, dateRange) {
        const dashboard = document.getElementById('statistics-dashboard');
        if (!dashboard) return;
        
        // Clear previous stats
        dashboard.innerHTML = '';
        
        // Calculate statistics
        const stats = calculateStats(readingStats, dateRange);
        
        // Create cards
        
        // Books completed card
        const booksCompletedCard = createStatCard(
            '📚',
            'Books Completed',
            stats.booksCompleted,
            `${stats.booksCompleted} book${stats.booksCompleted !== 1 ? 's' : ''} finished in this period`
        );
        dashboard.appendChild(booksCompletedCard);
        
        // Reading streak card
        const readingStreakCard = createStatCard(
            '🔥',
            'Current Streak',
            `${stats.currentStreak}`,
            `${stats.currentStreak} day${stats.currentStreak !== 1 ? 's' : ''} of continuous activity`
        );
        dashboard.appendChild(readingStreakCard);
        
        // Reading time card
        const readingTimeCard = createStatCard(
            '⏱️',
            'Reading Time',
            formatReadingTime(stats.readingTime),
            'Estimated time spent reading'
        );
        dashboard.appendChild(readingTimeCard);
        
        // Completion rate card
        const completionRateCard = createStatCard(
            '📈',
            'Completion Rate',
            `${stats.completionRate}%`,
            `${stats.booksCompleted} of ${stats.totalBooks} books in collection`
        );
        dashboard.appendChild(completionRateCard);
    }
    
    /**
     * Create a statistic card
     */
    function createStatCard(icon, title, value, description) {
        const card = document.createElement('div');
        card.className = 'statistics-card';
        
        const header = document.createElement('div');
        header.className = 'statistics-card-header';
        
        const iconEl = document.createElement('span');
        iconEl.className = 'statistics-card-icon';
        iconEl.textContent = icon;
        
        const titleEl = document.createElement('h3');
        titleEl.className = 'statistics-card-title';
        titleEl.textContent = title;
        
        header.appendChild(iconEl);
        header.appendChild(titleEl);
        
        const valueEl = document.createElement('div');
        valueEl.className = 'statistics-card-value';
        valueEl.textContent = value;
        
        const descriptionEl = document.createElement('p');
        descriptionEl.className = 'statistics-card-description';
        descriptionEl.textContent = description;
        
        card.appendChild(header);
        card.appendChild(valueEl);
        card.appendChild(descriptionEl);
        
        return card;
    }
    
    /**
     * Generate charts for the statistics
     */
    function generateCharts(readingStats, dateRange, period) {
        const chartsContainer = document.getElementById('statistics-charts');
        if (!chartsContainer) return;
        
        // Clear previous charts
        chartsContainer.innerHTML = '';
        
        // Create reading activity chart
        const activityChartContainer = document.createElement('div');
        activityChartContainer.className = 'statistics-chart-container';
        
        const activityChartHeader = document.createElement('div');
        activityChartHeader.className = 'statistics-chart-header';
        
        const activityChartTitle = document.createElement('h3');
        activityChartTitle.className = 'statistics-chart-title';
        activityChartTitle.textContent = 'Reading Activity';
        
        activityChartHeader.appendChild(activityChartTitle);
        
        const activityChart = document.createElement('div');
        activityChart.className = 'statistics-chart';
        activityChart.id = 'activity-chart';
        
        activityChartContainer.appendChild(activityChartHeader);
        activityChartContainer.appendChild(activityChart);
        
        // Create category distribution chart
        const categoryChartContainer = document.createElement('div');
        categoryChartContainer.className = 'statistics-chart-container';
        
        const categoryChartHeader = document.createElement('div');
        categoryChartHeader.className = 'statistics-chart-header';
        
        const categoryChartTitle = document.createElement('h3');
        categoryChartTitle.className = 'statistics-chart-title';
        categoryChartTitle.textContent = 'Books by Category';
        
        categoryChartHeader.appendChild(categoryChartTitle);
        
        const categoryChart = document.createElement('div');
        categoryChart.className = 'statistics-chart';
        categoryChart.id = 'category-chart';
        
        categoryChartContainer.appendChild(categoryChartHeader);
        categoryChartContainer.appendChild(categoryChart);
        
        // Add charts to container
        chartsContainer.appendChild(activityChartContainer);
        chartsContainer.appendChild(categoryChartContainer);
        
        // Generate chart data
        renderActivityChart(readingStats, dateRange, period);
        renderCategoryChart(readingStats, dateRange);
    }
    
    /**
     * Render the reading activity chart
     */
    function renderActivityChart(readingStats, dateRange, period) {
        const chartContainer = document.getElementById('activity-chart');
        if (!chartContainer) return;
        
        // Clear previous chart
        chartContainer.innerHTML = '';
        
        // Create bar chart
        const barChart = document.createElement('div');
        barChart.className = 'bar-chart';
        
        // Get activity data for the date range
        const activityData = getActivityData(readingStats, dateRange, period);
        
        if (activityData.labels.length === 0) {
            // No data
            const emptyMessage = document.createElement('div');
            emptyMessage.className = 'statistics-empty';
            emptyMessage.textContent = 'No reading activity data available for this period.';
            chartContainer.appendChild(emptyMessage);
            return;
        }
        
        // Find the maximum value for scaling
        const maxValue = Math.max(...activityData.values, 1);
        
        // Create bars
        activityData.labels.forEach((label, index) => {
            const value = activityData.values[index];
            const heightPercentage = (value / maxValue) * 100;
            
            const bar = document.createElement('div');
            bar.className = 'bar-chart-bar';
            bar.style.height = `${heightPercentage}%`;
            
            const barLabel = document.createElement('div');
            barLabel.className = 'bar-chart-bar-label';
            barLabel.textContent = label;
            
            const barValue = document.createElement('div');
            barValue.className = 'bar-chart-bar-value';
            barValue.textContent = value;
            
            bar.appendChild(barLabel);
            if (value > 0) {
                bar.appendChild(barValue);
            }
            
            barChart.appendChild(bar);
        });
        
        chartContainer.appendChild(barChart);
    }
    
    /**
     * Render the category distribution chart
     */
    function renderCategoryChart(readingStats, dateRange) {
        const chartContainer = document.getElementById('category-chart');
        if (!chartContainer) return;
        
        // Clear previous chart
        chartContainer.innerHTML = '';
        
        // Get category data
        const categoryData = getCategoryData(readingStats, dateRange);
        
        if (categoryData.labels.length === 0) {
            // No data
            const emptyMessage = document.createElement('div');
            emptyMessage.className = 'statistics-empty';
            emptyMessage.textContent = 'No category data available for this period.';
            chartContainer.appendChild(emptyMessage);
            return;
        }
        
        // Create pie chart container
        const pieChartContainer = document.createElement('div');
        pieChartContainer.style.display = 'flex';
        pieChartContainer.style.flexDirection = 'column';
        pieChartContainer.style.alignItems = 'center';
        
        // Create pie chart
        const pieChart = document.createElement('div');
        pieChart.className = 'pie-chart';
        
        // Colors for categories
        const colors = ['#4a6fa5', '#4CAF50', '#FFC107'];
        
        // Create slices
        let startAngle = 0;
        
        categoryData.values.forEach((value, index) => {
            const percentage = value / categoryData.total;
            const degrees = percentage * 360;
            
            const slice = document.createElement('div');
            slice.className = 'pie-chart-slice';
            slice.style.backgroundColor = colors[index % colors.length];
            slice.style.transform = `rotate(${startAngle}deg)`;
            slice.style.clipPath = `polygon(50% 50%, 50% 0%, ${degrees > 180 ? '0% 0%, 0% 100%, 100% 100%, 100% 0%' : '100% 0%'}, 50% 0%)`;
            
            if (degrees > 180) {
                // Create a second slice for angles > 180 degrees
                const secondSlice = document.createElement('div');
                secondSlice.className = 'pie-chart-slice';
                secondSlice.style.backgroundColor = colors[index % colors.length];
                secondSlice.style.transform = `rotate(${startAngle + 180}deg)`;
                secondSlice.style.clipPath = `polygon(50% 50%, 50% 0%, ${degrees > 270 ? '0% 0%, 0% 100%, 100% 100%, 100% 0%' : '100% 0%'}, 50% 0%)`;
                
                pieChart.appendChild(secondSlice);
            }
            
            pieChart.appendChild(slice);
            startAngle += degrees;
        });
        
        // Create legend
        const legend = document.createElement('div');
        legend.className = 'pie-chart-legend';
        
        categoryData.labels.forEach((label, index) => {
            const legendItem = document.createElement('div');
            legendItem.className = 'pie-chart-legend-item';
            
            const colorBox = document.createElement('div');
            colorBox.className = 'pie-chart-legend-color';
            colorBox.style.backgroundColor = colors[index % colors.length];
            
            const labelText = document.createElement('span');
            labelText.textContent = `${label} (${categoryData.values[index]})`;
            
            legendItem.appendChild(colorBox);
            legendItem.appendChild(labelText);
            legend.appendChild(legendItem);
        });
        
        pieChartContainer.appendChild(pieChart);
        pieChartContainer.appendChild(legend);
        chartContainer.appendChild(pieChartContainer);
    }
    
    /**
     * Calculate statistics for the given period
     */
    function calculateStats(readingStats, dateRange) {
        // Get all books
        const allBooks = getAllBooks();
        const totalBooks = allBooks.length;
        
        // Get user data
        const userData = getStoredData() || { books: {} };
        
        // Count books completed in the date range
        let booksCompleted = 0;
        let readingTime = 0;
        
        Object.keys(readingStats.booksCompletedDates || {}).forEach(bookId => {
            const completionDate = readingStats.booksCompletedDates[bookId];
            
            // Check if completion date is within range
            if (isDateInRange(completionDate, dateRange.start, dateRange.end)) {
                booksCompleted++;
                
                // Add reading time
                readingTime += getBookReadingTime(bookId);
            }
        });
        
        // Calculate completion rate
        const totalCompleted = Object.keys(userData.books || {}).filter(id => userData.books[id]).length;
        const completionRate = Math.round((totalCompleted / totalBooks) * 100);
        
        // Calculate current streak
        const currentStreak = calculateCurrentStreak(readingStats.activityDates);
        
        return {
            booksCompleted,
            readingTime,
            completionRate,
            currentStreak,
            totalBooks
        };
    }
    
    /**
     * Get activity data for the chart
     */
    function getActivityData(readingStats, dateRange, period) {
        const labels = [];
        const values = [];
        
        // Format depends on the period
        switch (period) {
            case 'week':
                // Daily data for the week
                const days = ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'];
                
                // Create array of dates in the range
                const weekDates = [];
                let currentDate = new Date(dateRange.start);
                
                while (currentDate <= new Date(dateRange.end)) {
                    weekDates.push(currentDate.toISOString().split('T')[0]);
                    currentDate.setDate(currentDate.getDate() + 1);
                }
                
                // Count books completed on each day
                weekDates.forEach(date => {
                    const dayOfWeek = new Date(date).getDay();
                    labels.push(days[dayOfWeek]);
                    
                    // Count books completed on this day
                    let count = 0;
                    Object.values(readingStats.booksCompletedDates || {}).forEach(completionDate => {
                        if (completionDate === date) {
                            count++;
                        }
                    });
                    
                    values.push(count);
                });
                break;
                
            case 'month':
                // Weekly data for the month
                const weeks = ['Week 1', 'Week 2', 'Week 3', 'Week 4', 'Week 5'];
                
                // Create array of week ranges
                const monthStart = new Date(dateRange.start);
                const weekRanges = [];
                
                for (let i = 0; i < 5; i++) {
                    const weekStart = new Date(monthStart);
                    weekStart.setDate(monthStart.getDate() + (i * 7));
                    
                    const weekEnd = new Date(weekStart);
                    weekEnd.setDate(weekStart.getDate() + 6);
                    
                    // Only include weeks that overlap with the date range
                    if (weekStart <= new Date(dateRange.end)) {
                        weekRanges.push({
                            start: weekStart.toISOString().split('T')[0],
                            end: weekEnd.toISOString().split('T')[0],
                            label: weeks[i]
                        });
                    }
                }
                
                // Count books completed in each week
                weekRanges.forEach(week => {
                    labels.push(week.label);
                    
                    // Count books completed in this week
                    let count = 0;
                    Object.values(readingStats.booksCompletedDates || {}).forEach(completionDate => {
                        if (isDateInRange(completionDate, week.start, week.end)) {
                            count++;
                        }
                    });
                    
                    values.push(count);
                });
                break;
                
            case 'year':
                // Monthly data for the year
                const months = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
                
                // Create array of month ranges
                const yearStart = new Date(dateRange.start);
                const monthRanges = [];
                
                for (let i = 0; i < 12; i++) {
                    const monthStart = new Date(yearStart.getFullYear(), yearStart.getMonth() + i, 1);
                    const monthEnd = new Date(yearStart.getFullYear(), yearStart.getMonth() + i + 1, 0);
                    
                    // Only include months that overlap with the date range
                    if (monthStart <= new Date(dateRange.end)) {
                        monthRanges.push({
                            start: monthStart.toISOString().split('T')[0],
                            end: monthEnd.toISOString().split('T')[0],
                            label: months[monthStart.getMonth()]
                        });
                    }
                }
                
                // Count books completed in each month
                monthRanges.forEach(month => {
                    labels.push(month.label);
                    
                    // Count books completed in this month
                    let count = 0;
                    Object.values(readingStats.booksCompletedDates || {}).forEach(completionDate => {
                        if (isDateInRange(completionDate, month.start, month.end)) {
                            count++;
                        }
                    });
                    
                    values.push(count);
                });
                break;
                
            case 'all':
                // Yearly data for all time
                const completionYears = new Set();
                
                // Get all years with completions
                Object.values(readingStats.booksCompletedDates || {}).forEach(completionDate => {
                    const year = completionDate.split('-')[0];
                    completionYears.add(year);
                });
                
                // Sort years
                const years = Array.from(completionYears).sort();
                
                // Count books completed in each year
                years.forEach(year => {
                    labels.push(year);
                    
                    // Count books completed in this year
                    let count = 0;
                    Object.values(readingStats.booksCompletedDates || {}).forEach(completionDate => {
                        if (completionDate.startsWith(year)) {
                            count++;
                        }
                    });
                    
                    values.push(count);
                });
                break;
        }
        
        return { labels, values };
    }
    
    /**
     * Get category data for the chart
     */
    function getCategoryData(readingStats, dateRange) {
        const categories = {
            'science-philosophy': { label: 'Science & Philosophy', count: 0 },
            'memoir-biography': { label: 'Memoir & Biography', count: 0 },
            'fiction': { label: 'Fiction', count: 0 }
        };
        
        // Count books completed in each category within the date range
        Object.keys(readingStats.booksCompletedDates || {}).forEach(bookId => {
            const completionDate = readingStats.booksCompletedDates[bookId];
            
            // Check if completion date is within range
            if (isDateInRange(completionDate, dateRange.start, dateRange.end)) {
                // Get book category
                const book = getBookById(bookId);
                if (book && categories[book.category]) {
                    categories[book.category].count++;
                }
            }
        });
        
        // Format data for chart
        const labels = [];
        const values = [];
        let total = 0;
        
        Object.values(categories).forEach(category => {
            if (category.count > 0) {
                labels.push(category.label);
                values.push(category.count);
                total += category.count;
            }
        });
        
        return { labels, values, total };
    }
    
    /**
     * Calculate the current reading streak
     */
    function calculateCurrentStreak(activityDates) {
        if (!activityDates || activityDates.length === 0) {
            return 0;
        }
        
        // Sort dates in descending order
        const sortedDates = [...activityDates].sort((a, b) => new Date(b) - new Date(a));
        
        // Get today's date
        const today = new Date().toISOString().split('T')[0];
        
        // Check if there was activity today or yesterday
        const hasRecentActivity = sortedDates[0] === today || 
            sortedDates[0] === new Date(Date.now() - MS_PER_DAY).toISOString().split('T')[0];
        
        if (!hasRecentActivity) {
            return 0;
        }
        
        // Calculate streak
        let streak = 1;
        let currentDate = new Date(sortedDates[0]);
        
        for (let i = 1; i < sortedDates.length; i++) {
            const prevDate = new Date(currentDate);
            prevDate.setDate(prevDate.getDate() - 1);
            
            if (sortedDates[i] === prevDate.toISOString().split('T')[0]) {
                streak++;
                currentDate = prevDate;
            } else {
                break;
            }
        }
        
        return streak;
    }
    
    /**
     * Get date range for the selected period
     */
    function getDateRange(period) {
        const now = new Date();
        let start, end;
        
        switch (period) {
            case 'week':
                // Last 7 days
                start = new Date(now);
                start.setDate(now.getDate() - 6);
                end = now;
                break;
                
            case 'month':
                // Last 30 days
                start = new Date(now);
                start.setDate(now.getDate() - 29);
                end = now;
                break;
                
            case 'year':
                // Last 365 days
                start = new Date(now);
                start.setDate(now.getDate() - 364);
                end = now;
                break;
                
            case 'all':
                // All time (use a far past date)
                start = new Date('2000-01-01');
                end = now;
                break;
                
            default:
                // Default to week
                start = new Date(now);
                start.setDate(now.getDate() - 6);
                end = now;
        }
        
        return {
            start: start.toISOString().split('T')[0],
            end: end.toISOString().split('T')[0]
        };
    }
    
    /**
     * Check if a date is within a range
     */
    function isDateInRange(date, start, end) {
        return date >= start && date <= end;
    }
    
    /**
     * Format reading time in minutes to a human-readable string
     */
    function formatReadingTime(minutes) {
        if (minutes < 60) {
            return `${minutes} min`;
        } else {
            const hours = Math.floor(minutes / 60);
            const mins = minutes % 60;
            
            if (mins === 0) {
                return `${hours} ${hours === 1 ? 'hour' : 'hours'}`;
            } else {
                return `${hours} ${hours === 1 ? 'hour' : 'hours'} ${mins} min`;
            }
        }
    }
    
    /**
     * Get book data by ID
     */
    function getBookById(bookId) {
        const allBooks = getAllBooks();
        return allBooks.find(book => book.id === bookId);
    }
    
    /**
     * Get all books data
     */
    function getAllBooks() {
        // This would normally come from a database
        // For this implementation, we're hardcoding the book data
        return [
            // Science & Philosophy
            {
                id: 'ape-universe',
                title: 'The Ape that Understood the Universe',
                author: 'Steve Stewart-Williams',
                category: 'science-philosophy'
            },
            {
                id: 'code-book',
                title: 'The Code Book',
                author: 'Simon Singh',
                category: 'science-philosophy'
            },
            {
                id: 'brief-answers',
                title: 'Brief Answers to the Big Questions',
                author: 'Stephen Hawking',
                category: 'science-philosophy'
            },
            {
                id: 'sapiens',
                title: 'Sapiens',
                author: 'Yuval Noah Harari',
                category: 'science-philosophy'
            },
            {
                id: 'thinking-fast-slow',
                title: 'Thinking, Fast and Slow',
                author: 'Daniel Kahneman',
                category: 'science-philosophy'
            },
            {
                id: 'why-we-sleep',
                title: 'Why We Sleep',
                author: 'Matthew Walker',
                category: 'science-philosophy'
            },
            
            // Memoir & Biography
            {
                id: 'educated',
                title: 'Educated',
                author: 'Tara Westover',
                category: 'memoir-biography'
            },
            {
                id: 'becoming',
                title: 'Becoming',
                author: 'Michelle Obama',
                category: 'memoir-biography'
            },
            {
                id: 'born-crime',
                title: 'Born a Crime',
                author: 'Trevor Noah',
                category: 'memoir-biography'
            },
            {
                id: 'shoe-dog',
                title: 'Shoe Dog',
                author: 'Phil Knight',
                category: 'memoir-biography'
            },
            {
                id: 'elon-musk',
                title: 'Elon Musk',
                author: 'Walter Isaacson',
                category: 'memoir-biography'
            },
            {
                id: 'greenlights',
                title: 'Greenlights',
                author: 'Matthew McConaughey',
                category: 'memoir-biography'
            },
            
            // Fiction
            {
                id: 'project-hail-mary',
                title: 'Project Hail Mary',
                author: 'Andy Weir',
                category: 'fiction'
            },
            {
                id: 'midnight-library',
                title: 'The Midnight Library',
                author: 'Matt Haig',
                category: 'fiction'
            },
            {
                id: 'invisible-life',
                title: 'The Invisible Life of Addie LaRue',
                author: 'V.E. Schwab',
                category: 'fiction'
            },
            {
                id: 'circe',
                title: 'Circe',
                author: 'Madeline Miller',
                category: 'fiction'
            },
            {
                id: 'brave-new-world',
                title: 'Brave New World',
                author: 'Aldous Huxley',
                category: 'fiction'
            },
            {
                id: '1984',
                title: '1984',
                author: 'George Orwell',
                category: 'fiction'
            }
        ];
    }
    
    /**
     * Get reading time for a book
     */
    function getBookReadingTime(bookId) {
        // Book reading time data (in minutes)
        const bookReadingTimes = {
            // Science & Philosophy
            'ape-universe': 240, // 4 hours
            'code-book': 360, // 6 hours
            'brief-answers': 180, // 3 hours
            'sapiens': 480, // 8 hours
            'thinking-fast-slow': 540, // 9 hours
            'why-we-sleep': 300, // 5 hours
            
            // Memoir & Biography
            'educated': 330, // 5.5 hours
            'becoming': 420, // 7 hours
            'born-crime': 270, // 4.5 hours
            'shoe-dog': 300, // 5 hours
            'elon-musk': 480, // 8 hours
            'greenlights': 270, // 4.5 hours
            
            // Fiction
            'project-hail-mary': 390, // 6.5 hours
            'midnight-library': 270, // 4.5 hours
            'invisible-life': 330, // 5.5 hours
            'circe': 360, // 6 hours
            'brave-new-world': 240, // 4 hours
            '1984': 270 // 4.5 hours
        };
        
        return bookReadingTimes[bookId] || 300; // Default to 5 hours if not found
    }
    
    /**
     * Get stored user data from localStorage
     */
    function getStoredData() {
        const storedData = localStorage.getItem(STORAGE_KEY);
        return storedData ? JSON.parse(storedData) : null;
    }
    
    /**
     * Store user data to localStorage
     */
    function storeData(data) {
        localStorage.setItem(STORAGE_KEY, JSON.stringify(data));
    }
});