// Luigi's Bookshelf - Rating System

document.addEventListener('DOMContentLoaded', function() {
    // Constants
    const STORAGE_KEY = "luigis_bookshop_data";
    
    // Initialize the rating system
    initRatingSystem();
    
    /**
     * Initialize the rating system by adding rating stars to each book
     * and setting up event listeners
     */
    function initRatingSystem() {
        // Get all book entries
        const bookEntries = document.querySelectorAll('.book-entry');
        
        // Add rating UI to each book
        bookEntries.forEach(book => {
            // Get book ID from the checkbox
            const checkbox = book.querySelector('.book-checkbox');
            if (!checkbox) return;
            
            const bookId = checkbox.getAttribute('data-book');
            
            // Get the book-meta div to add our rating UI
            const bookMeta = book.querySelector('.book-meta');
            if (!bookMeta) return;
            
            // Create rating summary div to hold both Luigi's and user's ratings
            const ratingSummary = document.createElement('div');
            ratingSummary.className = 'rating-summary';
            
            // Move Luigi's rating into the summary div
            const luigiRating = bookMeta.querySelector('.rating-stars');
            if (luigiRating) {
                const luigiRatingContainer = document.createElement('div');
                luigiRatingContainer.className = 'luigi-rating';
                
                const luigiRatingLabel = document.createElement('span');
                luigiRatingLabel.className = 'luigi-rating-label';
                luigiRatingLabel.textContent = "Luigi's Rating:";
                
                luigiRatingContainer.appendChild(luigiRatingLabel);
                luigiRatingContainer.appendChild(luigiRating);
                ratingSummary.appendChild(luigiRatingContainer);
            }
            
            // Create user rating container
            const userRatingContainer = document.createElement('div');
            userRatingContainer.className = 'user-rating';
            
            // Create rating label
            const ratingLabel = document.createElement('span');
            ratingLabel.className = 'user-rating-label';
            ratingLabel.textContent = 'Your Rating:';
            userRatingContainer.appendChild(ratingLabel);
            
            // Create star rating
            const ratingStars = document.createElement('div');
            ratingStars.className = 'user-rating-stars';
            ratingStars.setAttribute('data-book', bookId);
            
            // Add 5 stars
            for (let i = 1; i <= 5; i++) {
                const star = document.createElement('span');
                star.className = 'star';
                star.innerHTML = '★';
                star.setAttribute('data-value', i);
                
                // Add event listeners for hover and click
                star.addEventListener('mouseenter', handleStarHover);
                star.addEventListener('mouseleave', handleStarHoverEnd);
                star.addEventListener('click', handleStarClick);
                
                ratingStars.appendChild(star);
            }
            
            userRatingContainer.appendChild(ratingStars);
            
            // Create rating value display
            const ratingValue = document.createElement('span');
            ratingValue.className = 'user-rating-value';
            ratingValue.textContent = '';
            userRatingContainer.appendChild(ratingValue);
            
            // Add user rating to the summary div
            ratingSummary.appendChild(userRatingContainer);
            
            // Replace the original rating-stars div with our new rating summary
            if (luigiRating) {
                bookMeta.insertBefore(ratingSummary, luigiRating.nextSibling);
                bookMeta.removeChild(luigiRating);
            } else {
                bookMeta.appendChild(ratingSummary);
            }
            
            // Load user's rating if it exists
            loadUserRating(bookId, ratingStars, ratingValue);
        });
    }
    
    /**
     * Handle mouse hover over a star
     */
    function handleStarHover(e) {
        const currentStar = e.target;
        const stars = currentStar.parentElement.children;
        const value = parseInt(currentStar.getAttribute('data-value'));
        
        // Highlight all stars up to the hovered one
        for (let i = 0; i < stars.length; i++) {
            if (i < value) {
                stars[i].classList.add('hover');
            } else {
                stars[i].classList.remove('hover');
            }
        }
    }
    
    /**
     * Handle mouse leaving the star rating area
     */
    function handleStarHoverEnd(e) {
        const stars = e.target.parentElement.children;
        
        // Remove hover class from all stars
        for (let i = 0; i < stars.length; i++) {
            stars[i].classList.remove('hover');
        }
    }
    
    /**
     * Handle star click to set rating
     */
    function handleStarClick(e) {
        const currentStar = e.target;
        const stars = currentStar.parentElement.children;
        const value = parseInt(currentStar.getAttribute('data-value'));
        const bookId = currentStar.parentElement.getAttribute('data-book');
        
        // Update active stars
        for (let i = 0; i < stars.length; i++) {
            if (i < value) {
                stars[i].classList.add('active');
            } else {
                stars[i].classList.remove('active');
            }
        }
        
        // Update rating value display
        const ratingValue = currentStar.parentElement.nextElementSibling;
        ratingValue.textContent = `(${value}/5)`;
        
        // Save the rating
        saveUserRating(bookId, value);
        
        // Show notification
        showRatingNotification(bookId, value);
    }
    
    /**
     * Save user rating to localStorage
     */
    function saveUserRating(bookId, rating) {
        const userData = getStoredData() || { authenticated: true, books: {}, ratings: {} };
        
        // Initialize ratings object if it doesn't exist
        if (!userData.ratings) {
            userData.ratings = {};
        }
        
        // Save the rating
        userData.ratings[bookId] = rating;
        
        // Store the updated data
        storeData(userData);
    }
    
    /**
     * Load user rating from localStorage
     */
    function loadUserRating(bookId, starsContainer, valueDisplay) {
        const userData = getStoredData();
        
        if (userData && userData.ratings && userData.ratings[bookId]) {
            const rating = userData.ratings[bookId];
            const stars = starsContainer.children;
            
            // Set active stars
            for (let i = 0; i < stars.length; i++) {
                if (i < rating) {
                    stars[i].classList.add('active');
                } else {
                    stars[i].classList.remove('active');
                }
            }
            
            // Update rating value display
            valueDisplay.textContent = `(${rating}/5)`;
        }
    }
    
    /**
     * Show a notification when a book is rated
     */
    function showRatingNotification(bookId, rating) {
        // Find the book title
        const bookEntry = document.querySelector(`.book-checkbox[data-book="${bookId}"]`).closest('.book-entry');
        const bookTitle = bookEntry.querySelector('.book-title').textContent;
        
        // Create notification element if it doesn't exist
        let notification = document.getElementById('rating-notification');
        if (!notification) {
            notification = document.createElement('div');
            notification.id = 'rating-notification';
            notification.className = 'rating-notification';
            document.body.appendChild(notification);
        }
        
        // Set notification message
        notification.textContent = `You rated "${bookTitle}" ${rating} out of 5 stars`;
        
        // Show notification
        notification.classList.add('show');
        
        // Hide notification after 3 seconds
        setTimeout(() => {
            notification.classList.remove('show');
        }, 3000);
    }
    
    /**
     * Get stored user data from localStorage
     */
    function getStoredData() {
        const storedData = localStorage.getItem(STORAGE_KEY);
        return storedData ? JSON.parse(storedData) : null;
    }
    
    /**
     * Store user data to localStorage
     */
    function storeData(data) {
        localStorage.setItem(STORAGE_KEY, JSON.stringify(data));
    }
});