// Luigi's Bookshelf - Social Sharing

document.addEventListener('DOMContentLoaded', function() {
    // Constants
    const STORAGE_KEY = "luigis_bookshop_data";
    
    // Initialize the social sharing
    initSocialSharing();
    
    /**
     * Initialize the social sharing section
     */
    function initSocialSharing() {
        // Get the passport content div
        const passportContent = document.getElementById('passport-content');
        if (!passportContent) return;
        
        // Find where to insert the social sharing section
        // We'll put it after the recommendations section or challenges section
        let insertAfter = document.querySelector('.recommendations-section');
        if (!insertAfter) {
            insertAfter = document.querySelector('.challenges-section');
        }
        if (!insertAfter) {
            insertAfter = document.querySelector('.reading-stats');
        }
        if (!insertAfter) {
            insertAfter = document.querySelector('.reading-progress');
        }
        if (!insertAfter) return;
        
        // Create social sharing section
        const socialSharingSection = createSocialSharingSection();
        
        // Insert after the target element
        insertAfter.parentNode.insertBefore(socialSharingSection, insertAfter.nextSibling);
        
        // Set up event listeners for the toggle button
        const toggleButton = document.querySelector('.social-sharing-toggle');
        const socialSharingContent = document.querySelector('.social-sharing-content');
        
        if (toggleButton && socialSharingContent) {
            toggleButton.addEventListener('click', function() {
                const isCollapsed = socialSharingContent.classList.contains('collapsed');
                
                if (isCollapsed) {
                    socialSharingContent.classList.remove('collapsed');
                    toggleButton.classList.remove('collapsed');
                    toggleButton.querySelector('.social-sharing-toggle-text').textContent = 'Hide';
                } else {
                    socialSharingContent.classList.add('collapsed');
                    toggleButton.classList.add('collapsed');
                    toggleButton.querySelector('.social-sharing-toggle-text').textContent = 'Show';
                }
            });
        }
        
        // Set up event listeners for sharing options
        setupSharingOptions();
    }
    
    /**
     * Create the social sharing section HTML
     */
    function createSocialSharingSection() {
        const section = document.createElement('div');
        section.className = 'social-sharing-section';
        
        // Create header
        const header = document.createElement('div');
        header.className = 'social-sharing-header';
        
        const title = document.createElement('h2');
        title.className = 'social-sharing-title';
        title.textContent = 'Share Your Reading Journey';
        
        const toggle = document.createElement('button');
        toggle.className = 'social-sharing-toggle';
        toggle.innerHTML = '<span class="social-sharing-toggle-text">Hide</span><span class="social-sharing-toggle-icon">▼</span>';
        
        header.appendChild(title);
        header.appendChild(toggle);
        
        // Create content container
        const content = document.createElement('div');
        content.className = 'social-sharing-content';
        
        // Create sharing options
        const sharingOptions = document.createElement('div');
        sharingOptions.className = 'sharing-options';
        
        // Add sharing options
        sharingOptions.appendChild(createSharingOption(
            '📊', 
            'Reading Progress', 
            'Share your overall reading progress and statistics',
            'progress'
        ));
        
        sharingOptions.appendChild(createSharingOption(
            '🏆', 
            'Achievements', 
            'Share your reading achievements and badges',
            'achievements'
        ));
        
        sharingOptions.appendChild(createSharingOption(
            '📚', 
            'Favorite Books', 
            'Share your favorite books from Luigi\'s collection',
            'favorites'
        ));
        
        // Create preview section (initially empty)
        const previewSection = document.createElement('div');
        previewSection.className = 'sharing-preview';
        previewSection.id = 'sharing-preview';
        previewSection.style.display = 'none';
        
        // Add elements to the content
        content.appendChild(sharingOptions);
        content.appendChild(previewSection);
        
        // Add elements to the section
        section.appendChild(header);
        section.appendChild(content);
        
        return section;
    }
    
    /**
     * Create a sharing option element
     */
    function createSharingOption(icon, title, description, type) {
        const option = document.createElement('div');
        option.className = 'sharing-option';
        option.dataset.type = type;
        
        const header = document.createElement('div');
        header.className = 'sharing-option-header';
        
        const iconEl = document.createElement('span');
        iconEl.className = 'sharing-option-icon';
        iconEl.textContent = icon;
        
        const titleEl = document.createElement('h3');
        titleEl.className = 'sharing-option-title';
        titleEl.textContent = title;
        
        header.appendChild(iconEl);
        header.appendChild(titleEl);
        
        const descriptionEl = document.createElement('p');
        descriptionEl.className = 'sharing-option-description';
        descriptionEl.textContent = description;
        
        option.appendChild(header);
        option.appendChild(descriptionEl);
        
        return option;
    }
    
    /**
     * Set up event listeners for sharing options
     */
    function setupSharingOptions() {
        const options = document.querySelectorAll('.sharing-option');
        
        options.forEach(option => {
            option.addEventListener('click', function() {
                const type = this.dataset.type;
                showSharingPreview(type);
                
                // Highlight selected option
                options.forEach(opt => opt.style.borderLeft = '');
                this.style.borderLeft = '4px solid #4a6fa5';
            });
        });
    }
    
    /**
     * Show sharing preview based on selected type
     */
    function showSharingPreview(type) {
        const previewSection = document.getElementById('sharing-preview');
        if (!previewSection) return;
        
        // Show the preview section
        previewSection.style.display = 'block';
        
        // Clear previous content
        previewSection.innerHTML = '';
        
        // Create preview header
        const header = document.createElement('div');
        header.className = 'sharing-preview-header';
        
        const title = document.createElement('h3');
        title.className = 'sharing-preview-title';
        
        const description = document.createElement('p');
        description.className = 'sharing-preview-description';
        
        header.appendChild(title);
        header.appendChild(description);
        
        // Create preview content
        const content = document.createElement('div');
        content.className = 'sharing-preview-content';
        
        // Create preview image
        const imageContainer = document.createElement('div');
        imageContainer.className = 'sharing-preview-image';
        
        const image = document.createElement('img');
        imageContainer.appendChild(image);
        
        // Create preview text
        const text = document.createElement('p');
        text.className = 'sharing-preview-text';
        
        content.appendChild(imageContainer);
        content.appendChild(text);
        
        // Create customization section
        const customization = createCustomizationSection(type);
        
        // Create actions
        const actions = document.createElement('div');
        actions.className = 'sharing-preview-actions';
        
        const copyButton = document.createElement('button');
        copyButton.className = 'sharing-button secondary';
        copyButton.innerHTML = '<span class="sharing-button-icon">📋</span> Copy Text';
        copyButton.addEventListener('click', () => copyShareText(text.textContent));
        
        const twitterButton = document.createElement('button');
        twitterButton.className = 'sharing-button';
        twitterButton.innerHTML = '<span class="sharing-button-icon twitter-color">𝕏</span> Share on Twitter';
        twitterButton.addEventListener('click', () => shareToTwitter(text.textContent));
        
        const facebookButton = document.createElement('button');
        facebookButton.className = 'sharing-button';
        facebookButton.innerHTML = '<span class="sharing-button-icon facebook-color">f</span> Share on Facebook';
        facebookButton.addEventListener('click', () => shareToFacebook(text.textContent));
        
        actions.appendChild(copyButton);
        actions.appendChild(twitterButton);
        actions.appendChild(facebookButton);
        
        // Add elements to the preview section
        previewSection.appendChild(header);
        previewSection.appendChild(content);
        previewSection.appendChild(customization);
        previewSection.appendChild(actions);
        
        // Set content based on type
        if (type === 'progress') {
            setupProgressSharing(title, description, image, text);
        } else if (type === 'achievements') {
            setupAchievementsSharing(title, description, image, text);
        } else if (type === 'favorites') {
            setupFavoritesSharing(title, description, image, text);
        }
    }
    
    /**
     * Create customization section for sharing
     */
    function createCustomizationSection(type) {
        const customization = document.createElement('div');
        customization.className = 'sharing-customization';
        
        const header = document.createElement('div');
        header.className = 'sharing-customization-header';
        
        const title = document.createElement('h3');
        title.className = 'sharing-customization-title';
        title.textContent = 'Customize Your Message';
        
        const description = document.createElement('p');
        description.className = 'sharing-customization-description';
        description.textContent = 'Personalize your sharing message before posting';
        
        header.appendChild(title);
        header.appendChild(description);
        
        // Create form
        const form = document.createElement('div');
        form.className = 'sharing-form';
        
        // Message input
        const messageGroup = document.createElement('div');
        messageGroup.className = 'sharing-form-group';
        
        const messageLabel = document.createElement('label');
        messageLabel.className = 'sharing-form-label';
        messageLabel.textContent = 'Your Message';
        
        const messageInput = document.createElement('textarea');
        messageInput.className = 'sharing-form-textarea';
        messageInput.id = 'sharing-message';
        
        // Set default message based on type
        if (type === 'progress') {
            messageInput.value = "I'm making progress on my reading journey with Luigi's Bookshelf! Check out my stats:";
        } else if (type === 'achievements') {
            messageInput.value = "I've earned some reading achievements on Luigi's Bookshelf! Check out my badges:";
        } else if (type === 'favorites') {
            messageInput.value = "These are my favorite books from Luigi's Bookshelf collection:";
        }
        
        messageGroup.appendChild(messageLabel);
        messageGroup.appendChild(messageInput);
        
        // Include stats checkbox
        const statsGroup = document.createElement('div');
        statsGroup.className = 'sharing-form-group';
        
        const statsCheckbox = document.createElement('input');
        statsCheckbox.type = 'checkbox';
        statsCheckbox.id = 'include-stats';
        statsCheckbox.checked = true;
        
        const statsLabel = document.createElement('label');
        statsLabel.className = 'sharing-form-label';
        statsLabel.htmlFor = 'include-stats';
        statsLabel.textContent = 'Include detailed statistics';
        
        statsGroup.appendChild(statsCheckbox);
        statsGroup.appendChild(statsLabel);
        
        // Update button
        const formActions = document.createElement('div');
        formActions.className = 'sharing-form-actions';
        
        const updateButton = document.createElement('button');
        updateButton.className = 'sharing-button';
        updateButton.textContent = 'Update Preview';
        updateButton.addEventListener('click', () => updateSharePreview(type));
        
        formActions.appendChild(updateButton);
        
        // Add elements to the form
        form.appendChild(messageGroup);
        
        if (type === 'progress' || type === 'achievements') {
            form.appendChild(statsGroup);
        }
        
        form.appendChild(formActions);
        
        // Add elements to the customization section
        customization.appendChild(header);
        customization.appendChild(form);
        
        return customization;
    }
    
    /**
     * Set up progress sharing preview
     */
    function setupProgressSharing(titleEl, descriptionEl, imageEl, textEl) {
        const userData = getStoredData() || { books: {} };
        
        // Set title and description
        titleEl.textContent = 'Share Your Reading Progress';
        descriptionEl.textContent = 'Let others know how many books you\'ve read from Luigi\'s collection';
        
        // Calculate progress
        const totalBooks = Object.keys(bookData).length;
        const readBooks = Object.keys(userData.books || {}).filter(id => userData.books[id]).length;
        const progressPercentage = Math.round((readBooks / totalBooks) * 100);
        
        // Set image (placeholder for now - in a real implementation, this would generate an actual progress image)
        imageEl.src = `https://via.placeholder.com/600x300/4a6fa5/ffffff?text=Reading+Progress:+${progressPercentage}%`;
        imageEl.alt = 'Reading Progress';
        
        // Set text
        const message = document.getElementById('sharing-message').value;
        const includeStats = document.getElementById('include-stats')?.checked ?? true;
        
        let shareText = `${message}\n\n`;
        shareText += `📚 I've read ${readBooks} out of ${totalBooks} books (${progressPercentage}%)\n`;
        
        if (includeStats) {
            // Add category breakdown
            const categoryProgress = getCategoryProgress(userData);
            
            shareText += '\nCategory Progress:\n';
            Object.keys(categoryProgress).forEach(category => {
                const { read, total } = categoryProgress[category];
                const catPercentage = Math.round((read / total) * 100);
                shareText += `- ${formatCategoryName(category)}: ${read}/${total} (${catPercentage}%)\n`;
            });
            
            // Add estimated reading time
            const readingTime = getReadingTimeStats(userData);
            shareText += `\nTotal Reading Time: ${formatReadingTime(readingTime.completed)} of ${formatReadingTime(readingTime.total)}\n`;
        }
        
        shareText += '\n#LuigisBookshelf #ReadingChallenge';
        
        textEl.textContent = shareText;
    }
    
    /**
     * Set up achievements sharing preview
     */
    function setupAchievementsSharing(titleEl, descriptionEl, imageEl, textEl) {
        const userData = getStoredData() || { books: {} };
        
        // Set title and description
        titleEl.textContent = 'Share Your Reading Achievements';
        descriptionEl.textContent = 'Show off the reading badges you\'ve earned';
        
        // Get earned achievements
        const achievements = getEarnedAchievements(userData);
        
        // Set image (placeholder for now - in a real implementation, this would generate an actual achievements image)
        imageEl.src = `https://via.placeholder.com/600x300/9c27b0/ffffff?text=${achievements.length}+Achievements+Earned`;
        imageEl.alt = 'Reading Achievements';
        
        // Set text
        const message = document.getElementById('sharing-message').value;
        const includeStats = document.getElementById('include-stats')?.checked ?? true;
        
        let shareText = `${message}\n\n`;
        shareText += `🏆 I've earned ${achievements.length} reading achievements!\n`;
        
        if (includeStats && achievements.length > 0) {
            shareText += '\nMy Achievements:\n';
            achievements.forEach(achievement => {
                shareText += `- ${achievement.name}: ${achievement.description}\n`;
            });
        }
        
        shareText += '\n#LuigisBookshelf #ReadingAchievements';
        
        textEl.textContent = shareText;
    }
    
    /**
     * Set up favorites sharing preview
     */
    function setupFavoritesSharing(titleEl, descriptionEl, imageEl, textEl) {
        const userData = getStoredData() || { books: {}, ratings: {} };
        
        // Set title and description
        titleEl.textContent = 'Share Your Favorite Books';
        descriptionEl.textContent = 'Let others know which books from Luigi\'s collection you enjoyed the most';
        
        // Get favorite books (rated 4-5 stars)
        const favoriteBooks = getFavoriteBooks(userData);
        
        // Set image (placeholder for now - in a real implementation, this would generate an actual favorites image)
        imageEl.src = `https://via.placeholder.com/600x300/ff9800/ffffff?text=${favoriteBooks.length}+Favorite+Books`;
        imageEl.alt = 'Favorite Books';
        
        // Set text
        const message = document.getElementById('sharing-message').value;
        
        let shareText = `${message}\n\n`;
        
        if (favoriteBooks.length === 0) {
            shareText += '📚 I haven\'t rated any books yet, but I\'m excited to discover my favorites!\n';
        } else {
            shareText += `📚 My top ${favoriteBooks.length} book${favoriteBooks.length !== 1 ? 's' : ''} from Luigi's collection:\n\n`;
            
            favoriteBooks.forEach((book, index) => {
                const stars = '★'.repeat(book.rating);
                shareText += `${index + 1}. "${book.title}" by ${book.author} - ${stars}\n`;
            });
        }
        
        shareText += '\n#LuigisBookshelf #BookRecommendations';
        
        textEl.textContent = shareText;
    }
    
    /**
     * Update the share preview based on user customizations
     */
    function updateSharePreview(type) {
        const previewText = document.querySelector('.sharing-preview-text');
        if (!previewText) return;
        
        const textEl = previewText;
        
        if (type === 'progress') {
            setupProgressSharing(
                document.querySelector('.sharing-preview-title'),
                document.querySelector('.sharing-preview-description'),
                document.querySelector('.sharing-preview-image img'),
                textEl
            );
        } else if (type === 'achievements') {
            setupAchievementsSharing(
                document.querySelector('.sharing-preview-title'),
                document.querySelector('.sharing-preview-description'),
                document.querySelector('.sharing-preview-image img'),
                textEl
            );
        } else if (type === 'favorites') {
            setupFavoritesSharing(
                document.querySelector('.sharing-preview-title'),
                document.querySelector('.sharing-preview-description'),
                document.querySelector('.sharing-preview-image img'),
                textEl
            );
        }
        
        // Show notification
        showSharingNotification('Preview updated!');
    }
    
    /**
     * Copy share text to clipboard
     */
    function copyShareText(text) {
        navigator.clipboard.writeText(text).then(() => {
            showSharingNotification('Text copied to clipboard!');
        }).catch(err => {
            console.error('Could not copy text: ', err);
            showSharingNotification('Failed to copy text', true);
        });
    }
    
    /**
     * Share to Twitter
     */
    function shareToTwitter(text) {
        // Limit text to Twitter's character limit
        const twitterText = text.length > 280 ? text.substring(0, 277) + '...' : text;
        
        // Encode the text for a URL
        const encodedText = encodeURIComponent(twitterText);
        
        // Open Twitter share dialog
        window.open(`https://twitter.com/intent/tweet?text=${encodedText}`, '_blank');
        
        // Show notification
        showSharingNotification('Opening Twitter share dialog...');
    }
    
    /**
     * Share to Facebook
     */
    function shareToFacebook(text) {
        // Facebook sharing typically uses the Open Graph protocol
        // For simplicity, we'll just open a share dialog with the text
        const encodedText = encodeURIComponent(text);
        
        // Open Facebook share dialog
        window.open(`https://www.facebook.com/sharer/sharer.php?u=https://luigisbookshelf.com&quote=${encodedText}`, '_blank');
        
        // Show notification
        showSharingNotification('Opening Facebook share dialog...');
    }
    
    /**
     * Show a notification for sharing actions
     */
    function showSharingNotification(message, isError = false) {
        // Create notification element if it doesn't exist
        let notification = document.getElementById('social-sharing-notification');
        if (!notification) {
            notification = document.createElement('div');
            notification.id = 'social-sharing-notification';
            notification.className = 'social-sharing-notification';
            document.body.appendChild(notification);
        }
        
        // Set notification message
        notification.textContent = message;
        
        // Set error styling if needed
        if (isError) {
            notification.style.backgroundColor = '#F44336';
        } else {
            notification.style.backgroundColor = '#4CAF50';
        }
        
        // Show notification
        notification.classList.add('show');
        
        // Hide notification after 3 seconds
        setTimeout(() => {
            notification.classList.remove('show');
        }, 3000);
    }
    
    /**
     * Get category progress statistics
     */
    function getCategoryProgress(userData) {
        const categoryProgress = {
            'science-philosophy': { read: 0, total: 0 },
            'memoir-biography': { read: 0, total: 0 },
            'fiction': { read: 0, total: 0 }
        };
        
        // Count books in each category
        Object.keys(bookData).forEach(bookId => {
            const category = bookData[bookId].category;
            if (categoryProgress[category]) {
                categoryProgress[category].total++;
                
                if (userData.books && userData.books[bookId]) {
                    categoryProgress[category].read++;
                }
            }
        });
        
        return categoryProgress;
    }
    
    /**
     * Get reading time statistics
     */
    function getReadingTimeStats(userData) {
        // Book reading time data (in minutes)
        const bookReadingTimes = {
            // Science & Philosophy
            'ape-universe': 240, // 4 hours
            'code-book': 360, // 6 hours
            'brief-answers': 180, // 3 hours
            'sapiens': 480, // 8 hours
            'thinking-fast-slow': 540, // 9 hours
            'why-we-sleep': 300, // 5 hours
            
            // Memoir & Biography
            'educated': 330, // 5.5 hours
            'becoming': 420, // 7 hours
            'born-crime': 270, // 4.5 hours
            'shoe-dog': 300, // 5 hours
            'elon-musk': 480, // 8 hours
            'greenlights': 270, // 4.5 hours
            
            // Fiction
            'project-hail-mary': 390, // 6.5 hours
            'midnight-library': 270, // 4.5 hours
            'invisible-life': 330, // 5.5 hours
            'circe': 360, // 6 hours
            'brave-new-world': 240, // 4 hours
            '1984': 270 // 4.5 hours
        };
        
        let totalTime = 0;
        let completedTime = 0;
        
        // Calculate times
        Object.keys(bookReadingTimes).forEach(bookId => {
            const time = bookReadingTimes[bookId];
            
            totalTime += time;
            
            if (userData.books && userData.books[bookId]) {
                completedTime += time;
            }
        });
        
        return {
            total: totalTime,
            completed: completedTime
        };
    }
    
    /**
     * Format reading time in minutes to a human-readable string
     */
    function formatReadingTime(minutes) {
        if (minutes < 60) {
            return `${minutes} min`;
        } else {
            const hours = Math.floor(minutes / 60);
            const mins = minutes % 60;
            
            if (mins === 0) {
                return `${hours} ${hours === 1 ? 'hour' : 'hours'}`;
            } else {
                return `${hours} ${hours === 1 ? 'hour' : 'hours'} ${mins} min`;
            }
        }
    }
    
    /**
     * Get earned achievements
     */
    function getEarnedAchievements(userData) {
        // This is a simplified version - in a real implementation, this would
        // use the actual achievement system's logic
        const achievements = [];
        
        // Count books read
        const readBooks = Object.keys(userData.books || {}).filter(id => userData.books[id]).length;
        
        // Category-based achievements
        const categoryProgress = getCategoryProgress(userData);
        
        if (categoryProgress['science-philosophy'].read === categoryProgress['science-philosophy'].total) {
            achievements.push({
                name: 'Philosophy Pioneer',
                description: 'Completed all Science & Philosophy books'
            });
        }
        
        if (categoryProgress['memoir-biography'].read === categoryProgress['memoir-biography'].total) {
            achievements.push({
                name: 'Memoir Master',
                description: 'Completed all Memoir & Biography books'
            });
        }
        
        if (categoryProgress['fiction'].read === categoryProgress['fiction'].total) {
            achievements.push({
                name: 'Fiction Fanatic',
                description: 'Completed all Fiction books'
            });
        }
        
        // Count-based achievements
        if (readBooks >= 5) {
            achievements.push({
                name: 'Bookworm',
                description: 'Read 5 books from any category'
            });
        }
        
        if (readBooks >= 10) {
            achievements.push({
                name: 'Avid Reader',
                description: 'Read 10 books from any category'
            });
        }
        
        if (readBooks === Object.keys(bookData).length) {
            achievements.push({
                name: 'Literary Legend',
                description: 'Completed all books in Luigi\'s collection'
            });
        }
        
        // Special achievements
        if (userData.books && userData.books['1984'] && userData.books['brave-new-world']) {
            achievements.push({
                name: 'Dystopian Dreamer',
                description: 'Read both 1984 and Brave New World'
            });
        }
        
        if (userData.books && userData.books['elon-musk'] && userData.books['shoe-dog']) {
            achievements.push({
                name: 'Tech Titan',
                description: 'Read Elon Musk and Shoe Dog biographies'
            });
        }
        
        return achievements;
    }
    
    /**
     * Get favorite books (rated 4-5 stars)
     */
    function getFavoriteBooks(userData) {
        const favorites = [];
        
        if (!userData.ratings) return favorites;
        
        // Find books rated 4 or 5 stars
        Object.keys(userData.ratings).forEach(bookId => {
            const rating = userData.ratings[bookId];
            
            if (rating >= 4 && bookData[bookId]) {
                favorites.push({
                    id: bookId,
                    title: bookData[bookId].title,
                    author: bookData[bookId].author,
                    rating: rating
                });
            }
        });
        
        // Sort by rating (highest first)
        favorites.sort((a, b) => b.rating - a.rating);
        
        return favorites;
    }
    
    /**
     * Format a category name for display
     */
    function formatCategoryName(category) {
        return category
            .split('-')
            .map(word => word.charAt(0).toUpperCase() + word.slice(1))
            .join(' & ');
    }
    
    /**
     * Get stored user data from localStorage
     */
    function getStoredData() {
        const storedData = localStorage.getItem(STORAGE_KEY);
        return storedData ? JSON.parse(storedData) : null;
    }
    
    // Book data - this would normally come from a database
    // For this implementation, we're hardcoding the book data
    const bookData = {
        // Science & Philosophy
        'ape-universe': {
            id: 'ape-universe',
            title: 'The Ape that Understood the Universe',
            author: 'Steve Stewart-Williams',
            category: 'science-philosophy'
        },
        'code-book': {
            id: 'code-book',
            title: 'The Code Book',
            author: 'Simon Singh',
            category: 'science-philosophy'
        },
        'brief-answers': {
            id: 'brief-answers',
            title: 'Brief Answers to the Big Questions',
            author: 'Stephen Hawking',
            category: 'science-philosophy'
        },
        'sapiens': {
            id: 'sapiens',
            title: 'Sapiens',
            author: 'Yuval Noah Harari',
            category: 'science-philosophy'
        },
        'thinking-fast-slow': {
            id: 'thinking-fast-slow',
            title: 'Thinking, Fast and Slow',
            author: 'Daniel Kahneman',
            category: 'science-philosophy'
        },
        'why-we-sleep': {
            id: 'why-we-sleep',
            title: 'Why We Sleep',
            author: 'Matthew Walker',
            category: 'science-philosophy'
        },
        
        // Memoir & Biography
        'educated': {
            id: 'educated',
            title: 'Educated',
            author: 'Tara Westover',
            category: 'memoir-biography'
        },
        'becoming': {
            id: 'becoming',
            title: 'Becoming',
            author: 'Michelle Obama',
            category: 'memoir-biography'
        },
        'born-crime': {
            id: 'born-crime',
            title: 'Born a Crime',
            author: 'Trevor Noah',
            category: 'memoir-biography'
        },
        'shoe-dog': {
            id: 'shoe-dog',
            title: 'Shoe Dog',
            author: 'Phil Knight',
            category: 'memoir-biography'
        },
        'elon-musk': {
            id: 'elon-musk',
            title: 'Elon Musk',
            author: 'Walter Isaacson',
            category: 'memoir-biography'
        },
        'greenlights': {
            id: 'greenlights',
            title: 'Greenlights',
            author: 'Matthew McConaughey',
            category: 'memoir-biography'
        },
        
        // Fiction
        'project-hail-mary': {
            id: 'project-hail-mary',
            title: 'Project Hail Mary',
            author: 'Andy Weir',
            category: 'fiction'
        },
        'midnight-library': {
            id: 'midnight-library',
            title: 'The Midnight Library',
            author: 'Matt Haig',
            category: 'fiction'
        },
        'invisible-life': {
            id: 'invisible-life',
            title: 'The Invisible Life of Addie LaRue',
            author: 'V.E. Schwab',
            category: 'fiction'
        },
        'circe': {
            id: 'circe',
            title: 'Circe',
            author: 'Madeline Miller',
            category: 'fiction'
        },
        'brave-new-world': {
            id: 'brave-new-world',
            title: 'Brave New World',
            author: 'Aldous Huxley',
            category: 'fiction'
        },
        '1984': {
            id: '1984',
            title: '1984',
            author: 'George Orwell',
            category: 'fiction'
        }
    };
});