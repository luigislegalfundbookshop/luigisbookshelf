// Luigi's Bookshelf - Reading Time Estimates

document.addEventListener('DOMContentLoaded', function() {
    // Book reading time data (in minutes)
    // These are estimated based on average reading speeds and book lengths
    const bookReadingTimes = {
        // Science & Philosophy
        'ape-universe': 240, // 4 hours
        'code-book': 360, // 6 hours
        'brief-answers': 180, // 3 hours
        'sapiens': 480, // 8 hours
        'thinking-fast-slow': 540, // 9 hours
        'why-we-sleep': 300, // 5 hours
        
        // Memoir & Biography
        'educated': 330, // 5.5 hours
        'becoming': 420, // 7 hours
        'born-crime': 270, // 4.5 hours
        'shoe-dog': 300, // 5 hours
        'elon-musk': 480, // 8 hours
        'greenlights': 270, // 4.5 hours
        
        // Fiction
        'project-hail-mary': 390, // 6.5 hours
        'midnight-library': 270, // 4.5 hours
        'invisible-life': 330, // 5.5 hours
        'circe': 360, // 6 hours
        'brave-new-world': 240, // 4 hours
        '1984': 270 // 4.5 hours
    };
    
    // Average reading speeds (words per minute)
    const readingSpeeds = {
        slow: 150,
        average: 250,
        fast: 400
    };
    
    // Initialize reading time display
    initReadingTimes();
    
    // Add reading statistics to the page
    addReadingStatistics();
    
    /**
     * Initialize reading time displays for all books
     */
    function initReadingTimes() {
        // Get all book entries
        const bookEntries = document.querySelectorAll('.book-entry');
        
        // Add reading time to each book
        bookEntries.forEach(book => {
            // Get book ID from the checkbox
            const checkbox = book.querySelector('.book-checkbox');
            if (!checkbox) return;
            
            const bookId = checkbox.getAttribute('data-book');
            
            // Get reading time for this book
            const readingTimeMinutes = bookReadingTimes[bookId];
            if (!readingTimeMinutes) return;
            
            // Get the book details div to add our reading time
            const bookDetails = book.querySelector('.book-details');
            if (!bookDetails) return;
            
            // Create reading time element
            const readingTimeElement = document.createElement('div');
            readingTimeElement.className = 'reading-time';
            
            // Create icon
            const icon = document.createElement('span');
            icon.className = 'reading-time-icon';
            icon.innerHTML = '⏱️';
            readingTimeElement.appendChild(icon);
            
            // Create text
            const text = document.createElement('span');
            text.className = 'reading-time-text';
            text.textContent = formatReadingTime(readingTimeMinutes);
            readingTimeElement.appendChild(text);
            
            // Create tooltip
            const tooltip = document.createElement('span');
            tooltip.className = 'reading-time-tooltip';
            tooltip.innerHTML = '<span class="icon">ⓘ</span>';
            
            const tooltipText = document.createElement('span');
            tooltipText.className = 'tooltip-text';
            tooltipText.innerHTML = `
                Based on average reading speed (250 words/min):<br>
                - Slow (150 wpm): ${formatReadingTime(readingTimeMinutes * (readingSpeeds.average / readingSpeeds.slow))}<br>
                - Fast (400 wpm): ${formatReadingTime(readingTimeMinutes * (readingSpeeds.average / readingSpeeds.fast))}
            `;
            tooltip.appendChild(tooltipText);
            
            readingTimeElement.appendChild(tooltip);
            
            // Add to book details
            const bookMeta = book.querySelector('.book-meta');
            if (bookMeta) {
                bookMeta.parentNode.insertBefore(readingTimeElement, bookMeta.nextSibling);
            } else {
                bookDetails.appendChild(readingTimeElement);
            }
        });
    }
    
    /**
     * Add reading statistics section to the page
     */
    function addReadingStatistics() {
        // Get the passport content div
        const passportContent = document.getElementById('passport-content');
        if (!passportContent) return;
        
        // Get progress section to add our stats after it
        const progressSection = document.querySelector('.reading-progress');
        if (!progressSection) return;
        
        // Create reading stats container
        const readingStats = document.createElement('div');
        readingStats.className = 'reading-stats';
        
        // Add title
        const statsTitle = document.createElement('div');
        statsTitle.className = 'reading-stats-title';
        statsTitle.textContent = 'Reading Time Statistics';
        readingStats.appendChild(statsTitle);
        
        // Calculate statistics
        const stats = calculateReadingStats();
        
        // Add total time
        addStatItem(readingStats, 'Total Collection Reading Time:', formatReadingTime(stats.totalTime));
        
        // Add time by category
        Object.keys(stats.categoryTimes).forEach(category => {
            const formattedCategory = category.replace('-', ' & ');
            const categoryName = formattedCategory.charAt(0).toUpperCase() + formattedCategory.slice(1);
            addStatItem(readingStats, `${categoryName}:`, formatReadingTime(stats.categoryTimes[category]));
        });
        
        // Add completed time
        addStatItem(readingStats, 'Time for Books You\'ve Read:', formatReadingTime(stats.completedTime));
        
        // Add remaining time
        addStatItem(readingStats, 'Time for Books Remaining:', formatReadingTime(stats.remainingTime));
        
        // Insert after progress section
        progressSection.parentNode.insertBefore(readingStats, progressSection.nextSibling);
    }
    
    /**
     * Add a statistic item to the stats container
     */
    function addStatItem(container, label, value) {
        const item = document.createElement('div');
        item.className = 'reading-stats-item';
        
        const labelSpan = document.createElement('span');
        labelSpan.className = 'reading-stats-label';
        labelSpan.textContent = label;
        
        const valueSpan = document.createElement('span');
        valueSpan.className = 'reading-stats-value';
        valueSpan.textContent = value;
        
        item.appendChild(labelSpan);
        item.appendChild(valueSpan);
        container.appendChild(item);
    }
    
    /**
     * Calculate reading statistics
     */
    function calculateReadingStats() {
        // Get user data to check which books are read
        const userData = getStoredData() || { books: {} };
        
        let totalTime = 0;
        let completedTime = 0;
        let remainingTime = 0;
        const categoryTimes = {
            'science-philosophy': 0,
            'memoir-biography': 0,
            'fiction': 0
        };
        
        // Map book IDs to their categories
        const bookCategories = {
            // Science & Philosophy
            'ape-universe': 'science-philosophy',
            'code-book': 'science-philosophy',
            'brief-answers': 'science-philosophy',
            'sapiens': 'science-philosophy',
            'thinking-fast-slow': 'science-philosophy',
            'why-we-sleep': 'science-philosophy',
            
            // Memoir & Biography
            'educated': 'memoir-biography',
            'becoming': 'memoir-biography',
            'born-crime': 'memoir-biography',
            'shoe-dog': 'memoir-biography',
            'elon-musk': 'memoir-biography',
            'greenlights': 'memoir-biography',
            
            // Fiction
            'project-hail-mary': 'fiction',
            'midnight-library': 'fiction',
            'invisible-life': 'fiction',
            'circe': 'fiction',
            'brave-new-world': 'fiction',
            '1984': 'fiction'
        };
        
        // Calculate times
        Object.keys(bookReadingTimes).forEach(bookId => {
            const time = bookReadingTimes[bookId];
            const category = bookCategories[bookId];
            
            totalTime += time;
            
            if (category) {
                categoryTimes[category] += time;
            }
            
            if (userData.books && userData.books[bookId]) {
                completedTime += time;
            } else {
                remainingTime += time;
            }
        });
        
        return {
            totalTime,
            completedTime,
            remainingTime,
            categoryTimes
        };
    }
    
    /**
     * Format reading time in minutes to a human-readable string
     */
    function formatReadingTime(minutes) {
        if (minutes < 60) {
            return `${minutes} min`;
        } else {
            const hours = Math.floor(minutes / 60);
            const mins = minutes % 60;
            
            if (mins === 0) {
                return `${hours} ${hours === 1 ? 'hour' : 'hours'}`;
            } else {
                return `${hours} ${hours === 1 ? 'hour' : 'hours'} ${mins} min`;
            }
        }
    }
    
    /**
     * Get stored user data from localStorage
     */
    function getStoredData() {
        const STORAGE_KEY = "luigis_bookshop_data";
        const storedData = localStorage.getItem(STORAGE_KEY);
        return storedData ? JSON.parse(storedData) : null;
    }
});