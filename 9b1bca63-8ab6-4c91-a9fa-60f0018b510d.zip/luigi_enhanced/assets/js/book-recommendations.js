// Luigi's Bookshelf - Book Recommendations

document.addEventListener('DOMContentLoaded', function() {
    // Constants
    const STORAGE_KEY = "luigis_bookshop_data";
    
    // Book data - this would normally come from a database
    // For this implementation, we're hardcoding the book data
    const bookData = {
        // Science & Philosophy
        'ape-universe': {
            id: 'ape-universe',
            title: 'The Ape that Understood the Universe',
            author: 'Steve Stewart-Williams',
            category: 'science-philosophy',
            tags: ['psychology', 'evolution', 'human-behavior'],
            similar: ['sapiens', 'thinking-fast-slow']
        },
        'code-book': {
            id: 'code-book',
            title: 'The Code Book',
            author: 'Simon Singh',
            category: 'science-philosophy',
            tags: ['cryptography', 'mathematics', 'history'],
            similar: ['brief-answers', 'sapiens']
        },
        'brief-answers': {
            id: 'brief-answers',
            title: 'Brief Answers to the Big Questions',
            author: 'Stephen Hawking',
            category: 'science-philosophy',
            tags: ['physics', 'cosmology', 'philosophy'],
            similar: ['sapiens', 'why-we-sleep']
        },
        'sapiens': {
            id: 'sapiens',
            title: 'Sapiens',
            author: 'Yuval Noah Harari',
            category: 'science-philosophy',
            tags: ['history', 'anthropology', 'evolution'],
            similar: ['ape-universe', 'thinking-fast-slow']
        },
        'thinking-fast-slow': {
            id: 'thinking-fast-slow',
            title: 'Thinking, Fast and Slow',
            author: 'Daniel Kahneman',
            category: 'science-philosophy',
            tags: ['psychology', 'decision-making', 'behavioral-economics'],
            similar: ['ape-universe', 'sapiens']
        },
        'why-we-sleep': {
            id: 'why-we-sleep',
            title: 'Why We Sleep',
            author: 'Matthew Walker',
            category: 'science-philosophy',
            tags: ['neuroscience', 'health', 'psychology'],
            similar: ['thinking-fast-slow', 'brief-answers']
        },
        
        // Memoir & Biography
        'educated': {
            id: 'educated',
            title: 'Educated',
            author: 'Tara Westover',
            category: 'memoir-biography',
            tags: ['memoir', 'education', 'family'],
            similar: ['becoming', 'born-crime']
        },
        'becoming': {
            id: 'becoming',
            title: 'Becoming',
            author: 'Michelle Obama',
            category: 'memoir-biography',
            tags: ['memoir', 'politics', 'leadership'],
            similar: ['educated', 'greenlights']
        },
        'born-crime': {
            id: 'born-crime',
            title: 'Born a Crime',
            author: 'Trevor Noah',
            category: 'memoir-biography',
            tags: ['memoir', 'comedy', 'south-africa'],
            similar: ['educated', 'greenlights']
        },
        'shoe-dog': {
            id: 'shoe-dog',
            title: 'Shoe Dog',
            author: 'Phil Knight',
            category: 'memoir-biography',
            tags: ['business', 'entrepreneurship', 'sports'],
            similar: ['elon-musk', 'greenlights']
        },
        'elon-musk': {
            id: 'elon-musk',
            title: 'Elon Musk',
            author: 'Walter Isaacson',
            category: 'memoir-biography',
            tags: ['business', 'technology', 'entrepreneurship'],
            similar: ['shoe-dog', 'born-crime']
        },
        'greenlights': {
            id: 'greenlights',
            title: 'Greenlights',
            author: 'Matthew McConaughey',
            category: 'memoir-biography',
            tags: ['memoir', 'entertainment', 'philosophy'],
            similar: ['born-crime', 'becoming']
        },
        
        // Fiction
        'project-hail-mary': {
            id: 'project-hail-mary',
            title: 'Project Hail Mary',
            author: 'Andy Weir',
            category: 'fiction',
            tags: ['science-fiction', 'space', 'adventure'],
            similar: ['midnight-library', 'brave-new-world']
        },
        'midnight-library': {
            id: 'midnight-library',
            title: 'The Midnight Library',
            author: 'Matt Haig',
            category: 'fiction',
            tags: ['fantasy', 'philosophy', 'life-choices'],
            similar: ['invisible-life', 'circe']
        },
        'invisible-life': {
            id: 'invisible-life',
            title: 'The Invisible Life of Addie LaRue',
            author: 'V.E. Schwab',
            category: 'fiction',
            tags: ['fantasy', 'historical-fiction', 'romance'],
            similar: ['midnight-library', 'circe']
        },
        'circe': {
            id: 'circe',
            title: 'Circe',
            author: 'Madeline Miller',
            category: 'fiction',
            tags: ['mythology', 'fantasy', 'historical-fiction'],
            similar: ['invisible-life', 'midnight-library']
        },
        'brave-new-world': {
            id: 'brave-new-world',
            title: 'Brave New World',
            author: 'Aldous Huxley',
            category: 'fiction',
            tags: ['dystopian', 'classic', 'science-fiction'],
            similar: ['1984', 'project-hail-mary']
        },
        '1984': {
            id: '1984',
            title: '1984',
            author: 'George Orwell',
            category: 'fiction',
            tags: ['dystopian', 'classic', 'political-fiction'],
            similar: ['brave-new-world', 'project-hail-mary']
        }
    };
    
    // Initialize the book recommendations
    initBookRecommendations();
    
    /**
     * Initialize the book recommendations section
     */
    function initBookRecommendations() {
        // Get the passport content div
        const passportContent = document.getElementById('passport-content');
        if (!passportContent) return;
        
        // Find where to insert the recommendations section
        // We'll put it after the challenges section or reading stats
        let insertAfter = document.querySelector('.challenges-section');
        if (!insertAfter) {
            insertAfter = document.querySelector('.reading-stats');
        }
        if (!insertAfter) {
            insertAfter = document.querySelector('.reading-progress');
        }
        if (!insertAfter) return;
        
        // Create recommendations section
        const recommendationsSection = createRecommendationsSection();
        
        // Insert after the target element
        insertAfter.parentNode.insertBefore(recommendationsSection, insertAfter.nextSibling);
        
        // Generate recommendations
        generateRecommendations();
        
        // Set up event listeners for the toggle button
        const toggleButton = document.querySelector('.recommendations-toggle');
        const recommendationsContent = document.querySelector('.recommendations-content');
        
        if (toggleButton && recommendationsContent) {
            toggleButton.addEventListener('click', function() {
                const isCollapsed = recommendationsContent.classList.contains('collapsed');
                
                if (isCollapsed) {
                    recommendationsContent.classList.remove('collapsed');
                    toggleButton.classList.remove('collapsed');
                    toggleButton.querySelector('.recommendations-toggle-text').textContent = 'Hide';
                } else {
                    recommendationsContent.classList.add('collapsed');
                    toggleButton.classList.add('collapsed');
                    toggleButton.querySelector('.recommendations-toggle-text').textContent = 'Show';
                }
            });
        }
    }
    
    /**
     * Create the recommendations section HTML
     */
    function createRecommendationsSection() {
        const section = document.createElement('div');
        section.className = 'recommendations-section';
        
        // Create header
        const header = document.createElement('div');
        header.className = 'recommendations-header';
        
        const title = document.createElement('h2');
        title.className = 'recommendations-title';
        title.textContent = 'Book Recommendations';
        
        const toggle = document.createElement('button');
        toggle.className = 'recommendations-toggle';
        toggle.innerHTML = '<span class="recommendations-toggle-text">Hide</span><span class="recommendations-toggle-icon">▼</span>';
        
        header.appendChild(title);
        header.appendChild(toggle);
        
        // Create content container
        const content = document.createElement('div');
        content.className = 'recommendations-content';
        
        // Create recommendation groups container
        const recommendationGroups = document.createElement('div');
        recommendationGroups.className = 'recommendation-groups';
        recommendationGroups.id = 'recommendation-groups';
        
        // Add elements to the section
        section.appendChild(header);
        section.appendChild(content);
        content.appendChild(recommendationGroups);
        
        return section;
    }
    
    /**
     * Generate book recommendations based on user's reading history
     */
    function generateRecommendations() {
        const userData = getStoredData() || { books: {}, ratings: {} };
        const recommendationGroups = document.getElementById('recommendation-groups');
        
        if (!recommendationGroups) return;
        
        // Clear existing recommendations
        recommendationGroups.innerHTML = '';
        
        // Check if user has read any books
        const readBooks = Object.keys(userData.books || {}).filter(bookId => userData.books[bookId]);
        
        if (readBooks.length === 0) {
            // No books read yet, show general recommendations
            addGeneralRecommendations(recommendationGroups);
        } else {
            // Generate recommendations based on read books
            
            // 1. Based on highest rated books
            if (userData.ratings && Object.keys(userData.ratings).length > 0) {
                addHighestRatedRecommendations(recommendationGroups, userData);
            }
            
            // 2. Based on recently read books
            addSimilarBooksRecommendations(recommendationGroups, readBooks);
            
            // 3. Based on categories user has shown interest in
            addCategoryBasedRecommendations(recommendationGroups, readBooks);
        }
    }
    
    /**
     * Add general recommendations for new users
     */
    function addGeneralRecommendations(container) {
        // Create recommendation group
        const group = document.createElement('div');
        group.className = 'recommendation-group';
        
        // Create group header
        const header = document.createElement('div');
        header.className = 'recommendation-group-header';
        
        const title = document.createElement('h3');
        title.className = 'recommendation-group-title';
        title.textContent = 'Recommended for New Readers';
        
        const description = document.createElement('p');
        description.className = 'recommendation-group-description';
        description.textContent = 'Popular books to get you started with Luigi\'s collection';
        
        header.appendChild(title);
        header.appendChild(description);
        
        // Create recommendation list
        const list = document.createElement('div');
        list.className = 'recommendation-list';
        
        // Add some popular books
        const popularBooks = ['sapiens', 'educated', 'midnight-library', 'shoe-dog'];
        
        popularBooks.forEach(bookId => {
            if (bookData[bookId]) {
                const book = bookData[bookId];
                const item = createRecommendationItem(book, 'Highly recommended by Luigi');
                list.appendChild(item);
            }
        });
        
        // Add elements to the group
        group.appendChild(header);
        group.appendChild(list);
        
        // Add group to container
        container.appendChild(group);
    }
    
    /**
     * Add recommendations based on user's highest rated books
     */
    function addHighestRatedRecommendations(container, userData) {
        // Get user's ratings
        const ratings = userData.ratings || {};
        
        // Find books rated 4 or 5 stars
        const highlyRated = Object.keys(ratings)
            .filter(bookId => ratings[bookId] >= 4)
            .sort((a, b) => ratings[b] - ratings[a]);
        
        if (highlyRated.length === 0) return;
        
        // Create recommendation group
        const group = document.createElement('div');
        group.className = 'recommendation-group';
        
        // Create group header
        const header = document.createElement('div');
        header.className = 'recommendation-group-header';
        
        const title = document.createElement('h3');
        title.className = 'recommendation-group-title';
        title.textContent = 'Because You Enjoyed';
        
        const description = document.createElement('p');
        description.className = 'recommendation-group-description';
        description.textContent = 'Recommendations based on books you rated highly';
        
        header.appendChild(title);
        header.appendChild(description);
        
        // Create recommendation list
        const list = document.createElement('div');
        list.className = 'recommendation-list';
        
        // Get recommendations based on highly rated books
        const recommendedBooks = new Set();
        
        highlyRated.slice(0, 2).forEach(bookId => {
            if (bookData[bookId] && bookData[bookId].similar) {
                bookData[bookId].similar.forEach(similarBookId => {
                    // Only recommend books the user hasn't read yet
                    if (!userData.books || !userData.books[similarBookId]) {
                        recommendedBooks.add(similarBookId);
                    }
                });
            }
        });
        
        if (recommendedBooks.size === 0) {
            // No recommendations found
            const noRecommendations = document.createElement('p');
            noRecommendations.className = 'no-recommendations';
            noRecommendations.textContent = 'No recommendations found based on your ratings. Try rating more books!';
            list.appendChild(noRecommendations);
        } else {
            // Add recommendations to the list
            Array.from(recommendedBooks).slice(0, 4).forEach(bookId => {
                if (bookData[bookId]) {
                    const book = bookData[bookId];
                    const sourceBook = highlyRated[0];
                    const reason = `Similar to ${bookData[sourceBook].title} which you rated highly`;
                    const item = createRecommendationItem(book, reason);
                    list.appendChild(item);
                }
            });
        }
        
        // Add elements to the group
        group.appendChild(header);
        group.appendChild(list);
        
        // Add group to container
        container.appendChild(group);
    }
    
    /**
     * Add recommendations based on similar books to what the user has read
     */
    function addSimilarBooksRecommendations(container, readBooks) {
        if (readBooks.length === 0) return;
        
        // Create recommendation group
        const group = document.createElement('div');
        group.className = 'recommendation-group';
        
        // Create group header
        const header = document.createElement('div');
        header.className = 'recommendation-group-header';
        
        const title = document.createElement('h3');
        title.className = 'recommendation-group-title';
        title.textContent = 'Similar to Books You\'ve Read';
        
        const description = document.createElement('p');
        description.className = 'recommendation-group-description';
        description.textContent = 'Books that are similar to ones you\'ve already completed';
        
        header.appendChild(title);
        header.appendChild(description);
        
        // Create recommendation list
        const list = document.createElement('div');
        list.className = 'recommendation-list';
        
        // Get recommendations based on read books
        const recommendedBooks = new Set();
        const userData = getStoredData() || { books: {} };
        
        // Use the most recently read books (up to 3)
        readBooks.slice(0, 3).forEach(bookId => {
            if (bookData[bookId] && bookData[bookId].similar) {
                bookData[bookId].similar.forEach(similarBookId => {
                    // Only recommend books the user hasn't read yet
                    if (!userData.books || !userData.books[similarBookId]) {
                        recommendedBooks.add(similarBookId);
                    }
                });
            }
        });
        
        if (recommendedBooks.size === 0) {
            // No recommendations found
            const noRecommendations = document.createElement('p');
            noRecommendations.className = 'no-recommendations';
            noRecommendations.textContent = 'No similar books found. Try reading more books!';
            list.appendChild(noRecommendations);
        } else {
            // Add recommendations to the list
            Array.from(recommendedBooks).slice(0, 4).forEach(bookId => {
                if (bookData[bookId]) {
                    const book = bookData[bookId];
                    const sourceBook = readBooks[0];
                    const reason = `Similar to ${bookData[sourceBook].title} which you've read`;
                    const item = createRecommendationItem(book, reason);
                    list.appendChild(item);
                }
            });
        }
        
        // Add elements to the group
        group.appendChild(header);
        group.appendChild(list);
        
        // Add group to container
        container.appendChild(group);
    }
    
    /**
     * Add recommendations based on categories the user has shown interest in
     */
    function addCategoryBasedRecommendations(container, readBooks) {
        if (readBooks.length === 0) return;
        
        // Count books read in each category
        const categoryCount = {};
        const userData = getStoredData() || { books: {} };
        
        readBooks.forEach(bookId => {
            if (bookData[bookId] && bookData[bookId].category) {
                const category = bookData[bookId].category;
                categoryCount[category] = (categoryCount[category] || 0) + 1;
            }
        });
        
        // Find the most read category
        let topCategory = null;
        let maxCount = 0;
        
        Object.keys(categoryCount).forEach(category => {
            if (categoryCount[category] > maxCount) {
                maxCount = categoryCount[category];
                topCategory = category;
            }
        });
        
        if (!topCategory) return;
        
        // Create recommendation group
        const group = document.createElement('div');
        group.className = 'recommendation-group';
        
        // Create group header
        const header = document.createElement('div');
        header.className = 'recommendation-group-header';
        
        const title = document.createElement('h3');
        title.className = 'recommendation-group-title';
        title.textContent = `More ${formatCategoryName(topCategory)} Books`;
        
        const description = document.createElement('p');
        description.className = 'recommendation-group-description';
        description.textContent = `Based on your interest in ${formatCategoryName(topCategory)}`;
        
        header.appendChild(title);
        header.appendChild(description);
        
        // Create recommendation list
        const list = document.createElement('div');
        list.className = 'recommendation-list';
        
        // Find unread books in the top category
        const unreadBooks = Object.keys(bookData)
            .filter(bookId => {
                return bookData[bookId].category === topCategory && 
                       (!userData.books || !userData.books[bookId]);
            });
        
        if (unreadBooks.length === 0) {
            // No recommendations found
            const noRecommendations = document.createElement('p');
            noRecommendations.className = 'no-recommendations';
            noRecommendations.textContent = `You've read all the ${formatCategoryName(topCategory)} books!`;
            list.appendChild(noRecommendations);
        } else {
            // Add recommendations to the list
            unreadBooks.forEach(bookId => {
                if (bookData[bookId]) {
                    const book = bookData[bookId];
                    const reason = `More ${formatCategoryName(topCategory)} for your collection`;
                    const item = createRecommendationItem(book, reason);
                    list.appendChild(item);
                }
            });
        }
        
        // Add elements to the group
        group.appendChild(header);
        group.appendChild(list);
        
        // Add group to container
        container.appendChild(group);
    }
    
    /**
     * Create a recommendation item
     */
    function createRecommendationItem(book, reason) {
        const item = document.createElement('div');
        item.className = 'recommendation-item';
        item.dataset.id = book.id;
        
        // Create book cover
        const cover = document.createElement('div');
        cover.className = 'recommendation-cover';
        
        // Find the book cover image from the existing book entries
        const bookEntry = document.querySelector(`.book-checkbox[data-book="${book.id}"]`);
        let coverUrl = '';
        
        if (bookEntry) {
            const bookCoverImg = bookEntry.closest('.book-entry').querySelector('.book-cover img');
            if (bookCoverImg) {
                coverUrl = bookCoverImg.src;
            }
        }
        
        const coverImg = document.createElement('img');
        coverImg.src = coverUrl || 'https://via.placeholder.com/150x200?text=No+Cover';
        coverImg.alt = `${book.title} cover`;
        cover.appendChild(coverImg);
        
        // Create book details
        const details = document.createElement('div');
        details.className = 'recommendation-details';
        
        const title = document.createElement('h4');
        title.className = 'recommendation-title';
        title.textContent = book.title;
        
        const author = document.createElement('p');
        author.className = 'recommendation-author';
        author.textContent = `by ${book.author}`;
        
        const reasonEl = document.createElement('p');
        reasonEl.className = 'recommendation-reason';
        reasonEl.textContent = reason;
        
        details.appendChild(title);
        details.appendChild(author);
        details.appendChild(reasonEl);
        
        // Create actions
        const actions = document.createElement('div');
        actions.className = 'recommendation-actions';
        
        // Create "View Book" button that scrolls to the book in the list
        const viewButton = document.createElement('a');
        viewButton.className = 'recommendation-button';
        viewButton.textContent = 'View Book';
        viewButton.href = '#';
        viewButton.addEventListener('click', function(e) {
            e.preventDefault();
            scrollToBook(book.id);
        });
        
        actions.appendChild(viewButton);
        details.appendChild(actions);
        
        // Add elements to the item
        item.appendChild(cover);
        item.appendChild(details);
        
        return item;
    }
    
    /**
     * Scroll to a specific book in the list
     */
    function scrollToBook(bookId) {
        const bookEntry = document.querySelector(`.book-checkbox[data-book="${bookId}"]`);
        
        if (bookEntry) {
            const bookElement = bookEntry.closest('.book-entry');
            
            if (bookElement) {
                // Scroll to the book
                bookElement.scrollIntoView({ behavior: 'smooth', block: 'center' });
                
                // Highlight the book temporarily
                bookElement.style.transition = 'background-color 0.5s ease';
                bookElement.style.backgroundColor = '#fffde7';
                
                setTimeout(() => {
                    bookElement.style.backgroundColor = '';
                    setTimeout(() => {
                        bookElement.style.transition = '';
                    }, 500);
                }, 1500);
            }
        }
    }
    
    /**
     * Format a category name for display
     */
    function formatCategoryName(category) {
        return category
            .split('-')
            .map(word => word.charAt(0).toUpperCase() + word.slice(1))
            .join(' & ');
    }
    
    /**
     * Get stored user data from localStorage
     */
    function getStoredData() {
        const storedData = localStorage.getItem(STORAGE_KEY);
        return storedData ? JSON.parse(storedData) : null;
    }
});