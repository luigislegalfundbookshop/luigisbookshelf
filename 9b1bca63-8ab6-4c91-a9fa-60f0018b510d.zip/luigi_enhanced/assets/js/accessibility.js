// Luigi's Bookshelf - Accessibility Improvements

document.addEventListener('DOMContentLoaded', function() {
    // Constants
    const STORAGE_KEY = "luigis_bookshop_data";
    const A11Y_KEY = "accessibility_settings";
    
    // Initialize accessibility features
    initAccessibility();
    
    /**
     * Initialize accessibility features
     */
    function initAccessibility() {
        // Add skip to content link
        addSkipToContentLink();
        
        // Add accessibility toolbar
        addAccessibilityToolbar();
        
        // Add ARIA attributes to improve screen reader experience
        enhanceAriaAttributes();
        
        // Improve keyboard navigation
        enhanceKeyboardNavigation();
        
        // Apply saved accessibility settings
        applySavedSettings();
    }
    
    /**
     * Add skip to content link
     */
    function addSkipToContentLink() {
        // Create skip link
        const skipLink = document.createElement('a');
        skipLink.href = '#passport-content';
        skipLink.className = 'skip-to-content';
        skipLink.textContent = 'Skip to content';
        
        // Add to the beginning of the body
        document.body.insertBefore(skipLink, document.body.firstChild);
    }
    
    /**
     * Add accessibility toolbar
     */
    function addAccessibilityToolbar() {
        // Create toolbar container
        const toolbar = document.createElement('div');
        toolbar.className = 'accessibility-toolbar';
        toolbar.setAttribute('aria-label', 'Accessibility options');
        
        // Create toggle button
        const toggleButton = document.createElement('button');
        toggleButton.className = 'accessibility-toggle';
        toggleButton.setAttribute('aria-label', 'Toggle accessibility toolbar');
        toggleButton.innerHTML = '♿';
        
        // Create toolbar content
        const toolbarContent = document.createElement('div');
        toolbarContent.className = 'accessibility-toolbar-content';
        
        // Add text size options
        const textSizeOption = createAccessibilityOption(
            'Text Size',
            [
                { id: 'text-size-normal', text: 'Normal', value: 'normal' },
                { id: 'text-size-medium', text: 'Medium', value: 'medium' },
                { id: 'text-size-large', text: 'Large', value: 'large' },
                { id: 'text-size-xlarge', text: 'X-Large', value: 'xlarge' }
            ],
            'text-size',
            'normal',
            handleTextSizeChange
        );
        toolbarContent.appendChild(textSizeOption);
        
        // Add contrast options
        const contrastOption = createAccessibilityOption(
            'Contrast',
            [
                { id: 'contrast-normal', text: 'Normal', value: 'normal' },
                { id: 'contrast-high', text: 'High Contrast', value: 'high' }
            ],
            'contrast',
            'normal',
            handleContrastChange
        );
        toolbarContent.appendChild(contrastOption);
        
        // Add text spacing options
        const spacingOption = createAccessibilityOption(
            'Text Spacing',
            [
                { id: 'spacing-normal', text: 'Normal', value: 'normal' },
                { id: 'spacing-increased', text: 'Increased', value: 'increased' }
            ],
            'spacing',
            'normal',
            handleSpacingChange
        );
        toolbarContent.appendChild(spacingOption);
        
        // Add font options
        const fontOption = createAccessibilityOption(
            'Font',
            [
                { id: 'font-normal', text: 'Normal', value: 'normal' },
                { id: 'font-dyslexic', text: 'Dyslexic Friendly', value: 'dyslexic' }
            ],
            'font',
            'normal',
            handleFontChange
        );
        toolbarContent.appendChild(fontOption);
        
        // Add motion options
        const motionOption = createAccessibilityOption(
            'Motion',
            [
                { id: 'motion-normal', text: 'Normal', value: 'normal' },
                { id: 'motion-reduced', text: 'Reduced', value: 'reduced' }
            ],
            'motion',
            'normal',
            handleMotionChange
        );
        toolbarContent.appendChild(motionOption);
        
        // Add reset button
        const resetButton = document.createElement('button');
        resetButton.className = 'accessibility-button';
        resetButton.textContent = 'Reset All Settings';
        resetButton.addEventListener('click', resetAccessibilitySettings);
        toolbarContent.appendChild(resetButton);
        
        // Add toggle functionality
        toggleButton.addEventListener('click', function() {
            toolbar.classList.toggle('expanded');
            const isExpanded = toolbar.classList.contains('expanded');
            toggleButton.setAttribute('aria-expanded', isExpanded);
        });
        
        // Add elements to the toolbar
        toolbar.appendChild(toggleButton);
        toolbar.appendChild(toolbarContent);
        
        // Add to the document
        document.body.appendChild(toolbar);
    }
    
    /**
     * Create an accessibility option group
     */
    function createAccessibilityOption(label, options, name, defaultValue, changeHandler) {
        const optionContainer = document.createElement('div');
        optionContainer.className = 'accessibility-option';
        
        const optionLabel = document.createElement('span');
        optionLabel.className = 'accessibility-option-label';
        optionLabel.textContent = label;
        
        const buttonsContainer = document.createElement('div');
        buttonsContainer.className = 'accessibility-buttons';
        
        options.forEach(option => {
            const button = document.createElement('button');
            button.id = option.id;
            button.className = 'accessibility-button';
            button.textContent = option.text;
            button.dataset.value = option.value;
            button.dataset.option = name;
            
            if (option.value === defaultValue) {
                button.classList.add('active');
            }
            
            button.addEventListener('click', function() {
                // Remove active class from all buttons in this group
                buttonsContainer.querySelectorAll('.accessibility-button').forEach(btn => {
                    btn.classList.remove('active');
                });
                
                // Add active class to clicked button
                this.classList.add('active');
                
                // Call change handler
                changeHandler(option.value);
                
                // Save setting
                saveAccessibilitySetting(name, option.value);
            });
            
            buttonsContainer.appendChild(button);
        });
        
        optionContainer.appendChild(optionLabel);
        optionContainer.appendChild(buttonsContainer);
        
        return optionContainer;
    }
    
    /**
     * Handle text size change
     */
    function handleTextSizeChange(value) {
        // Remove existing text size classes
        document.body.classList.remove('text-size-medium', 'text-size-large', 'text-size-xlarge');
        
        // Add new class if not normal
        if (value !== 'normal') {
            document.body.classList.add(`text-size-${value}`);
        }
    }
    
    /**
     * Handle contrast change
     */
    function handleContrastChange(value) {
        // Toggle high contrast class
        if (value === 'high') {
            document.documentElement.classList.add('high-contrast');
        } else {
            document.documentElement.classList.remove('high-contrast');
        }
    }
    
    /**
     * Handle text spacing change
     */
    function handleSpacingChange(value) {
        // Toggle increased spacing class
        if (value === 'increased') {
            document.body.classList.add('increased-spacing');
        } else {
            document.body.classList.remove('increased-spacing');
        }
    }
    
    /**
     * Handle font change
     */
    function handleFontChange(value) {
        // Toggle dyslexic font class
        if (value === 'dyslexic') {
            document.body.classList.add('dyslexic-font');
            
            // Load dyslexic font if not already loaded
            if (!document.getElementById('dyslexic-font')) {
                const fontLink = document.createElement('link');
                fontLink.id = 'dyslexic-font';
                fontLink.rel = 'stylesheet';
                fontLink.href = 'https://cdn.jsdelivr.net/npm/open-dyslexic@1.0.3/open-dyslexic-regular.css';
                document.head.appendChild(fontLink);
            }
        } else {
            document.body.classList.remove('dyslexic-font');
        }
    }
    
    /**
     * Handle motion change
     */
    function handleMotionChange(value) {
        // Toggle reduced motion class
        if (value === 'reduced') {
            document.body.classList.add('reduced-motion');
        } else {
            document.body.classList.remove('reduced-motion');
        }
    }
    
    /**
     * Reset all accessibility settings
     */
    function resetAccessibilitySettings() {
        // Remove all accessibility classes
        document.body.classList.remove(
            'text-size-medium', 
            'text-size-large', 
            'text-size-xlarge',
            'increased-spacing',
            'dyslexic-font',
            'reduced-motion'
        );
        document.documentElement.classList.remove('high-contrast');
        
        // Reset all buttons to default
        document.querySelectorAll('.accessibility-button').forEach(button => {
            button.classList.remove('active');
            
            // Find the default button in each group
            if (button.dataset.value === 'normal') {
                button.classList.add('active');
            }
        });
        
        // Clear saved settings
        const userData = getStoredData() || {};
        userData[A11Y_KEY] = {
            'text-size': 'normal',
            'contrast': 'normal',
            'spacing': 'normal',
            'font': 'normal',
            'motion': 'normal'
        };
        storeData(userData);
    }
    
    /**
     * Save accessibility setting
     */
    function saveAccessibilitySetting(name, value) {
        const userData = getStoredData() || {};
        
        // Initialize accessibility settings if needed
        if (!userData[A11Y_KEY]) {
            userData[A11Y_KEY] = {};
        }
        
        // Save setting
        userData[A11Y_KEY][name] = value;
        
        // Store data
        storeData(userData);
    }
    
    /**
     * Apply saved accessibility settings
     */
    function applySavedSettings() {
        const userData = getStoredData() || {};
        const settings = userData[A11Y_KEY] || {};
        
        // Apply each setting if it exists
        if (settings['text-size']) {
            handleTextSizeChange(settings['text-size']);
            setActiveButton('text-size', settings['text-size']);
        }
        
        if (settings['contrast']) {
            handleContrastChange(settings['contrast']);
            setActiveButton('contrast', settings['contrast']);
        }
        
        if (settings['spacing']) {
            handleSpacingChange(settings['spacing']);
            setActiveButton('spacing', settings['spacing']);
        }
        
        if (settings['font']) {
            handleFontChange(settings['font']);
            setActiveButton('font', settings['font']);
        }
        
        if (settings['motion']) {
            handleMotionChange(settings['motion']);
            setActiveButton('motion', settings['motion']);
        }
    }
    
    /**
     * Set the active button for a setting
     */
    function setActiveButton(option, value) {
        document.querySelectorAll(`.accessibility-button[data-option="${option}"]`).forEach(button => {
            button.classList.remove('active');
            if (button.dataset.value === value) {
                button.classList.add('active');
            }
        });
    }
    
    /**
     * Enhance ARIA attributes for better screen reader experience
     */
    function enhanceAriaAttributes() {
        // Add ARIA landmark roles
        document.querySelector('header')?.setAttribute('role', 'banner');
        document.querySelector('nav')?.setAttribute('role', 'navigation');
        document.querySelector('main')?.setAttribute('role', 'main');
        document.querySelector('footer')?.setAttribute('role', 'contentinfo');
        
        // Add ARIA labels to sections
        document.querySelector('.reading-progress')?.setAttribute('aria-label', 'Reading Progress');
        document.querySelector('.book-categories')?.setAttribute('aria-label', 'Book Categories');
        
        // Add ARIA labels to interactive elements
        document.querySelectorAll('.book-checkbox').forEach(checkbox => {
            const bookTitle = checkbox.closest('.book-entry')?.querySelector('.book-title')?.textContent;
            if (bookTitle) {
                checkbox.setAttribute('aria-label', `Mark ${bookTitle} as read`);
            }
        });
        
        // Add ARIA attributes to category navigation
        const categoryNav = document.querySelector('.category-nav');
        if (categoryNav) {
            categoryNav.setAttribute('role', 'navigation');
            categoryNav.setAttribute('aria-label', 'Book Categories');
        }
    }
    
    /**
     * Enhance keyboard navigation
     */
    function enhanceKeyboardNavigation() {
        // Make book entries focusable
        document.querySelectorAll('.book-entry').forEach(book => {
            book.setAttribute('tabindex', '0');
            
            // Add keyboard event listener
            book.addEventListener('keydown', function(e) {
                // Enter or Space key
                if (e.key === 'Enter' || e.key === ' ') {
                    e.preventDefault();
                    // Trigger click on the book link
                    this.click();
                }
            });
        });
        
        // Improve focus management for modals
        document.addEventListener('keydown', function(e) {
            // Check if any modal is open
            const openModal = document.querySelector('.notes-modal.show');
            if (openModal && e.key === 'Escape') {
                // Close the modal on Escape key
                const closeButton = openModal.querySelector('.notes-modal-close');
                if (closeButton) {
                    closeButton.click();
                }
            }
        });
    }
    
    /**
     * Get stored user data from localStorage
     */
    function getStoredData() {
        const storedData = localStorage.getItem(STORAGE_KEY);
        return storedData ? JSON.parse(storedData) : null;
    }
    
    /**
     * Store user data to localStorage
     */
    function storeData(data) {
        localStorage.setItem(STORAGE_KEY, JSON.stringify(data));
    }
});