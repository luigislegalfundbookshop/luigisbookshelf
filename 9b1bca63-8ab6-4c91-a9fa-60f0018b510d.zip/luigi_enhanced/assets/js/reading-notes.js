// Luigi's Bookshelf - Reading Notes

document.addEventListener('DOMContentLoaded', function() {
    // Constants
    const STORAGE_KEY = "luigis_bookshop_data";
    const NOTES_KEY = "book_notes";
    
    // Initialize the reading notes
    initReadingNotes();
    
    /**
     * Initialize the reading notes feature
     */
    function initReadingNotes() {
        // Add notes buttons to each book
        addNotesButtons();
        
        // Create notes modal
        createNotesModal();
        
        // Set up event listeners for the modal
        setupModalEvents();
    }
    
    /**
     * Add notes buttons to each book
     */
    function addNotesButtons() {
        // Get all book entries
        const bookEntries = document.querySelectorAll('.book-entry');
        
        // Add notes button to each book
        bookEntries.forEach(book => {
            // Get book ID from the checkbox
            const checkbox = book.querySelector('.book-checkbox');
            if (!checkbox) return;
            
            const bookId = checkbox.getAttribute('data-book');
            
            // Get the book details div to add our notes button
            const bookDetails = book.querySelector('.book-details');
            if (!bookDetails) return;
            
            // Create notes button
            const notesButton = document.createElement('button');
            notesButton.className = 'book-notes-button';
            notesButton.dataset.bookId = bookId;
            
            // Get notes count for this book
            const notesCount = getBookNotesCount(bookId);
            
            // Set button content
            notesButton.innerHTML = `
                <span class="book-notes-button-icon">📝</span>
                <span>Notes</span>
                ${notesCount > 0 ? `<span class="book-notes-count">${notesCount}</span>` : ''}
            `;
            
            // Add click event listener
            notesButton.addEventListener('click', function(e) {
                e.preventDefault();
                openNotesModal(bookId);
            });
            
            // Add button to book details
            bookDetails.appendChild(notesButton);
        });
    }
    
    /**
     * Create the notes modal
     */
    function createNotesModal() {
        // Check if modal already exists
        if (document.getElementById('notes-modal')) return;
        
        // Create modal container
        const modal = document.createElement('div');
        modal.className = 'notes-modal';
        modal.id = 'notes-modal';
        
        // Create modal content
        const modalContent = document.createElement('div');
        modalContent.className = 'notes-modal-content';
        
        // Create modal header
        const modalHeader = document.createElement('div');
        modalHeader.className = 'notes-modal-header';
        
        const modalTitle = document.createElement('h2');
        modalTitle.className = 'notes-modal-title';
        modalTitle.textContent = 'Book Notes';
        
        const closeButton = document.createElement('button');
        closeButton.className = 'notes-modal-close';
        closeButton.innerHTML = '&times;';
        closeButton.setAttribute('aria-label', 'Close');
        
        modalHeader.appendChild(modalTitle);
        modalHeader.appendChild(closeButton);
        
        // Create modal body
        const modalBody = document.createElement('div');
        modalBody.className = 'notes-modal-body';
        modalBody.id = 'notes-modal-body';
        
        // Add elements to the modal
        modalContent.appendChild(modalHeader);
        modalContent.appendChild(modalBody);
        modal.appendChild(modalContent);
        
        // Add modal to the document
        document.body.appendChild(modal);
    }
    
    /**
     * Set up event listeners for the modal
     */
    function setupModalEvents() {
        const modal = document.getElementById('notes-modal');
        if (!modal) return;
        
        // Close button
        const closeButton = modal.querySelector('.notes-modal-close');
        if (closeButton) {
            closeButton.addEventListener('click', closeNotesModal);
        }
        
        // Close when clicking outside the modal content
        modal.addEventListener('click', function(e) {
            if (e.target === modal) {
                closeNotesModal();
            }
        });
        
        // Close on escape key
        document.addEventListener('keydown', function(e) {
            if (e.key === 'Escape' && modal.classList.contains('show')) {
                closeNotesModal();
            }
        });
    }
    
    /**
     * Open the notes modal for a specific book
     */
    function openNotesModal(bookId) {
        const modal = document.getElementById('notes-modal');
        const modalBody = document.getElementById('notes-modal-body');
        
        if (!modal || !modalBody) return;
        
        // Clear modal body
        modalBody.innerHTML = '';
        
        // Get book data
        const bookData = getBookData(bookId);
        if (!bookData) return;
        
        // Create book info section
        const bookInfo = createBookInfoSection(bookData);
        modalBody.appendChild(bookInfo);
        
        // Create notes list section
        const notesList = createNotesListSection(bookId);
        modalBody.appendChild(notesList);
        
        // Show the modal
        modal.classList.add('show');
        
        // Prevent body scrolling
        document.body.style.overflow = 'hidden';
    }
    
    /**
     * Close the notes modal
     */
    function closeNotesModal() {
        const modal = document.getElementById('notes-modal');
        if (!modal) return;
        
        // Hide the modal
        modal.classList.remove('show');
        
        // Restore body scrolling
        document.body.style.overflow = '';
    }
    
    /**
     * Create the book info section for the modal
     */
    function createBookInfoSection(bookData) {
        const bookInfo = document.createElement('div');
        bookInfo.className = 'notes-book-info';
        
        // Book cover
        const bookCover = document.createElement('div');
        bookCover.className = 'notes-book-cover';
        
        // Find the book cover image from the existing book entries
        const bookEntry = document.querySelector(`.book-checkbox[data-book="${bookData.id}"]`);
        let coverUrl = '';
        
        if (bookEntry) {
            const bookCoverImg = bookEntry.closest('.book-entry').querySelector('.book-cover img');
            if (bookCoverImg) {
                coverUrl = bookCoverImg.src;
            }
        }
        
        const coverImg = document.createElement('img');
        coverImg.src = coverUrl || 'https://via.placeholder.com/150x200?text=No+Cover';
        coverImg.alt = `${bookData.title} cover`;
        bookCover.appendChild(coverImg);
        
        // Book details
        const bookDetails = document.createElement('div');
        bookDetails.className = 'notes-book-details';
        
        const title = document.createElement('h3');
        title.className = 'notes-book-title';
        title.textContent = bookData.title;
        
        const author = document.createElement('p');
        author.className = 'notes-book-author';
        author.textContent = `by ${bookData.author}`;
        
        const summary = document.createElement('p');
        summary.className = 'notes-book-summary';
        summary.textContent = bookData.summary || 'No summary available.';
        
        bookDetails.appendChild(title);
        bookDetails.appendChild(author);
        bookDetails.appendChild(summary);
        
        // Add elements to the book info section
        bookInfo.appendChild(bookCover);
        bookInfo.appendChild(bookDetails);
        
        return bookInfo;
    }
    
    /**
     * Create the notes list section for the modal
     */
    function createNotesListSection(bookId) {
        const notesList = document.createElement('div');
        notesList.className = 'notes-list';
        
        // Notes list header
        const header = document.createElement('div');
        header.className = 'notes-list-header';
        
        const title = document.createElement('h3');
        title.className = 'notes-list-title';
        title.textContent = 'Your Notes';
        
        const actions = document.createElement('div');
        actions.className = 'notes-list-actions';
        
        const addButton = document.createElement('button');
        addButton.className = 'notes-list-button';
        addButton.innerHTML = '<span class="notes-list-button-icon">+</span> Add Note';
        addButton.addEventListener('click', () => showNoteForm(bookId));
        
        actions.appendChild(addButton);
        header.appendChild(title);
        header.appendChild(actions);
        
        // Notes container
        const notesContainer = document.createElement('div');
        notesContainer.id = 'notes-container';
        
        // Get notes for this book
        const notes = getBookNotes(bookId);
        
        if (notes.length === 0) {
            // No notes yet
            const emptyMessage = document.createElement('div');
            emptyMessage.className = 'notes-empty';
            emptyMessage.textContent = 'You haven\'t added any notes for this book yet.';
            notesContainer.appendChild(emptyMessage);
        } else {
            // Add each note
            notes.forEach(note => {
                const noteItem = createNoteItem(note, bookId);
                notesContainer.appendChild(noteItem);
            });
        }
        
        // Add elements to the notes list section
        notesList.appendChild(header);
        notesList.appendChild(notesContainer);
        
        return notesList;
    }
    
    /**
     * Create a note item element
     */
    function createNoteItem(note, bookId) {
        const item = document.createElement('div');
        item.className = 'notes-item';
        item.dataset.id = note.id;
        
        // Note header
        const header = document.createElement('div');
        header.className = 'notes-item-header';
        
        const date = document.createElement('p');
        date.className = 'notes-item-date';
        date.textContent = formatDate(new Date(note.date));
        
        const actions = document.createElement('div');
        actions.className = 'notes-item-actions';
        
        const editButton = document.createElement('button');
        editButton.className = 'notes-item-button';
        editButton.innerHTML = '✏️';
        editButton.setAttribute('aria-label', 'Edit');
        editButton.addEventListener('click', () => editNote(note, bookId));
        
        const deleteButton = document.createElement('button');
        deleteButton.className = 'notes-item-button';
        deleteButton.innerHTML = '🗑️';
        deleteButton.setAttribute('aria-label', 'Delete');
        deleteButton.addEventListener('click', () => deleteNote(note.id, bookId));
        
        actions.appendChild(editButton);
        actions.appendChild(deleteButton);
        
        header.appendChild(date);
        header.appendChild(actions);
        
        // Note content
        const content = document.createElement('p');
        content.className = 'notes-item-content';
        content.textContent = note.content;
        
        // Note tags
        if (note.tags && note.tags.length > 0) {
            const tagsContainer = document.createElement('div');
            tagsContainer.className = 'notes-item-tags';
            
            note.tags.forEach(tag => {
                const tagElement = document.createElement('span');
                tagElement.className = 'notes-item-tag';
                tagElement.textContent = tag;
                tagsContainer.appendChild(tagElement);
            });
            
            item.appendChild(header);
            item.appendChild(content);
            item.appendChild(tagsContainer);
        } else {
            item.appendChild(header);
            item.appendChild(content);
        }
        
        return item;
    }
    
    /**
     * Show the note form for adding or editing a note
     */
    function showNoteForm(bookId, noteToEdit = null) {
        const notesContainer = document.getElementById('notes-container');
        if (!notesContainer) return;
        
        // Remove any existing form
        const existingForm = document.querySelector('.notes-form');
        if (existingForm) {
            existingForm.remove();
        }
        
        // Create form
        const form = document.createElement('div');
        form.className = 'notes-form';
        
        // Form title
        const formTitle = document.createElement('h3');
        formTitle.className = 'notes-form-title';
        formTitle.textContent = noteToEdit ? 'Edit Note' : 'Add New Note';
        
        // Note content
        const contentGroup = document.createElement('div');
        contentGroup.className = 'notes-form-group';
        
        const contentLabel = document.createElement('label');
        contentLabel.className = 'notes-form-label';
        contentLabel.textContent = 'Note';
        
        const contentInput = document.createElement('textarea');
        contentInput.className = 'notes-form-textarea';
        contentInput.id = 'note-content';
        contentInput.placeholder = 'Enter your note here...';
        if (noteToEdit) {
            contentInput.value = noteToEdit.content;
        }
        
        contentGroup.appendChild(contentLabel);
        contentGroup.appendChild(contentInput);
        
        // Tags
        const tagsGroup = document.createElement('div');
        tagsGroup.className = 'notes-form-group';
        
        const tagsLabel = document.createElement('label');
        tagsLabel.className = 'notes-form-label';
        tagsLabel.textContent = 'Tags (comma separated)';
        
        const tagsInput = document.createElement('input');
        tagsInput.className = 'notes-form-input';
        tagsInput.id = 'note-tags';
        tagsInput.placeholder = 'e.g., important, quote, chapter 1';
        if (noteToEdit && noteToEdit.tags) {
            tagsInput.value = noteToEdit.tags.join(', ');
        }
        
        tagsGroup.appendChild(tagsLabel);
        tagsGroup.appendChild(tagsInput);
        
        // Form actions
        const formActions = document.createElement('div');
        formActions.className = 'notes-form-actions';
        
        const cancelButton = document.createElement('button');
        cancelButton.className = 'notes-form-button secondary';
        cancelButton.textContent = 'Cancel';
        cancelButton.addEventListener('click', () => {
            form.remove();
            refreshNotesList(bookId);
        });
        
        const saveButton = document.createElement('button');
        saveButton.className = 'notes-form-button';
        saveButton.textContent = noteToEdit ? 'Update Note' : 'Save Note';
        saveButton.addEventListener('click', () => {
            const content = document.getElementById('note-content').value;
            const tags = document.getElementById('note-tags').value;
            
            if (content.trim() === '') {
                showNotesNotification('Please enter a note', true);
                return;
            }
            
            if (noteToEdit) {
                updateNote(noteToEdit.id, content, tags, bookId);
            } else {
                saveNote(content, tags, bookId);
            }
            
            form.remove();
            refreshNotesList(bookId);
        });
        
        formActions.appendChild(cancelButton);
        formActions.appendChild(saveButton);
        
        // Add elements to the form
        form.appendChild(formTitle);
        form.appendChild(contentGroup);
        form.appendChild(tagsGroup);
        form.appendChild(formActions);
        
        // Add form to the notes container
        if (noteToEdit) {
            // Insert before the note being edited
            const noteItem = document.querySelector(`.notes-item[data-id="${noteToEdit.id}"]`);
            if (noteItem) {
                noteItem.parentNode.insertBefore(form, noteItem);
                noteItem.style.display = 'none';
            } else {
                notesContainer.insertBefore(form, notesContainer.firstChild);
            }
        } else {
            // Add at the top for new notes
            notesContainer.insertBefore(form, notesContainer.firstChild);
        }
        
        // Focus on the content input
        contentInput.focus();
    }
    
    /**
     * Save a new note
     */
    function saveNote(content, tagsString, bookId) {
        // Parse tags
        const tags = tagsString
            .split(',')
            .map(tag => tag.trim())
            .filter(tag => tag !== '');
        
        // Create note object
        const note = {
            id: generateId(),
            bookId: bookId,
            content: content,
            tags: tags,
            date: new Date().toISOString()
        };
        
        // Get existing notes
        const userData = getStoredData() || {};
        if (!userData[NOTES_KEY]) {
            userData[NOTES_KEY] = [];
        }
        
        // Add new note
        userData[NOTES_KEY].push(note);
        
        // Save to localStorage
        storeData(userData);
        
        // Show notification
        showNotesNotification('Note saved successfully');
        
        // Update notes count on button
        updateNotesCount(bookId);
    }
    
    /**
     * Update an existing note
     */
    function updateNote(noteId, content, tagsString, bookId) {
        // Parse tags
        const tags = tagsString
            .split(',')
            .map(tag => tag.trim())
            .filter(tag => tag !== '');
        
        // Get existing notes
        const userData = getStoredData() || {};
        if (!userData[NOTES_KEY]) {
            userData[NOTES_KEY] = [];
        }
        
        // Find and update the note
        const noteIndex = userData[NOTES_KEY].findIndex(note => note.id === noteId);
        
        if (noteIndex !== -1) {
            userData[NOTES_KEY][noteIndex].content = content;
            userData[NOTES_KEY][noteIndex].tags = tags;
            userData[NOTES_KEY][noteIndex].lastEdited = new Date().toISOString();
            
            // Save to localStorage
            storeData(userData);
            
            // Show notification
            showNotesNotification('Note updated successfully');
        }
    }
    
    /**
     * Delete a note
     */
    function deleteNote(noteId, bookId) {
        if (confirm('Are you sure you want to delete this note?')) {
            // Get existing notes
            const userData = getStoredData() || {};
            if (!userData[NOTES_KEY]) {
                userData[NOTES_KEY] = [];
            }
            
            // Filter out the note to delete
            userData[NOTES_KEY] = userData[NOTES_KEY].filter(note => note.id !== noteId);
            
            // Save to localStorage
            storeData(userData);
            
            // Show notification
            showNotesNotification('Note deleted successfully');
            
            // Refresh notes list
            refreshNotesList(bookId);
            
            // Update notes count on button
            updateNotesCount(bookId);
        }
    }
    
    /**
     * Edit a note
     */
    function editNote(note, bookId) {
        showNoteForm(bookId, note);
    }
    
    /**
     * Refresh the notes list
     */
    function refreshNotesList(bookId) {
        const notesContainer = document.getElementById('notes-container');
        if (!notesContainer) return;
        
        // Clear container
        notesContainer.innerHTML = '';
        
        // Get notes for this book
        const notes = getBookNotes(bookId);
        
        if (notes.length === 0) {
            // No notes yet
            const emptyMessage = document.createElement('div');
            emptyMessage.className = 'notes-empty';
            emptyMessage.textContent = 'You haven\'t added any notes for this book yet.';
            notesContainer.appendChild(emptyMessage);
        } else {
            // Add each note
            notes.forEach(note => {
                const noteItem = createNoteItem(note, bookId);
                notesContainer.appendChild(noteItem);
            });
        }
    }
    
    /**
     * Update the notes count on a book's notes button
     */
    function updateNotesCount(bookId) {
        const notesButton = document.querySelector(`.book-notes-button[data-book-id="${bookId}"]`);
        if (!notesButton) return;
        
        // Get notes count
        const count = getBookNotesCount(bookId);
        
        // Update button
        if (count > 0) {
            // Check if count element already exists
            let countElement = notesButton.querySelector('.book-notes-count');
            
            if (countElement) {
                countElement.textContent = count;
            } else {
                // Create new count element
                const countSpan = document.createElement('span');
                countSpan.className = 'book-notes-count';
                countSpan.textContent = count;
                notesButton.appendChild(countSpan);
            }
        } else {
            // Remove count element if it exists
            const countElement = notesButton.querySelector('.book-notes-count');
            if (countElement) {
                countElement.remove();
            }
        }
    }
    
    /**
     * Get notes for a specific book
     */
    function getBookNotes(bookId) {
        const userData = getStoredData() || {};
        if (!userData[NOTES_KEY]) {
            return [];
        }
        
        // Filter notes for this book and sort by date (newest first)
        return userData[NOTES_KEY]
            .filter(note => note.bookId === bookId)
            .sort((a, b) => new Date(b.date) - new Date(a.date));
    }
    
    /**
     * Get the number of notes for a specific book
     */
    function getBookNotesCount(bookId) {
        return getBookNotes(bookId).length;
    }
    
    /**
     * Get book data by ID
     */
    function getBookData(bookId) {
        // This would normally come from a database
        // For this implementation, we're hardcoding the book data
        const bookData = {
            // Science & Philosophy
            'ape-universe': {
                id: 'ape-universe',
                title: 'The Ape that Understood the Universe',
                author: 'Steve Stewart-Williams',
                summary: 'A compelling look at human behavior through evolutionary psychology and culture.'
            },
            'code-book': {
                id: 'code-book',
                title: 'The Code Book',
                author: 'Simon Singh',
                summary: 'An engaging history of cryptography from ancient ciphers to quantum encryption.'
            },
            'brief-answers': {
                id: 'brief-answers',
                title: 'Brief Answers to the Big Questions',
                author: 'Stephen Hawking',
                summary: 'Hawking\'s final book tackles some of the universe\'s biggest questions.'
            },
            'sapiens': {
                id: 'sapiens',
                title: 'Sapiens',
                author: 'Yuval Noah Harari',
                summary: 'A brief history of humankind, exploring the ways in which biology and history have defined us.'
            },
            'thinking-fast-slow': {
                id: 'thinking-fast-slow',
                title: 'Thinking, Fast and Slow',
                author: 'Daniel Kahneman',
                summary: 'An exploration of the two systems that drive the way we think and make choices.'
            },
            'why-we-sleep': {
                id: 'why-we-sleep',
                title: 'Why We Sleep',
                author: 'Matthew Walker',
                summary: 'A fascinating dive into the science of sleep and dreams.'
            },
            
            // Memoir & Biography
            'educated': {
                id: 'educated',
                title: 'Educated',
                author: 'Tara Westover',
                summary: 'A memoir about a woman who leaves her survivalist family and goes on to earn a PhD.'
            },
            'becoming': {
                id: 'becoming',
                title: 'Becoming',
                author: 'Michelle Obama',
                summary: 'The former First Lady\'s memoir about her life journey from Chicago to the White House.'
            },
            'born-crime': {
                id: 'born-crime',
                title: 'Born a Crime',
                author: 'Trevor Noah',
                summary: 'Stories from Trevor Noah\'s South African childhood during the twilight of apartheid.'
            },
            'shoe-dog': {
                id: 'shoe-dog',
                title: 'Shoe Dog',
                author: 'Phil Knight',
                summary: 'A memoir by the creator of Nike about building the world\'s most innovative brand.'
            },
            'elon-musk': {
                id: 'elon-musk',
                title: 'Elon Musk',
                author: 'Walter Isaacson',
                summary: 'A biography of the entrepreneur behind Tesla, SpaceX, and more.'
            },
            'greenlights': {
                id: 'greenlights',
                title: 'Greenlights',
                author: 'Matthew McConaughey',
                summary: 'The actor shares his unconventional wisdom and lessons learned the hard way.'
            },
            
            // Fiction
            'project-hail-mary': {
                id: 'project-hail-mary',
                title: 'Project Hail Mary',
                author: 'Andy Weir',
                summary: 'A lone astronaut must save humanity from an extinction-level threat.'
            },
            'midnight-library': {
                id: 'midnight-library',
                title: 'The Midnight Library',
                author: 'Matt Haig',
                summary: 'A library beyond the edge of the universe contains books with all the different lives you could have lived.'
            },
            'invisible-life': {
                id: 'invisible-life',
                title: 'The Invisible Life of Addie LaRue',
                author: 'V.E. Schwab',
                summary: 'A young woman makes a Faustian bargain to live forever but is cursed to be forgotten by everyone she meets.'
            },
            'circe': {
                id: 'circe',
                title: 'Circe',
                author: 'Madeline Miller',
                summary: 'A bold and subversive retelling of the goddess\'s story from Homer\'s Odyssey.'
            },
            'brave-new-world': {
                id: 'brave-new-world',
                title: 'Brave New World',
                author: 'Aldous Huxley',
                summary: 'A dystopian novel set in a futuristic World State of genetically modified citizens.'
            },
            '1984': {
                id: '1984',
                title: '1984',
                author: 'George Orwell',
                summary: 'A dystopian social science fiction novel and cautionary tale about totalitarianism.'
            }
        };
        
        return bookData[bookId] || null;
    }
    
    /**
     * Show a notification for notes actions
     */
    function showNotesNotification(message, isError = false) {
        // Create notification element if it doesn't exist
        let notification = document.getElementById('notes-notification');
        if (!notification) {
            notification = document.createElement('div');
            notification.id = 'notes-notification';
            notification.className = 'notes-notification';
            document.body.appendChild(notification);
        }
        
        // Set notification message
        notification.textContent = message;
        
        // Set error styling if needed
        if (isError) {
            notification.classList.add('error');
        } else {
            notification.classList.remove('error');
        }
        
        // Show notification
        notification.classList.add('show');
        
        // Hide notification after 3 seconds
        setTimeout(() => {
            notification.classList.remove('show');
        }, 3000);
    }
    
    /**
     * Format a date to a readable string
     */
    function formatDate(date) {
        const options = { 
            year: 'numeric', 
            month: 'short', 
            day: 'numeric',
            hour: '2-digit',
            minute: '2-digit'
        };
        return date.toLocaleDateString(undefined, options);
    }
    
    /**
     * Generate a unique ID
     */
    function generateId() {
        return 'note_' + Date.now() + '_' + Math.random().toString(36).substr(2, 9);
    }
    
    /**
     * Get stored user data from localStorage
     */
    function getStoredData() {
        const storedData = localStorage.getItem(STORAGE_KEY);
        return storedData ? JSON.parse(storedData) : null;
    }
    
    /**
     * Store user data to localStorage
     */
    function storeData(data) {
        localStorage.setItem(STORAGE_KEY, JSON.stringify(data));
    }
});