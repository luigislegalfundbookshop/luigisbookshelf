// Luigi's Bookshelf - Reading Challenges

document.addEventListener('DOMContentLoaded', function() {
    // Constants
    const STORAGE_KEY = "luigis_bookshop_data";
    const CHALLENGES_KEY = "reading_challenges";
    const MS_PER_DAY = 86400000; // Milliseconds in a day
    
    // Initialize the reading challenges
    initReadingChallenges();
    
    /**
     * Initialize the reading challenges section
     */
    function initReadingChallenges() {
        // Get the passport content div
        const passportContent = document.getElementById('passport-content');
        if (!passportContent) return;
        
        // Find where to insert the challenges section
        // We'll put it after the reading stats or progress section
        let insertAfter = document.querySelector('.reading-stats');
        if (!insertAfter) {
            insertAfter = document.querySelector('.reading-progress');
        }
        if (!insertAfter) return;
        
        // Create challenges section
        const challengesSection = createChallengesSection();
        
        // Insert after the target element
        insertAfter.parentNode.insertBefore(challengesSection, insertAfter.nextSibling);
        
        // Load existing challenges
        loadChallenges();
        
        // Set up event listeners for the toggle button
        const toggleButton = document.querySelector('.challenges-toggle');
        const challengesContent = document.querySelector('.challenges-content');
        
        if (toggleButton && challengesContent) {
            toggleButton.addEventListener('click', function() {
                const isCollapsed = challengesContent.classList.contains('collapsed');
                
                if (isCollapsed) {
                    challengesContent.classList.remove('collapsed');
                    toggleButton.classList.remove('collapsed');
                    toggleButton.querySelector('.challenges-toggle-text').textContent = 'Hide';
                } else {
                    challengesContent.classList.add('collapsed');
                    toggleButton.classList.add('collapsed');
                    toggleButton.querySelector('.challenges-toggle-text').textContent = 'Show';
                }
            });
        }
        
        // Set up event listener for the "Create Challenge" button
        const createChallengeBtn = document.getElementById('create-challenge-btn');
        if (createChallengeBtn) {
            createChallengeBtn.addEventListener('click', showCreateChallengeForm);
        }
    }
    
    /**
     * Create the challenges section HTML
     */
    function createChallengesSection() {
        const section = document.createElement('div');
        section.className = 'challenges-section';
        
        // Create header
        const header = document.createElement('div');
        header.className = 'challenges-header';
        
        const title = document.createElement('h2');
        title.className = 'challenges-title';
        title.textContent = 'Reading Challenges';
        
        const toggle = document.createElement('button');
        toggle.className = 'challenges-toggle';
        toggle.innerHTML = '<span class="challenges-toggle-text">Hide</span><span class="challenges-toggle-icon">▼</span>';
        
        header.appendChild(title);
        header.appendChild(toggle);
        
        // Create content container
        const content = document.createElement('div');
        content.className = 'challenges-content';
        
        // Create challenge list
        const challengeList = document.createElement('ul');
        challengeList.className = 'challenge-list';
        challengeList.id = 'challenge-list';
        
        // Create "Create Challenge" button
        const createButton = document.createElement('button');
        createButton.className = 'challenge-button';
        createButton.id = 'create-challenge-btn';
        createButton.textContent = 'Create New Challenge';
        
        // Add elements to the section
        section.appendChild(header);
        section.appendChild(content);
        content.appendChild(challengeList);
        content.appendChild(createButton);
        
        return section;
    }
    
    /**
     * Load challenges from localStorage
     */
    function loadChallenges() {
        const challenges = getChallenges();
        const challengeList = document.getElementById('challenge-list');
        
        if (!challengeList) return;
        
        // Clear existing challenges
        challengeList.innerHTML = '';
        
        if (challenges.length === 0) {
            // No challenges yet
            const noChallenges = document.createElement('li');
            noChallenges.className = 'challenge-item';
            noChallenges.innerHTML = `
                <p class="challenge-description">You don't have any reading challenges yet. Create one to get started!</p>
            `;
            challengeList.appendChild(noChallenges);
        } else {
            // Sort challenges by start date (newest first)
            challenges.sort((a, b) => new Date(b.startDate) - new Date(a.startDate));
            
            // Add each challenge to the list
            challenges.forEach(challenge => {
                const challengeItem = createChallengeItem(challenge);
                challengeList.appendChild(challengeItem);
            });
        }
        
        // Check for challenge progress updates
        updateChallengeProgress();
    }
    
    /**
     * Create a challenge list item
     */
    function createChallengeItem(challenge) {
        const now = new Date();
        const startDate = new Date(challenge.startDate);
        const endDate = new Date(challenge.endDate);
        
        // Determine challenge status
        let status = 'upcoming';
        if (now >= startDate && now <= endDate) {
            status = 'active';
        } else if (now > endDate) {
            status = challenge.completed ? 'completed' : 'active';
        }
        
        // Calculate progress
        const progress = calculateChallengeProgress(challenge);
        
        // Create challenge item
        const item = document.createElement('li');
        item.className = `challenge-item ${status}`;
        item.dataset.id = challenge.id;
        
        // Create challenge content
        item.innerHTML = `
            <div class="challenge-header">
                <h3 class="challenge-name">${challenge.name}</h3>
                <span class="challenge-status ${status}">${status.charAt(0).toUpperCase() + status.slice(1)}</span>
            </div>
            <p class="challenge-description">${challenge.description}</p>
            <div class="challenge-dates">
                ${formatDate(startDate)} - ${formatDate(endDate)}
            </div>
            <div class="challenge-progress-container">
                <div class="challenge-progress-bar" style="width: ${progress.percentage}%"></div>
            </div>
            <div class="challenge-progress-text">
                ${progress.completed} of ${progress.total} books (${progress.percentage}%)
            </div>
        `;
        
        // Add action buttons
        const actions = document.createElement('div');
        actions.className = 'challenge-actions';
        
        if (status !== 'completed') {
            const deleteBtn = document.createElement('button');
            deleteBtn.className = 'challenge-button secondary';
            deleteBtn.textContent = 'Delete';
            deleteBtn.addEventListener('click', () => deleteChallenge(challenge.id));
            actions.appendChild(deleteBtn);
        }
        
        if (status === 'active' && progress.percentage >= 100 && !challenge.completed) {
            const completeBtn = document.createElement('button');
            completeBtn.className = 'challenge-button';
            completeBtn.textContent = 'Mark Complete';
            completeBtn.addEventListener('click', () => completeChallenge(challenge.id));
            actions.appendChild(completeBtn);
        }
        
        item.appendChild(actions);
        
        return item;
    }
    
    /**
     * Show the create challenge form
     */
    function showCreateChallengeForm() {
        // Remove any existing form
        const existingForm = document.querySelector('.create-challenge-form');
        if (existingForm) {
            existingForm.remove();
        }
        
        // Create form
        const form = document.createElement('div');
        form.className = 'create-challenge-form';
        
        // Form title
        const formTitle = document.createElement('h3');
        formTitle.className = 'challenges-title';
        formTitle.textContent = 'Create New Reading Challenge';
        form.appendChild(formTitle);
        
        // Challenge name
        const nameGroup = document.createElement('div');
        nameGroup.className = 'form-group';
        
        const nameLabel = document.createElement('label');
        nameLabel.className = 'form-label';
        nameLabel.textContent = 'Challenge Name';
        
        const nameInput = document.createElement('input');
        nameInput.className = 'form-input';
        nameInput.type = 'text';
        nameInput.id = 'challenge-name';
        nameInput.placeholder = 'e.g., Summer Reading Challenge';
        
        nameGroup.appendChild(nameLabel);
        nameGroup.appendChild(nameInput);
        form.appendChild(nameGroup);
        
        // Challenge description
        const descGroup = document.createElement('div');
        descGroup.className = 'form-group';
        
        const descLabel = document.createElement('label');
        descLabel.className = 'form-label';
        descLabel.textContent = 'Description';
        
        const descInput = document.createElement('input');
        descInput.className = 'form-input';
        descInput.type = 'text';
        descInput.id = 'challenge-description';
        descInput.placeholder = 'e.g., Read 5 books during summer break';
        
        descGroup.appendChild(descLabel);
        descGroup.appendChild(descInput);
        form.appendChild(descGroup);
        
        // Challenge type
        const typeGroup = document.createElement('div');
        typeGroup.className = 'form-group';
        
        const typeLabel = document.createElement('label');
        typeLabel.className = 'form-label';
        typeLabel.textContent = 'Challenge Type';
        
        const typeSelect = document.createElement('select');
        typeSelect.className = 'form-select';
        typeSelect.id = 'challenge-type';
        
        const typeOptions = [
            { value: 'count', text: 'Read a specific number of books' },
            { value: 'category', text: 'Complete a specific category' },
            { value: 'specific', text: 'Read specific books' }
        ];
        
        typeOptions.forEach(option => {
            const optionEl = document.createElement('option');
            optionEl.value = option.value;
            optionEl.textContent = option.text;
            typeSelect.appendChild(optionEl);
        });
        
        typeGroup.appendChild(typeLabel);
        typeGroup.appendChild(typeSelect);
        form.appendChild(typeGroup);
        
        // Target count (for count type)
        const countGroup = document.createElement('div');
        countGroup.className = 'form-group';
        countGroup.id = 'count-group';
        
        const countLabel = document.createElement('label');
        countLabel.className = 'form-label';
        countLabel.textContent = 'Number of Books';
        
        const countInput = document.createElement('input');
        countInput.className = 'form-input';
        countInput.type = 'number';
        countInput.id = 'challenge-count';
        countInput.min = '1';
        countInput.max = '18';
        countInput.value = '5';
        
        countGroup.appendChild(countLabel);
        countGroup.appendChild(countInput);
        form.appendChild(countGroup);
        
        // Category selection (for category type)
        const categoryGroup = document.createElement('div');
        categoryGroup.className = 'form-group';
        categoryGroup.id = 'category-group';
        categoryGroup.style.display = 'none';
        
        const categoryLabel = document.createElement('label');
        categoryLabel.className = 'form-label';
        categoryLabel.textContent = 'Category';
        
        const categorySelect = document.createElement('select');
        categorySelect.className = 'form-select';
        categorySelect.id = 'challenge-category';
        
        const categoryOptions = [
            { value: 'science-philosophy', text: 'Science & Philosophy' },
            { value: 'memoir-biography', text: 'Memoir & Biography' },
            { value: 'fiction', text: 'Fiction' }
        ];
        
        categoryOptions.forEach(option => {
            const optionEl = document.createElement('option');
            optionEl.value = option.value;
            optionEl.textContent = option.text;
            categorySelect.appendChild(optionEl);
        });
        
        categoryGroup.appendChild(categoryLabel);
        categoryGroup.appendChild(categorySelect);
        form.appendChild(categoryGroup);
        
        // Start date
        const startGroup = document.createElement('div');
        startGroup.className = 'form-group';
        
        const startLabel = document.createElement('label');
        startLabel.className = 'form-label';
        startLabel.textContent = 'Start Date';
        
        const startInput = document.createElement('input');
        startInput.className = 'form-input';
        startInput.type = 'date';
        startInput.id = 'challenge-start';
        startInput.value = new Date().toISOString().split('T')[0]; // Today
        
        startGroup.appendChild(startLabel);
        startGroup.appendChild(startInput);
        form.appendChild(startGroup);
        
        // End date
        const endGroup = document.createElement('div');
        endGroup.className = 'form-group';
        
        const endLabel = document.createElement('label');
        endLabel.className = 'form-label';
        endLabel.textContent = 'End Date';
        
        const endInput = document.createElement('input');
        endInput.className = 'form-input';
        endInput.type = 'date';
        endInput.id = 'challenge-end';
        
        // Default end date is 30 days from now
        const defaultEndDate = new Date();
        defaultEndDate.setDate(defaultEndDate.getDate() + 30);
        endInput.value = defaultEndDate.toISOString().split('T')[0];
        
        endGroup.appendChild(endLabel);
        endGroup.appendChild(endInput);
        form.appendChild(endGroup);
        
        // Form actions
        const formActions = document.createElement('div');
        formActions.className = 'form-actions';
        
        const cancelBtn = document.createElement('button');
        cancelBtn.className = 'challenge-button secondary';
        cancelBtn.textContent = 'Cancel';
        cancelBtn.addEventListener('click', () => form.remove());
        
        const saveBtn = document.createElement('button');
        saveBtn.className = 'challenge-button';
        saveBtn.textContent = 'Create Challenge';
        saveBtn.addEventListener('click', saveChallenge);
        
        formActions.appendChild(cancelBtn);
        formActions.appendChild(saveBtn);
        form.appendChild(formActions);
        
        // Add form to the page
        const createChallengeBtn = document.getElementById('create-challenge-btn');
        if (createChallengeBtn) {
            createChallengeBtn.parentNode.insertBefore(form, createChallengeBtn);
        }
        
        // Set up event listener for challenge type change
        typeSelect.addEventListener('change', function() {
            const selectedType = this.value;
            
            // Show/hide appropriate fields based on type
            if (selectedType === 'count') {
                countGroup.style.display = 'block';
                categoryGroup.style.display = 'none';
            } else if (selectedType === 'category') {
                countGroup.style.display = 'none';
                categoryGroup.style.display = 'block';
            } else if (selectedType === 'specific') {
                countGroup.style.display = 'none';
                categoryGroup.style.display = 'none';
                // For now, we'll just use a predefined set of specific books
            }
        });
    }
    
    /**
     * Save a new challenge
     */
    function saveChallenge() {
        // Get form values
        const name = document.getElementById('challenge-name').value;
        const description = document.getElementById('challenge-description').value;
        const type = document.getElementById('challenge-type').value;
        const startDate = document.getElementById('challenge-start').value;
        const endDate = document.getElementById('challenge-end').value;
        
        // Validate form
        if (!name || !description || !startDate || !endDate) {
            alert('Please fill in all required fields.');
            return;
        }
        
        if (new Date(endDate) <= new Date(startDate)) {
            alert('End date must be after start date.');
            return;
        }
        
        // Create challenge object
        const challenge = {
            id: generateId(),
            name,
            description,
            type,
            startDate,
            endDate,
            completed: false,
            dateCreated: new Date().toISOString()
        };
        
        // Add type-specific properties
        if (type === 'count') {
            challenge.targetCount = parseInt(document.getElementById('challenge-count').value) || 5;
        } else if (type === 'category') {
            challenge.category = document.getElementById('challenge-category').value;
        } else if (type === 'specific') {
            // For this example, we'll use a predefined set of books
            challenge.specificBooks = ['brave-new-world', '1984']; // Dystopian books
        }
        
        // Save the challenge
        const challenges = getChallenges();
        challenges.push(challenge);
        saveChallenges(challenges);
        
        // Reload challenges
        loadChallenges();
        
        // Remove the form
        const form = document.querySelector('.create-challenge-form');
        if (form) {
            form.remove();
        }
        
        // Show notification
        showChallengeNotification(`New challenge created: ${name}`);
    }
    
    /**
     * Delete a challenge
     */
    function deleteChallenge(challengeId) {
        if (confirm('Are you sure you want to delete this challenge?')) {
            const challenges = getChallenges().filter(c => c.id !== challengeId);
            saveChallenges(challenges);
            loadChallenges();
        }
    }
    
    /**
     * Mark a challenge as complete
     */
    function completeChallenge(challengeId) {
        const challenges = getChallenges();
        const challenge = challenges.find(c => c.id === challengeId);
        
        if (challenge) {
            challenge.completed = true;
            challenge.dateCompleted = new Date().toISOString();
            saveChallenges(challenges);
            loadChallenges();
            
            // Show completion notification
            showChallengeNotification(`Congratulations! You completed the "${challenge.name}" challenge!`, true);
        }
    }
    
    /**
     * Update progress for all active challenges
     */
    function updateChallengeProgress() {
        const challenges = getChallenges();
        const userData = getStoredData();
        
        if (!userData || !userData.books) return;
        
        let updated = false;
        
        challenges.forEach(challenge => {
            if (challenge.completed) return;
            
            const progress = calculateChallengeProgress(challenge, userData);
            
            // Check if challenge should be auto-completed
            if (progress.percentage >= 100) {
                // Only auto-complete if the end date has passed
                const now = new Date();
                const endDate = new Date(challenge.endDate);
                
                if (now > endDate && !challenge.completed) {
                    challenge.completed = true;
                    challenge.dateCompleted = now.toISOString();
                    updated = true;
                    
                    // Show completion notification
                    showChallengeNotification(`Congratulations! You completed the "${challenge.name}" challenge!`, true);
                }
            }
        });
        
        if (updated) {
            saveChallenges(challenges);
            loadChallenges();
        }
    }
    
    /**
     * Calculate progress for a challenge
     */
    function calculateChallengeProgress(challenge, userData = null) {
        if (!userData) {
            userData = getStoredData() || { books: {} };
        }
        
        let total = 0;
        let completed = 0;
        
        if (challenge.type === 'count') {
            total = challenge.targetCount;
            
            // Count completed books
            Object.values(userData.books || {}).forEach(isRead => {
                if (isRead) completed++;
            });
            
            // Cap at target count
            completed = Math.min(completed, total);
        } else if (challenge.type === 'category') {
            // Get books in this category
            const categoryBooks = getCategoryBooks(challenge.category);
            total = categoryBooks.length;
            
            // Count completed books in this category
            categoryBooks.forEach(bookId => {
                if (userData.books && userData.books[bookId]) {
                    completed++;
                }
            });
        } else if (challenge.type === 'specific') {
            total = challenge.specificBooks.length;
            
            // Count completed specific books
            challenge.specificBooks.forEach(bookId => {
                if (userData.books && userData.books[bookId]) {
                    completed++;
                }
            });
        }
        
        const percentage = total > 0 ? Math.round((completed / total) * 100) : 0;
        
        return {
            total,
            completed,
            percentage
        };
    }
    
    /**
     * Get books in a specific category
     */
    function getCategoryBooks(category) {
        const categoryBooks = {
            'science-philosophy': [
                'ape-universe', 'code-book', 'brief-answers', 
                'sapiens', 'thinking-fast-slow', 'why-we-sleep'
            ],
            'memoir-biography': [
                'educated', 'becoming', 'born-crime',
                'shoe-dog', 'elon-musk', 'greenlights'
            ],
            'fiction': [
                'project-hail-mary', 'midnight-library', 'invisible-life',
                'circe', 'brave-new-world', '1984'
            ]
        };
        
        return categoryBooks[category] || [];
    }
    
    /**
     * Show a notification for challenge events
     */
    function showChallengeNotification(message, isCompletion = false) {
        // Create notification element if it doesn't exist
        let notification = document.getElementById('challenge-notification');
        if (!notification) {
            notification = document.createElement('div');
            notification.id = 'challenge-notification';
            notification.className = 'challenge-notification';
            if (isCompletion) {
                notification.classList.add('completed');
            }
            document.body.appendChild(notification);
        }
        
        // Set notification message
        notification.textContent = message;
        
        // Show notification
        notification.classList.add('show');
        
        // Hide notification after 3 seconds
        setTimeout(() => {
            notification.classList.remove('show');
        }, 3000);
    }
    
    /**
     * Format a date to a readable string
     */
    function formatDate(date) {
        const options = { year: 'numeric', month: 'short', day: 'numeric' };
        return date.toLocaleDateString(undefined, options);
    }
    
    /**
     * Generate a unique ID
     */
    function generateId() {
        return 'challenge_' + Date.now() + '_' + Math.random().toString(36).substr(2, 9);
    }
    
    /**
     * Get challenges from localStorage
     */
    function getChallenges() {
        const userData = getStoredData() || {};
        return userData[CHALLENGES_KEY] || [];
    }
    
    /**
     * Save challenges to localStorage
     */
    function saveChallenges(challenges) {
        const userData = getStoredData() || {};
        userData[CHALLENGES_KEY] = challenges;
        storeData(userData);
    }
    
    /**
     * Get stored user data from localStorage
     */
    function getStoredData() {
        const storedData = localStorage.getItem(STORAGE_KEY);
        return storedData ? JSON.parse(storedData) : null;
    }
    
    /**
     * Store user data to localStorage
     */
    function storeData(data) {
        localStorage.setItem(STORAGE_KEY, JSON.stringify(data));
    }
});