# Book Rating System Documentation

## Overview
The Book Rating System adds a personal rating feature to Luigi's Bookshelf website, allowing users to rate books they've read on a scale of 1-5 stars. This feature enhances user engagement and helps users track their opinions on books they've read.

## Implementation Details

### Files Added
- **CSS**: `assets/css/rating-system.css` - Contains all styling for the rating system
- **JavaScript**: `assets/js/rating-system.js` - Contains the logic for rating books and storing user ratings

### Rating System Features

1. **User Ratings**:
   - Users can rate any book on a scale of 1-5 stars
   - Ratings are displayed alongside Luigi's own ratings
   - Ratings are saved to localStorage and persist between sessions

2. **Visual Feedback**:
   - Interactive star rating system with hover effects
   - Clear visual distinction between Luigi's ratings and user ratings
   - Rating value displayed numerically (e.g., "4/5")

3. **Notifications**:
   - Toast notification appears when a user rates a book
   - Notification includes book title and rating value
   - Notification automatically disappears after 3 seconds

### Technical Implementation

1. **Rating Storage**:
   - User ratings are stored in localStorage under the `luigis_bookshop_data` key
   - Ratings are stored in a `ratings` object with book IDs as keys
   - Example structure: `{ authenticated: true, books: {...}, ratings: { "book-id": 4 } }`

2. **UI Components**:
   - Each book entry contains both Luigi's rating and the user's rating
   - Star rating system with interactive hover and click effects
   - Rating value display showing the numerical rating

3. **Integration with Existing Features**:
   - Works alongside the reading progress tracking system
   - Compatible with dark mode
   - Responsive design for all screen sizes

## User Experience
- Users can easily rate books they've read
- Visual distinction between Luigi's expert ratings and personal ratings
- Immediate feedback when rating a book
- Ratings persist between sessions for a personalized experience

## Future Enhancements
Potential future improvements could include:
- Average ratings from all users (requires backend implementation)
- Rating history and changes over time
- Rating-based recommendations
- Rating filters to sort books by user or Luigi's ratings