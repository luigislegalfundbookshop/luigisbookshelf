# Luigi's Legal Fund Bookshop Reading List - Admin Guide

## Administrative Guide & Access Code Management

This document provides detailed instructions for managing your exclusive reading list website, including access code distribution, site maintenance, and troubleshooting.

---

## Access Code Management

### Available Access Codes

The system is configured with 50 unique access codes. Here's the complete list:

```
luigi-alpha
luigi-beta
luigi-gamma
luigi-delta
luigi-epsilon
luigi-zeta
luigi-eta
luigi-theta
luigi-iota
luigi-kappa
luigi-lambda
luigi-mu
luigi-nu
luigi-xi
luigi-omicron
luigi-pi
luigi-rho
luigi-sigma
luigi-tau
luigi-upsilon
luigi-phi
luigi-chi
luigi-psi
luigi-omega
luigi-atlas
luigi-beacon
luigi-cipher
luigi-dusk
luigi-echo
luigi-frost
luigi-glow
luigi-haven
luigi-iris
luigi-jade
luigi-knight
luigi-lunar
luigi-mist
luigi-nova
luigi-orbit
luigi-pulse
luigi-quartz
luigi-ridge
luigi-spark
luigi-tide
luigi-urban
luigi-vista
luigi-wave
luigi-xenon
luigi-yield
luigi-zenith
```

Additionally, the master access code `luigi` will always work.

### Tracking Access Code Distribution

To keep track of which codes have been distributed and to whom, you can use the template below. Copy this into a spreadsheet or document for your records:

| Access Code | Recipient Name | Email | Date Issued | Notes |
|-------------|---------------|-------|------------|-------|
| luigi-alpha | | | | |
| luigi-beta | | | | |
| luigi-gamma | | | | |
| *etc...* | | | | |

### Best Practices for Access Code Distribution

1. **Personalized Distribution**: Send access codes individually via direct message or email rather than posting publicly
2. **Record Keeping**: Always update your tracking spreadsheet immediately after issuing a code
3. **Exclusivity Messaging**: When sharing a code, emphasize its personal nature with language like:
   - "Here's your personal access code to my curated reading list"
   - "Please don't share this code as it's linked to your individual reading progress"
4. **Follow-up**: Check in with recipients occasionally to see if they're enjoying the reading list

### Adding New Access Codes

If you need to add more access codes beyond the initial 50:

1. Access the file `assets/js/main.js`
2. Locate the `ACCESS_CODES` array (around line 4)
3. Add new codes following the existing pattern
4. Save the file and redeploy the website

---

## Website Maintenance

### Updating Book Information

To update book information (titles, authors, descriptions, ratings, or reviews):

1. Access the file `index.html`
2. Locate the book entry you want to modify within the appropriate category section
3. Update the relevant HTML elements:
   - Title: `<h3 class="book-title">Book Title</h3>`
   - Author: `<p class="book-author">by Author Name</p>`
   - Summary: `<p class="book-summary">Book description here.</p>`
   - Rating: Adjust the number of star symbols (★) in `<div class="rating-stars">★★★★★</div>`
   - Review: `<div class="book-review">Luigi's review text here.</div>`
4. Save the file and redeploy the website

### Adding New Books

To add a new book:

1. Access the file `index.html`
2. Locate the appropriate category section (`Science & Philosophy`, `Memoir & Biography`, or `Fiction`)
3. Within the `<div class="book-list">` element, add a new book entry using this template:

```html
<a class="book-entry" href="https://bookshop.org/a/111922/[ISBN]" target="_blank">
    <div class="book-cover">
        <img src="" alt="[Book Title] cover">
    </div>
    <div class="book-details">
        <h3 class="book-title">[Book Title]</h3>
        <p class="book-author">by [Author Name]</p>
        <p class="book-summary">[Brief description of the book]</p>
        <div class="book-meta">
            <div class="rating-stars">★★★★★</div>
            <input type="checkbox" class="book-checkbox" data-book="[unique-id]" onclick="updateProgress()" aria-label="Mark as read">
        </div>
        <div class="book-review">[Your personal review - optional]</div>
    </div>
</a>
```

4. Replace the placeholders:
   - `[ISBN]`: The book's ISBN number (for the Bookshop.org affiliate link)
   - `[Book Title]`: The title of the book
   - `[Author Name]`: The author's name
   - `[Brief description]`: A short summary of the book
   - `[unique-id]`: A unique identifier for the book (lowercase, hyphenated version of the title)
   - `[Your personal review]`: Your review of the book (optional)
5. Save the file and redeploy the website

### Fixing Book Cover Images

If a book cover isn't displaying correctly:

1. Access the file `assets/js/book-covers.js`
2. Locate the `bookOverrides` object (around line 4)
3. Add a new entry for the problematic book:

```javascript
"Book Title": "https://images-us.bookshop.org/ingram/[ISBN].jpg?height=500&v=v2",
```

4. Replace `Book Title` with the exact title as it appears in the HTML
5. Replace `[ISBN]` with the book's ISBN number
6. Save the file and redeploy the website

### Updating the Instagram Link

If you need to update the Instagram link:

1. Access the file `index.html`
2. Find the line containing `<a href="https://www.instagram.com/luigis_legal_fund_bookshop/" target="_blank">Instagram</a>`
3. Update the URL to your new Instagram handle
4. Save the file and redeploy the website

---

## Monitoring & Analytics

Since the website doesn't include built-in analytics (to maintain user privacy), here are alternative ways to gauge engagement:

### Affiliate Link Tracking

Monitor your Bookshop.org affiliate dashboard to track:
- Number of clicks from your reading list
- Conversion rates
- Commission earned
- Most popular books

### User Feedback Collection

Consider these methods to gather user feedback:
1. Direct outreach to access code recipients
2. Occasional email check-ins
3. Instagram polls or questions
4. Personal conversations about the reading list

### Access Code Usage

While the website doesn't track who uses which code, you can:
1. Ask recipients if they've used their code
2. Note any feedback they provide about specific books
3. Track which codes generate the most engagement or questions

---

## Troubleshooting Common Issues

### Access Code Problems

**Issue**: User reports their access code isn't working
**Solution**: 
1. Verify you provided them with a code from the approved list
2. Confirm they're entering it exactly as provided (codes are case-sensitive)
3. If needed, issue them a new code from the list

### Book Cover Display Issues

**Issue**: Book covers not displaying correctly
**Solution**:
1. Add the book to the `bookOverrides` object in `assets/js/book-covers.js` as described above
2. Use the Bookshop.org image URL format: `https://images-us.bookshop.org/ingram/[ISBN].jpg?height=500&v=v2`

### Progress Tracking Issues

**Issue**: User reports their reading progress isn't saving
**Solution**: This is typically caused by:
1. Using different browsers or devices
2. Clearing browser cookies/cache
3. Using private/incognito browsing

Advise users to:
- Use the same browser and device
- Avoid clearing browser data
- Not use private/incognito mode

### Deployment Issues

**Issue**: Changes not appearing after updating files
**Solution**:
1. Ensure you've saved all modified files
2. Redeploy the website completely
3. Have users clear their browser cache or try a hard refresh (Ctrl+F5)

---

## Technical Details

### Website Structure

```
/
├── index.html                  # Main HTML file
├── assets/
│   ├── css/
│   │   └── styles.css          # Main stylesheet
│   └── js/
│       ├── main.js             # Core functionality and access codes
│       └── book-covers.js      # Book cover image handling
```

### Access Code Implementation

The access code system is implemented in `assets/js/main.js`. It:
1. Checks the entered code against the `ACCESS_CODES` array
2. Stores authentication status in the browser's localStorage
3. Displays a personalized welcome based on the code used

### Reading Progress Tracking

Reading progress is:
1. Stored in the browser's localStorage
2. Linked to the specific access code used
3. Calculated as a percentage of books marked as read

---

## Backup and Recovery

### Creating a Backup

Periodically download a complete copy of your website files:
1. index.html
2. All files in the assets directory

Store these files securely as your backup.

### Restoring from Backup

If needed, you can restore the website by:
1. Uploading your backup files to the hosting service
2. Redeploying the website

---

If you encounter any issues not covered in this guide or need additional assistance, please contact the developer who implemented this solution.

*Last updated: August 2025*