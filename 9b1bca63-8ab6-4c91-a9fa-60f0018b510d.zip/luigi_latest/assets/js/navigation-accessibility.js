// Enhanced Navigation Accessibility for Luigi's Bookshelf

document.addEventListener('DOMContentLoaded', function() {
    // Get all category links
    const categoryLinks = document.querySelectorAll('.category-nav a');
    
    // Add click event listeners to highlight active category
    categoryLinks.forEach(link => {
        link.addEventListener('click', function() {
            // Remove active class and aria-current from all links
            categoryLinks.forEach(l => {
                l.classList.remove('active');
                l.setAttribute('aria-current', 'false');
            });
            
            // Add active class and aria-current to clicked link
            this.classList.add('active');
            this.setAttribute('aria-current', 'true');
            
            // Announce to screen readers
            const announcer = document.createElement('div');
            announcer.setAttribute('aria-live', 'polite');
            announcer.classList.add('sr-only');
            announcer.textContent = `Navigated to ${this.textContent} section`;
            document.body.appendChild(announcer);
            
            // Remove announcer after it's been read
            setTimeout(() => {
                document.body.removeChild(announcer);
            }, 1000);
        });
    });
    
    // Highlight active category based on scroll position
    window.addEventListener('scroll', function() {
        const scrollPosition = window.scrollY;
        
        // Get all category sections
        const categories = document.querySelectorAll('.category-title');
        
        // Find the current visible category
        let currentCategory = '';
        categories.forEach(category => {
            const sectionTop = category.offsetTop;
            if (scrollPosition >= sectionTop - 200) {
                currentCategory = category.id;
            }
        });
        
        // Update active link if we have a current category
        if (currentCategory) {
            categoryLinks.forEach(link => {
                link.classList.remove('active');
                link.setAttribute('aria-current', 'false');
                
                if (link.getAttribute('href') === '#' + currentCategory) {
                    link.classList.add('active');
                    link.setAttribute('aria-current', 'true');
                }
            });
        }
    });
    
    // Add keyboard navigation for book entries
    const bookEntries = document.querySelectorAll('.book-entry');
    bookEntries.forEach(entry => {
        // Add tabindex to ensure keyboard focusability
        entry.setAttribute('tabindex', '0');
        
        // Add keyboard event listener for Enter key
        entry.addEventListener('keydown', function(e) {
            if (e.key === 'Enter') {
                this.click();
            }
        });
    });
    
    // Add CSS for screen reader only elements
    const style = document.createElement('style');
    style.textContent = `
        .sr-only {
            position: absolute;
            width: 1px;
            height: 1px;
            padding: 0;
            margin: -1px;
            overflow: hidden;
            clip: rect(0, 0, 0, 0);
            white-space: nowrap;
            border: 0;
        }
    `;
    document.head.appendChild(style);
});