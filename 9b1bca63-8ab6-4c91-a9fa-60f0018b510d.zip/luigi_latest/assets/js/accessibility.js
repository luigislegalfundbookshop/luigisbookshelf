// Accessibility Features for Luigi's Bookshelf

document.addEventListener('DOMContentLoaded', function() {
    // Add skip to content link
    const skipLink = document.createElement('a');
    skipLink.href = '#passport-content';
    skipLink.className = 'skip-to-content';
    skipLink.textContent = 'Skip to content';
    document.body.insertBefore(skipLink, document.body.firstChild);

    // Create accessibility toolbar toggle button
    const toggleButton = document.createElement('button');
    toggleButton.className = 'accessibility-toolbar-toggle';
    toggleButton.setAttribute('aria-label', 'Open accessibility options');
    toggleButton.setAttribute('title', 'Accessibility Options');
    toggleButton.innerHTML = '♿';
    
    // Create accessibility toolbar
    const toolbar = document.createElement('div');
    toolbar.className = 'accessibility-toolbar collapsed';
    toolbar.setAttribute('aria-hidden', 'true');
    
    // Create toolbar header
    const toolbarHeader = document.createElement('div');
    toolbarHeader.className = 'accessibility-toolbar-header';
    
    const toolbarTitle = document.createElement('h3');
    toolbarTitle.className = 'accessibility-toolbar-title';
    toolbarTitle.textContent = 'Accessibility Options';
    
    const closeButton = document.createElement('button');
    closeButton.className = 'accessibility-toolbar-close';
    closeButton.setAttribute('aria-label', 'Close accessibility options');
    closeButton.textContent = '×';
    
    toolbarHeader.appendChild(toolbarTitle);
    toolbarHeader.appendChild(closeButton);
    toolbar.appendChild(toolbarHeader);
    
    // Create accessibility options
    const options = [
        createHighContrastOption(),
        createTextSizeOption(),
        createLineSpacingOption(),
        createLetterSpacingOption(),
        createDyslexiaFontOption(),
        createFocusIndicatorOption(),
        createKeyboardNavigationOption()
    ];
    
    options.forEach(option => toolbar.appendChild(option));
    
    // Add toolbar and toggle button to the body
    document.body.appendChild(toolbar);
    document.body.appendChild(toggleButton);
    
    // Toggle toolbar visibility
    toggleButton.addEventListener('click', function() {
        toolbar.classList.toggle('collapsed');
        const isExpanded = !toolbar.classList.contains('collapsed');
        toolbar.setAttribute('aria-hidden', !isExpanded);
        toggleButton.setAttribute('aria-expanded', isExpanded);
    });
    
    // Close toolbar when close button is clicked
    closeButton.addEventListener('click', function() {
        toolbar.classList.add('collapsed');
        toolbar.setAttribute('aria-hidden', 'true');
        toggleButton.setAttribute('aria-expanded', 'false');
    });
    
    // Load saved accessibility preferences
    loadAccessibilityPreferences();
    
    // Track keyboard navigation
    document.addEventListener('keydown', function(e) {
        if (e.key === 'Tab') {
            document.body.classList.add('keyboard-navigation');
        }
    });
    
    document.addEventListener('mousedown', function() {
        document.body.classList.remove('keyboard-navigation');
    });
});

// Create high contrast mode option
function createHighContrastOption() {
    const option = document.createElement('div');
    option.className = 'accessibility-option';
    
    const title = document.createElement('span');
    title.className = 'accessibility-option-title';
    title.textContent = 'Display Mode';
    
    const controls = document.createElement('div');
    controls.className = 'accessibility-controls';
    
    const normalButton = document.createElement('button');
    normalButton.className = 'accessibility-button';
    normalButton.textContent = 'Normal';
    normalButton.setAttribute('data-mode', 'normal');
    
    const highContrastButton = document.createElement('button');
    highContrastButton.className = 'accessibility-button';
    highContrastButton.textContent = 'High Contrast';
    highContrastButton.setAttribute('data-mode', 'high-contrast');
    
    controls.appendChild(normalButton);
    controls.appendChild(highContrastButton);
    
    option.appendChild(title);
    option.appendChild(controls);
    
    // Event listeners
    normalButton.addEventListener('click', function() {
        document.body.classList.remove('high-contrast');
        updateButtonStates(controls, normalButton);
        saveAccessibilityPreference('contrast-mode', 'normal');
    });
    
    highContrastButton.addEventListener('click', function() {
        document.body.classList.add('high-contrast');
        updateButtonStates(controls, highContrastButton);
        saveAccessibilityPreference('contrast-mode', 'high-contrast');
    });
    
    return option;
}

// Create text size option
function createTextSizeOption() {
    const option = document.createElement('div');
    option.className = 'accessibility-option';
    
    const title = document.createElement('span');
    title.className = 'accessibility-option-title';
    title.textContent = 'Text Size';
    
    const controls = document.createElement('div');
    controls.className = 'accessibility-controls';
    
    const sizes = [
        { name: 'Normal', value: 'normal' },
        { name: 'Large', value: 'large' },
        { name: 'X-Large', value: 'x-large' },
        { name: 'XX-Large', value: 'xx-large' }
    ];
    
    sizes.forEach(size => {
        const button = document.createElement('button');
        button.className = 'accessibility-button';
        button.textContent = size.name;
        button.setAttribute('data-size', size.value);
        
        button.addEventListener('click', function() {
            // Remove all text size classes
            document.body.classList.remove('text-size-large', 'text-size-x-large', 'text-size-xx-large');
            
            // Add the selected class if not normal
            if (size.value !== 'normal') {
                document.body.classList.add(`text-size-${size.value}`);
            }
            
            updateButtonStates(controls, button);
            saveAccessibilityPreference('text-size', size.value);
        });
        
        controls.appendChild(button);
    });
    
    option.appendChild(title);
    option.appendChild(controls);
    
    return option;
}

// Create line spacing option
function createLineSpacingOption() {
    const option = document.createElement('div');
    option.className = 'accessibility-option';
    
    const title = document.createElement('span');
    title.className = 'accessibility-option-title';
    title.textContent = 'Line Spacing';
    
    const controls = document.createElement('div');
    controls.className = 'accessibility-controls';
    
    const spacings = [
        { name: 'Normal', value: 'normal' },
        { name: 'Medium', value: 'medium' },
        { name: 'Large', value: 'large' },
        { name: 'X-Large', value: 'x-large' }
    ];
    
    spacings.forEach(spacing => {
        const button = document.createElement('button');
        button.className = 'accessibility-button';
        button.textContent = spacing.name;
        button.setAttribute('data-spacing', spacing.value);
        
        button.addEventListener('click', function() {
            // Remove all line spacing classes
            document.body.classList.remove('line-spacing-medium', 'line-spacing-large', 'line-spacing-x-large');
            
            // Add the selected class if not normal
            if (spacing.value !== 'normal') {
                document.body.classList.add(`line-spacing-${spacing.value}`);
            }
            
            updateButtonStates(controls, button);
            saveAccessibilityPreference('line-spacing', spacing.value);
        });
        
        controls.appendChild(button);
    });
    
    option.appendChild(title);
    option.appendChild(controls);
    
    return option;
}

// Create letter spacing option
function createLetterSpacingOption() {
    const option = document.createElement('div');
    option.className = 'accessibility-option';
    
    const title = document.createElement('span');
    title.className = 'accessibility-option-title';
    title.textContent = 'Letter Spacing';
    
    const controls = document.createElement('div');
    controls.className = 'accessibility-controls';
    
    const spacings = [
        { name: 'Normal', value: 'normal' },
        { name: 'Medium', value: 'medium' },
        { name: 'Large', value: 'large' },
        { name: 'X-Large', value: 'x-large' }
    ];
    
    spacings.forEach(spacing => {
        const button = document.createElement('button');
        button.className = 'accessibility-button';
        button.textContent = spacing.name;
        button.setAttribute('data-letter-spacing', spacing.value);
        
        button.addEventListener('click', function() {
            // Remove all letter spacing classes
            document.body.classList.remove('letter-spacing-medium', 'letter-spacing-large', 'letter-spacing-x-large');
            
            // Add the selected class if not normal
            if (spacing.value !== 'normal') {
                document.body.classList.add(`letter-spacing-${spacing.value}`);
            }
            
            updateButtonStates(controls, button);
            saveAccessibilityPreference('letter-spacing', spacing.value);
        });
        
        controls.appendChild(button);
    });
    
    option.appendChild(title);
    option.appendChild(controls);
    
    return option;
}

// Create dyslexia-friendly font option
function createDyslexiaFontOption() {
    const option = document.createElement('div');
    option.className = 'accessibility-option';
    
    const title = document.createElement('span');
    title.className = 'accessibility-option-title';
    title.textContent = 'Font';
    
    const controls = document.createElement('div');
    controls.className = 'accessibility-controls';
    
    const normalButton = document.createElement('button');
    normalButton.className = 'accessibility-button';
    normalButton.textContent = 'Standard Font';
    normalButton.setAttribute('data-font', 'normal');
    
    const dyslexiaButton = document.createElement('button');
    dyslexiaButton.className = 'accessibility-button';
    dyslexiaButton.textContent = 'Dyslexia-Friendly Font';
    dyslexiaButton.setAttribute('data-font', 'dyslexia');
    
    controls.appendChild(normalButton);
    controls.appendChild(dyslexiaButton);
    
    option.appendChild(title);
    option.appendChild(controls);
    
    // Event listeners
    normalButton.addEventListener('click', function() {
        document.body.classList.remove('dyslexia-font');
        updateButtonStates(controls, normalButton);
        saveAccessibilityPreference('font', 'normal');
    });
    
    dyslexiaButton.addEventListener('click', function() {
        document.body.classList.add('dyslexia-font');
        updateButtonStates(controls, dyslexiaButton);
        saveAccessibilityPreference('font', 'dyslexia');
    });
    
    return option;
}

// Create focus indicator option
function createFocusIndicatorOption() {
    const option = document.createElement('div');
    option.className = 'accessibility-option';
    
    const title = document.createElement('span');
    title.className = 'accessibility-option-title';
    title.textContent = 'Focus Indicators';
    
    const controls = document.createElement('div');
    controls.className = 'accessibility-controls';
    
    const normalButton = document.createElement('button');
    normalButton.className = 'accessibility-button';
    normalButton.textContent = 'Normal';
    normalButton.setAttribute('data-focus', 'normal');
    
    const enhancedButton = document.createElement('button');
    enhancedButton.className = 'accessibility-button';
    enhancedButton.textContent = 'Enhanced';
    enhancedButton.setAttribute('data-focus', 'enhanced');
    
    controls.appendChild(normalButton);
    controls.appendChild(enhancedButton);
    
    option.appendChild(title);
    option.appendChild(controls);
    
    // Event listeners
    normalButton.addEventListener('click', function() {
        document.body.classList.remove('enhanced-focus');
        updateButtonStates(controls, normalButton);
        saveAccessibilityPreference('focus', 'normal');
    });
    
    enhancedButton.addEventListener('click', function() {
        document.body.classList.add('enhanced-focus');
        updateButtonStates(controls, enhancedButton);
        saveAccessibilityPreference('focus', 'enhanced');
    });
    
    return option;
}

// Create keyboard navigation option
function createKeyboardNavigationOption() {
    const option = document.createElement('div');
    option.className = 'accessibility-option';
    
    const title = document.createElement('span');
    title.className = 'accessibility-option-title';
    title.textContent = 'Keyboard Navigation';
    
    const description = document.createElement('p');
    description.textContent = 'Press Tab to navigate between elements. Press Enter to activate links and buttons.';
    description.style.fontSize = '0.9em';
    description.style.marginTop = '5px';
    
    option.appendChild(title);
    option.appendChild(description);
    
    return option;
}

// Update button states in a control group
function updateButtonStates(controlsContainer, activeButton) {
    const buttons = controlsContainer.querySelectorAll('.accessibility-button');
    buttons.forEach(button => {
        button.classList.remove('active');
    });
    activeButton.classList.add('active');
}

// Save accessibility preference to localStorage
function saveAccessibilityPreference(key, value) {
    const preferences = getAccessibilityPreferences();
    preferences[key] = value;
    localStorage.setItem('luigis_bookshelf_accessibility', JSON.stringify(preferences));
}

// Get accessibility preferences from localStorage
function getAccessibilityPreferences() {
    const savedPreferences = localStorage.getItem('luigis_bookshelf_accessibility');
    return savedPreferences ? JSON.parse(savedPreferences) : {};
}

// Load and apply saved accessibility preferences
function loadAccessibilityPreferences() {
    const preferences = getAccessibilityPreferences();
    
    // Apply contrast mode
    if (preferences['contrast-mode'] === 'high-contrast') {
        document.body.classList.add('high-contrast');
        const highContrastButton = document.querySelector('[data-mode="high-contrast"]');
        if (highContrastButton) {
            updateButtonStates(highContrastButton.parentElement, highContrastButton);
        }
    } else {
        const normalContrastButton = document.querySelector('[data-mode="normal"]');
        if (normalContrastButton) {
            updateButtonStates(normalContrastButton.parentElement, normalContrastButton);
        }
    }
    
    // Apply text size
    if (preferences['text-size'] && preferences['text-size'] !== 'normal') {
        document.body.classList.add(`text-size-${preferences['text-size']}`);
        const textSizeButton = document.querySelector(`[data-size="${preferences['text-size']}"]`);
        if (textSizeButton) {
            updateButtonStates(textSizeButton.parentElement, textSizeButton);
        }
    } else {
        const normalSizeButton = document.querySelector('[data-size="normal"]');
        if (normalSizeButton) {
            updateButtonStates(normalSizeButton.parentElement, normalSizeButton);
        }
    }
    
    // Apply line spacing
    if (preferences['line-spacing'] && preferences['line-spacing'] !== 'normal') {
        document.body.classList.add(`line-spacing-${preferences['line-spacing']}`);
        const lineSpacingButton = document.querySelector(`[data-spacing="${preferences['line-spacing']}"]`);
        if (lineSpacingButton) {
            updateButtonStates(lineSpacingButton.parentElement, lineSpacingButton);
        }
    } else {
        const normalSpacingButton = document.querySelector('[data-spacing="normal"]');
        if (normalSpacingButton) {
            updateButtonStates(normalSpacingButton.parentElement, normalSpacingButton);
        }
    }
    
    // Apply letter spacing
    if (preferences['letter-spacing'] && preferences['letter-spacing'] !== 'normal') {
        document.body.classList.add(`letter-spacing-${preferences['letter-spacing']}`);
        const letterSpacingButton = document.querySelector(`[data-letter-spacing="${preferences['letter-spacing']}"]`);
        if (letterSpacingButton) {
            updateButtonStates(letterSpacingButton.parentElement, letterSpacingButton);
        }
    } else {
        const normalLetterSpacingButton = document.querySelector('[data-letter-spacing="normal"]');
        if (normalLetterSpacingButton) {
            updateButtonStates(normalLetterSpacingButton.parentElement, normalLetterSpacingButton);
        }
    }
    
    // Apply font
    if (preferences['font'] === 'dyslexia') {
        document.body.classList.add('dyslexia-font');
        const dyslexiaFontButton = document.querySelector('[data-font="dyslexia"]');
        if (dyslexiaFontButton) {
            updateButtonStates(dyslexiaFontButton.parentElement, dyslexiaFontButton);
        }
    } else {
        const normalFontButton = document.querySelector('[data-font="normal"]');
        if (normalFontButton) {
            updateButtonStates(normalFontButton.parentElement, normalFontButton);
        }
    }
    
    // Apply focus indicators
    if (preferences['focus'] === 'enhanced') {
        document.body.classList.add('enhanced-focus');
        const enhancedFocusButton = document.querySelector('[data-focus="enhanced"]');
        if (enhancedFocusButton) {
            updateButtonStates(enhancedFocusButton.parentElement, enhancedFocusButton);
        }
    } else {
        const normalFocusButton = document.querySelector('[data-focus="normal"]');
        if (normalFocusButton) {
            updateButtonStates(normalFocusButton.parentElement, normalFocusButton);
        }
    }
}