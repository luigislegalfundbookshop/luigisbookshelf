// Statistics Fix for Luigi's Bookshelf - Version 2

document.addEventListener('DOMContentLoaded', function() {
    // Constants
    const STORAGE_KEY = "luigis_bookshop_data";
    const STATS_KEY = "reading_stats";
    
    // Wait for the page to fully load
    setTimeout(function() {
        // Initialize the fix
        initStatisticsFix();
    }, 1000);
    
    /**
     * Initialize the statistics fix
     */
    function initStatisticsFix() {
        console.log("Initializing statistics fix...");
        
        // First, make sure all read books are in the statistics
        syncReadBooksWithStatistics();
        
        // Fix the book completion tracking
        fixBookCompletionTracking();
        
        // Force update the statistics display
        forceUpdateStatistics();
    }
    
    /**
     * Synchronize read books with statistics
     */
    function syncReadBooksWithStatistics() {
        console.log("Syncing read books with statistics...");
        const userData = getStoredData() || {};
        
        // Check if books are marked as read but not in statistics
        if (userData.books) {
            if (!userData[STATS_KEY]) {
                userData[STATS_KEY] = {
                    activityDates: [],
                    booksCompletedDates: {},
                    lastVisit: null
                };
            }
            
            // Get today's date (YYYY-MM-DD format)
            const today = new Date().toISOString().split('T')[0];
            
            // Record today's visit
            if (!userData[STATS_KEY].activityDates.includes(today)) {
                userData[STATS_KEY].activityDates.push(today);
            }
            
            // Record last visit
            userData[STATS_KEY].lastVisit = new Date().toISOString();
            
            // Add any read books to statistics if not already there
            let updatedBooks = false;
            Object.keys(userData.books).forEach(bookId => {
                if (userData.books[bookId] && !userData[STATS_KEY].booksCompletedDates[bookId]) {
                    userData[STATS_KEY].booksCompletedDates[bookId] = today;
                    updatedBooks = true;
                    console.log(`Added book ${bookId} to statistics`);
                }
            });
            
            if (updatedBooks) {
                // Save updated data
                storeData(userData);
                console.log("Updated user data with synchronized books");
            }
        }
    }
    
    /**
     * Fix book completion tracking
     */
    function fixBookCompletionTracking() {
        console.log("Fixing book completion tracking...");
        const bookCheckboxes = document.querySelectorAll('.book-checkbox');
        
        bookCheckboxes.forEach(checkbox => {
            // Remove existing event listeners (not possible directly, so we clone and replace)
            const newCheckbox = checkbox.cloneNode(true);
            checkbox.parentNode.replaceChild(newCheckbox, checkbox);
            
            // Add our enhanced event listener
            newCheckbox.addEventListener('change', function() {
                console.log(`Checkbox for ${this.getAttribute('data-book')} changed to ${this.checked}`);
                
                // Update the main progress tracking
                updateProgress();
                
                // If checked, record the book completion for statistics
                if (this.checked) {
                    recordBookCompletion(this.getAttribute('data-book'));
                }
            });
        });
        
        // Also restore checkbox states from storage
        loadUserProgress();
    }
    
    /**
     * Update progress
     */
    function updateProgress() {
        console.log("Updating progress...");
        const userData = getStoredData() || { authenticated: true, books: {} };
        const bookCheckboxes = document.querySelectorAll('.book-checkbox');
        
        // Update book status in storage
        bookCheckboxes.forEach(checkbox => {
            const bookId = checkbox.getAttribute('data-book');
            userData.books[bookId] = checkbox.checked;
        });
        
        storeData(userData);
        
        // Calculate and display progress
        const totalBooks = bookCheckboxes.length;
        const readBooks = Object.values(userData.books).filter(Boolean).length;
        const progressPercentage = (readBooks / totalBooks) * 100;
        
        console.log(`Progress: ${readBooks} of ${totalBooks} books (${Math.round(progressPercentage)}%)`);
        
        const progressFill = document.getElementById('progress-fill');
        const progressText = document.getElementById('progress-text');
        
        if (progressFill) {
            progressFill.style.width = `${progressPercentage}%`;
        }
        
        if (progressText) {
            progressText.textContent = `Reading Progress: ${readBooks} of ${totalBooks} books (${Math.round(progressPercentage)}%)`;
        }
    }
    
    /**
     * Load user progress from storage
     */
    function loadUserProgress() {
        console.log("Loading user progress...");
        const userData = getStoredData();
        
        if (userData && userData.books) {
            // Set checkbox states
            const bookCheckboxes = document.querySelectorAll('.book-checkbox');
            bookCheckboxes.forEach(checkbox => {
                const bookId = checkbox.getAttribute('data-book');
                if (userData.books[bookId]) {
                    checkbox.checked = true;
                    console.log(`Set checkbox for ${bookId} to checked`);
                }
            });
        }
    }
    
    /**
     * Record when a book is completed
     */
    function recordBookCompletion(bookId) {
        console.log(`Recording completion for book ${bookId}`);
        // Get stored data
        const userData = getStoredData() || {};
        
        // Initialize reading stats if needed
        if (!userData[STATS_KEY]) {
            userData[STATS_KEY] = {
                activityDates: [],
                booksCompletedDates: {},
                lastVisit: null
            };
        }
        
        // Check if this book was already recorded
        if (!userData[STATS_KEY].booksCompletedDates[bookId]) {
            // Get today's date (YYYY-MM-DD format)
            const today = new Date().toISOString().split('T')[0];
            
            // Record completion date
            userData[STATS_KEY].booksCompletedDates[bookId] = today;
            
            // Save data
            storeData(userData);
            console.log(`Saved completion date for book ${bookId}`);
            
            // Force update the statistics display
            forceUpdateStatistics();
        }
    }
    
    /**
     * Force update the statistics display
     */
    function forceUpdateStatistics() {
        console.log("Forcing statistics update...");
        
        // Check if statistics section exists
        const statisticsSection = document.querySelector('.statistics-section');
        if (!statisticsSection) {
            console.log("Statistics section not found");
            return;
        }
        
        // Find the original generateStatistics function
        if (window.generateStatistics) {
            console.log("Found original generateStatistics function");
            
            // Find the active period button
            const activeButton = document.querySelector('.statistics-time-button.active');
            if (activeButton) {
                const period = activeButton.dataset.period || 'all';
                console.log(`Calling generateStatistics with period: ${period}`);
                window.generateStatistics(period);
            } else {
                console.log("No active period button found, using 'all'");
                window.generateStatistics('all');
            }
        } else {
            console.log("Original generateStatistics function not found");
            
            // Try to find the function in the reading-statistics.js script
            const scripts = document.querySelectorAll('script');
            let statisticsScript = null;
            
            for (const script of scripts) {
                if (script.src && script.src.includes('reading-statistics.js')) {
                    statisticsScript = script;
                    break;
                }
            }
            
            if (statisticsScript) {
                console.log("Found reading-statistics.js script");
                
                // Create a custom event to trigger statistics update
                const event = new CustomEvent('updateStatistics', { detail: { period: 'all' } });
                document.dispatchEvent(event);
            } else {
                console.log("Could not find reading-statistics.js script");
            }
        }
    }
    
    /**
     * Get stored data from localStorage
     */
    function getStoredData() {
        const storedData = localStorage.getItem(STORAGE_KEY);
        return storedData ? JSON.parse(storedData) : null;
    }
    
    /**
     * Store data to localStorage
     */
    function storeData(data) {
        localStorage.setItem(STORAGE_KEY, JSON.stringify(data));
    }
});

// Make generateStatistics globally accessible
window.addEventListener('load', function() {
    // Find the original generateStatistics function
    const scripts = document.querySelectorAll('script');
    let statisticsScript = null;
    
    for (const script of scripts) {
        if (script.src && script.src.includes('reading-statistics.js')) {
            statisticsScript = script;
            break;
        }
    }
    
    if (statisticsScript) {
        // Try to access the generateStatistics function
        setTimeout(function() {
            // Check if the function is already defined
            if (typeof generateStatistics === 'function') {
                // Make it globally accessible
                window.generateStatistics = generateStatistics;
                console.log("Made generateStatistics globally accessible");
            }
        }, 1500);
    }
});