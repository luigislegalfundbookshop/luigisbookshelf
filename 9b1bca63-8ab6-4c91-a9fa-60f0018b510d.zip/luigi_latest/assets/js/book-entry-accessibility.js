// Book Entry Accessibility Enhancements for Luigi's Bookshelf

document.addEventListener('DOMContentLoaded', function() {
    // Get all book entries
    const bookEntries = document.querySelectorAll('.book-entry');
    
    // Enhance each book entry with accessibility attributes
    bookEntries.forEach((entry, index) => {
        // Add role for list item
        entry.setAttribute('role', 'listitem');
        
        // Get the book title
        const bookTitle = entry.querySelector('.book-title');
        if (bookTitle) {
            // Create a unique ID for the book title if it doesn't have one
            const bookId = bookTitle.id || `book-title-${index}`;
            bookTitle.id = bookId;
            
            // Associate the book entry with its title
            entry.setAttribute('aria-labelledby', bookId);
            
            // Get the checkbox for marking as read
            const checkbox = entry.querySelector('.book-checkbox');
            if (checkbox) {
                // Update the aria-label to be more descriptive
                checkbox.setAttribute('aria-label', `Mark ${bookTitle.textContent} as read`);
            }
            
            // Get the rating stars
            const ratingStars = entry.querySelector('.rating-stars');
            if (ratingStars) {
                // Count the number of filled stars
                const filledStars = (ratingStars.textContent.match(/★/g) || []).length;
                // Set an appropriate aria-label
                ratingStars.setAttribute('aria-label', `Rating: ${filledStars} out of 5 stars`);
            }
            
            // Get the book review
            const bookReview = entry.querySelector('.book-review');
            if (bookReview) {
                // Add aria-label if not present
                if (!bookReview.hasAttribute('aria-label')) {
                    bookReview.setAttribute('aria-label', 'Review');
                }
            }
        }
        
        // Get the book cover image
        const bookCover = entry.querySelector('.book-cover img');
        if (bookCover) {
            // Ensure alt text is descriptive if not already
            if (!bookCover.alt || bookCover.alt === '') {
                const bookTitleText = bookTitle ? bookTitle.textContent : 'Book';
                bookCover.alt = `${bookTitleText} cover`;
            }
        }
    });
    
    // Make book lists have proper list semantics
    const bookLists = document.querySelectorAll('.book-list');
    bookLists.forEach(list => {
        if (!list.hasAttribute('role')) {
            list.setAttribute('role', 'list');
        }
    });
    
    // Enhance category sections with proper semantics
    const categories = document.querySelectorAll('.book-categories > h2.category-title');
    categories.forEach(category => {
        // If the category title is not already in a section
        if (category.parentElement.className === 'book-categories') {
            // Get the category ID
            const categoryId = category.id;
            
            // Get all elements until the next category title
            let elements = [];
            let nextElement = category.nextElementSibling;
            
            while (nextElement && !nextElement.matches('h2.category-title')) {
                elements.push(nextElement);
                nextElement = nextElement.nextElementSibling;
            }
            
            // Create a section element
            const section = document.createElement('section');
            section.setAttribute('aria-labelledby', categoryId);
            
            // Insert the section before the category title
            category.parentElement.insertBefore(section, category);
            
            // Move the category title and all related elements into the section
            section.appendChild(category);
            elements.forEach(el => section.appendChild(el));
        }
    });
});