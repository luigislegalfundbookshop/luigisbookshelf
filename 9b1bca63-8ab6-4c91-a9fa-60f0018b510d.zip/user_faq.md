# Luigi's Legal Fund Bookshop Reading List - User FAQ

## Welcome to Luigi's Curated Reading List!

This exclusive reading list has been carefully curated to share some of Luigi's favorite books across various genres. Below you'll find answers to common questions about accessing and using this resource.

---

## Frequently Asked Questions

### Access & Login

**Q: How do I access the reading list?**  
A: You need a personal access code to view the reading list. This code was provided to you directly by Luigi. Enter it on the welcome screen to gain access.

**Q: Is my access code unique to me?**  
A: Yes! Each person receives their own personal access code. Please don't share your code with others, as it's linked to your individual reading progress.

**Q: Can I access the reading list on different devices?**  
A: Yes, you can use your access code on any device. Your reading progress will be synchronized across devices as long as you use the same browser and don't clear your cookies/cache.

**Q: What if I forget my access code?**  
A: Please contact Luigi directly for assistance with your access code. For security reasons, we cannot retrieve or reset codes automatically.

**Q: How long is my access valid?**  
A: Your access code provides unlimited access to the reading list. There is no expiration date.

---

### Using the Reading List

**Q: How is the reading list organized?**  
A: Books are organized into three main categories:
- Science & Philosophy
- Memoir & Biography
- Fiction

You can navigate between categories using the navigation bar at the top of the page.

**Q: How do I track my reading progress?**  
A: Next to each book title, you'll find a checkbox. Check the box when you've completed reading a book. The progress bar at the top of the page will update automatically to show your overall reading progress.

**Q: Is my reading progress saved?**  
A: Yes, your reading progress is saved in your browser's local storage. As long as you use the same browser and don't clear your cookies/cache, your progress will be remembered.

**Q: What information can I find about each book?**  
A: For each book, you'll see:
- Book cover image
- Title and author
- Brief summary
- Luigi's personal rating (1-5 stars)
- Luigi's personal review (for select titles)
- A link to purchase the book from Bookshop.org

**Q: Can I sort or filter the books?**  
A: Currently, books are organized by category. You can use the category navigation at the top to quickly jump to different sections.

---

### Book Purchases

**Q: What happens when I click on a book?**  
A: Clicking on a book will take you to Bookshop.org where you can purchase the book. This opens in a new tab, so you won't lose your place in the reading list.

**Q: Do purchases support Luigi's Legal Fund?**  
A: Yes! All book purchases made through links on this reading list generate affiliate commissions that directly support Luigi's Legal Fund.

**Q: Do I have to purchase books through these links?**  
A: Not at all. The reading list is provided as a resource regardless of where you choose to acquire the books. However, purchases through the provided links do help support Luigi's Legal Fund.

---

### Technical Support

**Q: The site isn't working properly on my device. What should I do?**  
A: Try these troubleshooting steps:
1. Refresh the page
2. Clear your browser cache and cookies
3. Try a different browser
4. If using a mobile device, try rotating to landscape mode

**Q: Some book covers aren't displaying correctly. What should I do?**  
A: Occasionally, book cover images may take a moment to load. If they don't appear after refreshing the page, please let Luigi know which specific books are affected.

**Q: How do I report other technical issues?**  
A: Please contact Luigi directly with any technical issues, including:
- Problems with your access code
- Books or reviews not displaying correctly
- Issues with tracking your reading progress

---

### Privacy & Data

**Q: What information is collected about me?**  
A: The reading list only stores your reading progress locally in your browser. No personal information is collected or stored on any server.

**Q: Can Luigi see which books I've read?**  
A: No. Your reading progress is stored only on your device and is not transmitted to Luigi or any third party.

**Q: Is my browsing activity on the reading list tracked?**  
A: No. The reading list does not use any analytics or tracking tools. Your browsing activity within the reading list is completely private.

---

Thank you for being part of Luigi's exclusive reading community! If you have any questions not covered in this FAQ, please reach out to Luigi directly.

*Last updated: August 2025*