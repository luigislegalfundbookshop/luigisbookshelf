# Fix Issues for Luigi's Bookshelf

## UI Fix (Completed)
- [x] Fix centering issue with access code input box and submit button
- [x] Document UI changes
- [x] Create backup of original CSS

## New Issue: Missing Book Covers (Completed)
- [x] Examine the book cover loading mechanism
- [x] Identify which book covers have disappeared
- [x] Determine the cause of the disappearing covers
- [x] Test to ensure all book covers display properly
- [x] Document the changes made

## Dark Mode Toggle Button Issue
- [ ] Extract and examine the current website files
- [ ] Review the dark mode implementation (CSS and JS)
- [ ] Identify why the dark mode toggle button is not appearing
- [ ] Fix the dark mode toggle button visibility issue
- [ ] Test the dark mode functionality
- [ ] Ensure the toggle works correctly
- [ ] Verify the dark mode styling is applied properly
- [ ] Document the changes made